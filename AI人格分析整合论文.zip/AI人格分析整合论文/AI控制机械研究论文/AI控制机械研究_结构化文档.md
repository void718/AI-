# AI 控制机械 / 人形机器人公开研究资料综述

## 检索说明

- 检索日期：2026-09-28
- 检索范围：清华大学、北京大学、复旦大学、哈佛大学（含上海交大、MIT/Stanford/Berkeley/CMU/ETH/Google DeepMind/NVIDIA 等明确标注的补充来源）；企业线为宇树科技、众擎科技（含 Figure/智元/Boston Dynamics/Tesla 补充）。
- 信息原则：仅采用公开可获取、并已实际打开页面核实的信息；每条标注资料类型、发布时间与 URL。
- 成果归属：全文严格区分「高校学术研究成果」与「企业工程落地成果」。
- 免责声明：本报告为公开资料综述，不构成任何投资或采购建议。

## 目录

1. 总览统计  2. 六主题覆盖矩阵  3. 六大技术主题综述（T1–T6）  4. 高校学术研究成果  5. 企业工程落地成果  6. 高校 vs 企业对比  7. 重要核实与局限  8. 全部参考来源清单（85 条）  9. 检索未果说明

## 1. 总览统计

### 1.1 三批条目统计

| 批次 | 条目数 | 编号区间 |
|---|---|---|
| 高校中国线（清华/北大/复旦/上交补充） | 26 | CN-001 ~ CN-026 |
| 哈佛及国际线 | 30 | INTL-001 ~ INTL-030 |
| 企业线（宇树/众擎/补充企业） | 29 | ENT-001 ~ ENT-029 |
| **合计** | **85** | — |

### 1.2 各机构 / 企业条目数

| 机构 / 企业 | 条目数 |
|---|---|
| 清华大学 | 9 |
| 北京大学 | 6 |
| 复旦大学 | 8 |
| 上海交通大学（补充） | 3 |
| 哈佛大学 | 9 |
| 其他国际高校与机构（MIT/Stanford/Berkeley/CMU/ETH/DeepMind/NVIDIA等） | 21 |
| 宇树科技 Unitree Robotics | 12 |
| 众擎科技 EngineAI | 11 |
| 补充企业（Figure/智元/Boston Dynamics/Tesla） | 6 |

### 1.3 六主题 × 高校/企业覆盖矩阵

| 主题 | 名称 | 高校中国线命中 | 哈佛及国际线命中 | 企业线命中 |
|---|---|---|---|---|
| T1 | AI 运动控制 | 13 | 7 | 13 |
| T2 | 机器人端侧 AI | 3 | 3 | 12 |
| T3 | 大模型操控机械本体 | 8 | 6 | 4 |
| T4 | 多模态机器人控制 | 4 | 4 | 3 |
| T5 | 强化学习机器人控制 | 15 | 10 | 5 |
| T6 | 机器人感知与执行联动 | 10 | 14 | 7 |

> 注：单条可同时命中多个主题，故各主题命中数之和大于条目总数。

## 2. 六大技术主题综述（T1 → T6）

### T1 AI 运动控制

**是什么**：AI 运动控制指用学习方法生成双足/四足步态、全身控制与高动态运动（跑、跳、空翻、爬坡），是足式机器人的基础能力。

**高校学术代表性进展**：
- [CN-002] 清华 DWL：全球首个在野外雪地/坡道/楼梯统一同一神经网络策略并零样本 sim2real 的人形运动（RSS 2024 最佳论文候选）
- [CN-004] 清华 Humanoid Parkour：端到端视觉全身控制，跳上 0.42m 高台、跨 0.8m 间隙、野外 1.8m/s（CoRL 2024）
- [CN-020] 复旦基于 PPO 让人形'具身天工3.0'以 2h07min 完赛 21.0975km 半马
- [INTL-001/002] 哈佛 HAMR-Jr 微型四足达 13.91 体长/s；跳虫启发机构水平跳跃 23 倍体长（Science Robotics）
- [INTL-012] MIT Mini Cheetah 用 RL 在草地/冰面跑到 3.9m/s（RSS 2022）
- [INTL-014] ETH 多专家蒸馏+RL 微调实现 ANYmal D 野外跑酷跨楼梯窄梁

**企业工程落地代表性进展**：
- [ENT-003] 宇树 H1 行走 3.3m/s，当时全尺寸人形速度纪录
- [ENT-005] 宇树 B2 四足奔跑 >6m/s、跳跃 >1.6m、站立负载≥120kg
- [ENT-014/019] 众擎 PM01 完成全球首例人形前空翻，空中每秒协同调整四五百次关节
- [ENT-016] 众擎 T800 膝关节 450N·m，支撑跑跳、回旋踢与格斗
- [ENT-028] Boston Dynamics 全电 Atlas 以跑跳空翻长期作动态运动国际标杆

**趋势小结**：高校以论文/开源框架把运动策略推向复杂地形与零样本迁移；企业以整机产品与高动态特技展示工程成熟度，sim-to-real 与课程学习已成标配。

### T2 机器人端侧 AI

**是什么**：机器人端侧 AI 指在机载/边缘算力上完成实时推理与控制，以及自研关节电机、执行器等端侧硬件。

**高校学术代表性进展**：
- [CN-014] 北大 Jetson-PI 前瞻对齐异步推理，在 Jetson Orin 上控制频率较朴素 PyTorch 提升 8.66 倍（CoRL 2026）
- [CN-012] 北大 Being-0：除大模型外全部组件可部署于低成本机载计算设备
- [CN-026] 上交王皓轩团队异步推理/动作块动态调整/量化三连（ICLR/ECCV/ICCV 2025-2026）
- [INTL-023] NVIDIA Cosmos 3 Edge 4B 世界模型原生跑在 Jetson Thor，15Hz 闭环
- [INTL-024] LiteVLA-Edge：4-bit GGUF 量化全端侧 VLA，端到端 150.5ms
- [INTL-030] OpenPi π0.5 经 TensorRT FP8/NVFP4 部署 Thor，延迟 132ms→49ms

**企业工程落地代表性进展**：
- [ENT-006] 宇树官方自述全自研电机/减速器/控制器/激光雷达，累计申请专利 200 余项
- [ENT-007/012] 宇树美国授权专利 US12584539 一体化关节动力单元；IM6014 关节电机仅 535g
- [ENT-013/016] 众擎 SE01/T800 行星/谐波/直线核心关节全栈自研，T800 关节扭矩 450N·m

**趋势小结**：高校侧集中在'在商用 Jetson 模组上做推理加速/量化/异步调度'，企业侧集中在自研关节电机与执行器；高校自研控制 SoC/NPU 公开成果稀缺。

### T3 大模型操控机械本体

**是什么**：大模型操控机械本体指 VLA（视觉-语言-动作）模型、LLM/VLM 直接驱动或规划机器人完成任务。

**高校学术代表性进展**：
- [INTL-010] Google RT-2：把动作当 token 并入 VLM，获网络知识涌现能力（CoRL 2023）
- [INTL-011] Stanford/Berkeley OpenVLA：7B 开源、97 万条真机演示训练，比 RT-2-X 成功率高 16.5%
- [INTL-013] NVIDIA GR00T N1：System2 语言+System1 扩散动作双系统开放人形基座
- [CN-005] 清华 AIR X-VLA：0.9B 软提示跨本体 VLA，刷新 LIBERO 等基准并完成 120 分钟自主叠衣（ICLR 2026）
- [CN-006] 清华 ViLa：借 GPT-4V 做视觉语言任务规划的早期范式
- [INTL-022] Berkeley LeVERB：VLM 隐式动作词表+RL 全身控制，较朴素层级方案高 7.8 倍

**企业工程落地代表性进展**：
- [ENT-024/025] Figure Helix/Helix 02：pixels-to-actions 双系统 VLA，从上半身扩展到全身自主
- [ENT-029] Tesla Optimus 复用 FSD 神经网络架构做视觉到动作控制，已装第一代产线
- [ENT-011] 王兴兴 WRC2026 透露预研大模型驱动的'物理 AI 自进化'体系（无一手论文）

**趋势小结**：双系统（慢思考语言+快动作扩散）成为 VLA 主流架构；高校与企业研究院贡献模型，中国整机企业侧自有 VLA 论文仍稀缺。

### T4 多模态机器人控制

**是什么**：多模态机器人控制指视觉、触觉/力觉、语言等多通道感知融合后驱动控制。

**高校学术代表性进展**：
- [CN-010] 北大 TacThru'透视皮肤'同步视触觉，5 任务平均成功率 85.5%（RA-L）
- [CN-008] 清华'脉冲-语言双通道'类脑触觉：快感知+慢推理贯通人工触觉
- [INTL-018] Berkeley/Google GelSight 触觉识别物体实例，仅凭触觉超过人类志愿者（ICRA 2019）
- [INTL-029] UIUC/华盛顿 3D-ViTac：低成本柔性触觉+视觉 3D 表征+扩散策略（CoRL 2024）
- [INTL-007] 哈佛 IMPACT：学习内模型预测控制免腕部力/触觉传感器做用力型操作

**企业工程落地代表性进展**：
- [ENT-008] 宇树 US12411198 双天线定向跟随专利，定位+相对位姿驱动整机随行
- [ENT-013/023] 众擎 SE01 配激光雷达+深度相机+6 颗摄像头，深圳街头无缆导航避障

**趋势小结**：触觉/力觉融合在高校活跃并出定量结果；中国整机企业多为'视觉+激光'配置介绍，缺带定量成功率的视语力融合整机论文。

### T5 强化学习机器人控制

**是什么**：强化学习机器人控制指用 RL/模仿学习、sim-to-real、奖励与课程设计训练控制策略。

**高校学术代表性进展**：
- [CN-001] 清华 Humanoid-Gym：Isaac Gym 人形 RL 训练框架，零样本部署 XBot 真机
- [INTL-015] ETH'数分钟学会走路'：单工作站并行数千环境，IsaacGym 范式先驱（CoRL 2021）
- [INTL-020] Google sim-to-real 四足敏捷步态经典（ICRA 2018）
- [CN-025] 上交 Keep on Going 选择性对抗训练，G1 地形穿越成功率 +40%（AAAI 2026）
- [CN-007] 清华把真机视觉不确定性纳入 RL，球位误差降 46%，支撑 RoboCup 蝉联冠军（Science Robotics）

**企业工程落地代表性进展**：
- [ENT-018] 众擎官方披露运控团队攻克 Sim2Real 并形成独特壁垒
- [ENT-027] 智元 AgiBot World：约 100 万条/2976 小时真机操作数据+GO-1 基础策略
- [ENT-011] 王兴兴预研让 AI 自动检索论文/编写控制代码在仿真闭环迭代的自进化体系

**趋势小结**：大规模并行仿真+域随机化+课程学习成熟，热点转向鲁棒对抗训练、人在环纠偏与自进化数据闭环。

### T6 机器人感知与执行联动

**是什么**：机器人感知与执行联动指 perception-action 闭环、抓取/灵巧操作与整机场景落地。

**高校学术代表性进展**：
- [INTL-016] Diffusion Policy：视觉运动策略建模为动作扩散，12 任务平均较 SOTA +46.9%
- [INTL-021] ALOHA Unleashed：大数据+Diffusion Policy 学会双臂可变形物灵巧操作
- [INTL-026] CMU RaC：人在环恢复/纠正，长时程双臂任务以 10 倍更少数据超 SOTA
- [CN-015] 北大 Imagine2Act：先想象目标再动手，Franka 6 任务 0.68（基线 0.43，ICRA 2026）
- [CN-011] 北大 RoboMIND：10.7 万条轨迹多本体操作数据集（RSS 2025）

**企业工程落地代表性进展**：
- [ENT-009/010] 宇树 Dex1-1 力控灵巧手（5~120N）完成开可乐、砸核桃、烙铁焊接
- [ENT-026] Figure F.03 进驻宝马工厂，官方称 Figure 02 上一年参与 3 万辆汽车装配
- [ENT-021] 众擎以 SA01/SE01/PM01 硬件开源+算法平台落地教育/娱乐/医疗

**趋势小结**：高校产出扩散策略、模仿学习与数据集；企业把整机推入工厂产线与开放平台，从演示走向量产。

## 3. 高校学术研究成果

### 3.1 清华大学

#### CN-001 Humanoid-Gym: Reinforcement Learning for Humanoid Robot with Zero-Shot Sim2Real Transfer（Humanoid-Gym：面向人形机器人零样本 Sim2Real 迁移的强化学习框架）
- 团队：清华大学交叉信息研究院（IIIS）陈建宇研究组（Xinyang Gu, Yen-Jen Wang, Jianyu Chen）；联合星动纪元（RobotEra）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2024-04
- 主题标签：T1、T5
- URL：https://arxiv.org/abs/2404.05695
- 中文要点：基于 NVIDIA Isaac Gym 构建的易用型人形机器人 RL 训练框架，强调零样本从仿真到真实的迁移，并集成 Isaac Gym→MuJoCo 的 sim-to-sim 校验以验证策略鲁棒性。在星动纪元 XBot-S（1.2 m）与 XBot-L（1.65 m）真机上完成零样本部署，开源了代码与项目主页。该工作是国内人形足式 RL 领域被广泛引用的开源基线之一。
- 可信度备注：arXiv:2404.05695；标注为 ICRA 2024 Workshop on Agile Robotics 收录。

#### CN-002 Advancing Humanoid Locomotion: Mastering Challenging Terrains with Denoising World Model Learning（基于去噪世界模型学习攻克复杂地形的人形机器人运动控制，简称 DWL）
- 团队：清华大学交叉信息研究院陈建宇研究组（Xinyang Gu, Yen-Jen Wang…Jianyu Chen）；上海期智研究院、星动纪元联合
- 资料类型：论文（会议论文）
- 发布时间：2024-08
- 主题标签：T1、T5
- URL：https://arxiv.org/abs/2408.14472
- 中文要点：提出端到端强化学习框架 DWL（去噪世界模型学习），用于人形机器人运动控制，号称全球首个在野外真实雪地、坡道、上下楼梯、极不平整地形上统一运行同一神经网络策略、并实现零样本 sim-to-real 的人形机器人，解决真实世界噪声扰动下的复杂地形适应性。
- 可信度备注：arXiv:2408.14472；已被 Robotics: Science and Systems（RSS）2024 接收，并入选 Best Paper Award Finalist（最佳论文奖最终候选）。

#### CN-003 Booster Gym: An End-to-End Reinforcement Learning Framework for Humanoid Robot Locomotion（Booster Gym：面向人形机器人运动的端到端强化学习框架）
- 团队：清华大学自动化系赵明国团队（Yushi Wang, Penghui Chen, Xinyu Han, Feng Wu, Mingguo Zhao）
- 资料类型：论文（arXiv 预印本，开源工具库）
- 发布时间：2025-06
- 主题标签：T1、T5
- URL：https://arxiv.org/abs/2506.15132
- 中文要点：针对人形机器人运动策略从仿真到真机"落地难"，开发了覆盖"训练—部署"全流程的代码框架，集成常用 RL 训练方法、域随机化、奖励函数设计与并联结构处理。在加速进化 Booster T1 人形机器人上验证，策略可无缝迁移到真机，实现全向行走、抗扰动与地形适应，并开源作为社区工具。
- 可信度备注：arXiv:2506.15132；预印本并开源代码。

#### CN-004 Humanoid Parkour Learning（人形机器人跑酷学习）
- 团队：清华大学（Ziwen Zhuang, Shenzhe Yao, Hang Zhao 赵行）
- 资料类型：论文（会议论文）
- 发布时间：2024-06
- 主题标签：T1、T5、T6
- URL：https://arxiv.org/abs/2406.10759
- 中文要点：提出无需任何动作先验、端到端基于视觉的全身控制跑酷策略，使人形机器人可跳上 0.42 m 高台、跨越障碍与 0.8 m 间隙，野外奔跑速度达 1.8 m/s，并在室内外自主选择跑酷技能；实验还展示将上肢动作替换后可迁移到人形移动操作任务。
- 可信度备注：arXiv:2406.10759；已发表于 CoRL 2024。

#### CN-005 X-VLA: Soft-Prompted Transformer as Scalable Cross-Embodiment Vision-Language-Action Model（X-VLA：以软提示 Transformer 为可扩展跨本体视觉-语言-动作模型）
- 团队：清华大学智能产业研究院（AIR）詹仙园、王泰团队，联合上海人工智能实验室；作者含 Jinliang Zheng, Jianxiong Li…Jingjing Liu, Tai Wang, Xianyuan Zhan 等
- 资料类型：官网项目页/官方新闻（论文为 ICLR 2026）
- 发布时间：2025-10
- 主题标签：T3
- URL：https://air.tsinghua.edu.cn/info/1007/2467.htm
- 中文要点：发布全开源通用跨本体具身基座模型 X-VLA，通过为每种机器人本体引入"实体特定可学习软提示（Soft Prompt）"解决跨本体异构数据训练难题；仅 0.9 B 参数量即在 LIBERO、SIMPLER、CALVIN、RoboTwin、VLABench、NAVSIM 等五大/六大权威基准刷新纪录，并率先实现 120 分钟无辅助自主叠衣这一长时序灵巧操作。
- 可信度备注：清华 AIR 官方新闻页；论文被 ICLR 2026 接收（ICLR Proceedings 已收录 PDF），数据/代码/参数全开源。

#### CN-006 ViLa: Robotic Vision-Language Planning（ViLa：利用 GPT-4V 充当机器人大脑的视觉-语言规划）
- 团队：清华大学交叉信息研究院高阳、弋力研究组
- 资料类型：官方新闻（论文解读）
- 发布时间：2023-12
- 主题标签：T3、T4
- URL：https://iiis.tsinghua.edu.cn/info/1018/1401.htm
- 中文要点：提出 ViLa 算法，借助 GPT-4V 等视觉语言大模型，将人类高级抽象指令分解为一系列可执行底层技能；机器人基于语言指令与当前视觉观测做链式思维（CoT）推理并动态闭环规划，可完成"开柜找薯片""按图片摆寿司"等真实环境中的复杂任务，展示了 VLM 作为机器人大脑进行任务规划的早期范式。
- 可信度备注：清华 IIIS 官方新闻页（高阳/弋力课题组）；属较早的 VLM 驱动机器人规划公开工作。

#### CN-007 Learning vision-driven reactive soccer skills for humanoid robots（人形机器人视觉驱动反应式足球技能学习）
- 团队：清华大学自动化系赵明国团队（第一作者王与时，通讯赵明国）；联合字节跳动 Seed、中国农业大学工学院、清华具身智能与机器人研究院
- 资料类型：官方新闻（对应 Science Robotics 论文）
- 发布时间：2026-08
- 主题标签：T1、T5、T6
- URL：https://www.au.tsinghua.edu.cn/info/1062/4568.htm
- 中文要点：提出把真机视觉不确定性直接纳入强化学习训练回路的框架——仿真中以对抗运动先验（AMP）引导类人动作，用虚拟感知系统建模不完美本体视觉，编解码器对带噪历史观测做时序压缩并隐式估计球位，实现无动捕的抗噪"感知-动作"闭环。在 Booster T1 上，球位估计误差降低 46%、触球时间最多缩短 64%、前场射门成功率约 90%，并支撑清华火神队蝉联 RoboCup 人形组冠军。
- 可信度备注：清华自动化系官方新闻；论文发表于 Science Robotics（2026-08-19 在线，DOI: 10.1126/scirobotics.aed1152），属顶级期刊。

#### CN-008 脉冲—语言双编码贯通人工触觉系统中的快速感知与深度推理（类脑触觉感知-认知系统）
- 团队：清华大学计算机系孙富春团队，联合中国科学院北京纳米能源与系统研究所
- 资料类型：官方新闻（对应期刊论文）
- 发布时间：2026-07
- 主题标签：T4
- URL：https://www.cs.tsinghua.edu.cn/info/1088/7226.htm
- 中文要点：提出"脉冲—语言双通道"具身触觉感知与认知框架，将类脑触觉传感器、脉冲神经网络（SNN）与大语言模型相结合：通道一负责对常见物体的快速感知识别，通道二在遇到未知/异常物体时调用大模型做语义推理与深度认知，贯通了人工触觉系统的"快感知"与"慢推理"。
- 可信度备注：清华计算机系官方新闻页（2026-07-16）；成果以"脉冲-语言双通道框架"为题发表，联合中科院纳米能源所。

#### CN-009 Dribble Master: Learning Agile Humanoid Dribbling through Legged Locomotion（Dribble Master：通过足式运动学习敏捷人形带球）
- 团队：清华大学（Zhuoheng Wang, Jinyin Zhou, Qi Wu 吴祺；标注含 Tsinghua University 合作）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-05
- 主题标签：T1、T5、T6
- URL：https://arxiv.org/abs/2505.12679
- 中文要点：针对人形足球带球"既要控球又要动态平衡"的难题，提出两阶段课程学习框架：第一阶段学基础运动技能，第二阶段微调得到敏捷带球策略；并在仿真中引入虚拟相机模型模拟真机视场与感知约束，配合启发式奖励鼓励主动感知、扩大视觉范围以持续追球。策略全仿真训练后零样本迁移到真机，完成多环境灵活带球。
- 可信度备注：arXiv:2505.12679（v3, 2026-03）；预印本，含项目视频页。

### 3.2 北京大学

#### CN-010 TacThru: Simultaneous Tactile-Visual Perception for Learning Multimodal Robot Manipulation（TacThru：面向多模态机器人操作学习的同步视触觉感知）
- 团队：北京大学人工智能研究院/心理与认知科学学院朱毅鑫助理教授团队，联合北京通用人工智能研究院（BAAI）
- 资料类型：官方新闻（对应 RA-L 论文）
- 发布时间：2026-03
- 主题标签：T4、T6
- URL：https://www.ai.pku.edu.cn/info/1053/3730.htm
- 中文要点：针对视觉被遮挡、触觉尚未激活的"最后一厘米"感知断档，设计"透视皮肤（STS）"传感器——全透明弹性体+持续内部照明+关键线同心定位点，实现指尖视角下同步的视觉（接近觉）与触觉（形变/剪切）感知，追踪约 120 Hz；并提出 TacThru-UMI 模仿学习框架，把腕部视觉、指尖图像、触觉位移、本体状态经 Transformer 扩散策略融合。5 项真实任务平均成功率 85.5%，显著优于触觉基线 66.3% 与纯视觉基线 55.4%。
- 可信度备注：北大人工智能研究院官方新闻；论文已被 IEEE Robotics and Automation Letters（RA-L）接收。

#### CN-011 RoboMIND: Benchmark on Multi-embodiment Intelligence Normative Data for Robot Manipulation（RoboMIND：面向机器人操作的多本体智能规范化数据基准）
- 团队：北京大学计算机系 Shanghang Zhang（张尚航）团队及合作单位（Kun Wu, Chengkai Hou…Shanghang Zhang, Jian Tang）
- 资料类型：论文（会议论文）
- 发布时间：2024-12
- 主题标签：T3、T5、T6
- URL：https://arxiv.org/abs/2412.13877
- 中文要点：发布大规模多本体遥操作数据集 RoboMIND，含 10.7 万条示范轨迹、479 个任务、96 类物体，覆盖 Franka Panda、UR5e、AgileX 双臂及一款双灵巧手人形共 4 种本体，并含 5 千条标注原因的失败示范；配套 Isaac Sim 数字孪生环境。用多种模仿学习方法与 SOTA VLA 模型验证数据质量与泛化能力，号称统一平台上最大规模多本体遥操作数据集。
- 可信度备注：arXiv:2412.13877；已被 Robotics: Science and Systems（RSS）2025 接收（DOI: 10.15607/RSS.2025.XXI.152）。

#### CN-012 Being-0: A Humanoid Robotic Agent with Vision-Language Models and Modular Skills（Being-0：集成视觉语言模型与模块化技能库的人形智能体）
- 团队：北京大学（Haoqi Yuan…Zongqing Lu 卢宗青），联合 BAAI、BeingBeyond
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-03
- 主题标签：T2、T3
- URL：https://arxiv.org/abs/2503.12533
- 中文要点：提出分层智能体框架 Being-0：大模型（FM）负责指令理解、任务规划与推理，模块化技能库提供稳定的运动与灵巧操作底层控制；二者之间由轻量 VLM 构成的 Connector 把语言计划翻译为技能命令并动态协调移动与操作。除 FM 外所有组件可部署在低成本机载计算设备上，在带灵巧手与主动视觉的全尺寸人形机器人上实现实时长程任务。
- 可信度备注：arXiv:2503.12533（v2, 2025-05）；预印本，含项目视频页。

#### CN-013 AC-DiT: Adaptive Coordination Diffusion Transformer for Mobile Manipulation（AC-DiT：面向移动操作的自适应协调扩散 Transformer）
- 团队：北京大学计算机系多媒体信息处理国家重点实验室（Sixiang Chen…Shanghang Zhang），联合南京大学、港中文、BAAI
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-07
- 主题标签：T4、T6
- URL：https://arxiv.org/abs/2507.01961
- 中文要点：面向家庭场景语言条件下的移动操作，提出"移动底盘—机械臂"自适应协调扩散 Transformer：先用 mobility-to-body 条件提取底盘运动表征作为全身动作先验，再按感知阶段动态融合 2D 图像与 3D 点云权重（语义阶段偏 2D、空间对齐阶段偏 3D）。仿真与真机实验均验证了端到端移动操作的协调与多模态感知适配。
- 可信度备注：arXiv:2507.01961（v3）；预印本，有项目主页 ac-dit.github.io。

#### CN-014 Jetson-PI: Towards Onboard Real-Time Robot Control via Foresight-Aligned Asynchronous Inference（Jetson-PI：基于前瞻对齐异步推理的机载实时机器人控制）
- 团队：北京大学（PKU-SEC-Lab，含 Hao Dong 董豪、Meng Li 等；Zebin Yang, Qi Wang, Yunhe Wang…Hao Dong, Meng Li）
- 资料类型：论文（会议论文）
- 发布时间：2026-07
- 主题标签：T2、T3
- URL：https://arxiv.org/abs/2607.12659
- 中文要点：针对 VLA 模型在 Jetson Orin 等低功耗机载设备上推理延迟高、控制频率低的问题，提出"前瞻对齐异步校正"方法：训练轻量未来校正模块预测已提交动作后的未来环境表征以解决感知-执行错位，并用置信度调度自适应平衡 VLM 与动作专家调用，叠加 CUDA Graph 复用、GPU 驻留缓冲等系统级优化。在 Jetson Orin 上控制频率较朴素 PyTorch 提升 8.66 倍，LIBERO 平均成功率较 VLASH 高 14.8%，并真机完成叠衣任务。
- 可信度备注：arXiv:2607.12659（v5, 2026-09）；已被 CoRL 2026 接收，代码开源。

#### CN-015 Imagine2Act: Leveraging Object-Action Motion Consistency from Imagined Goals for Robotic Manipulation（Imagine2Act：利用"想象目标"中的物体-动作运动一致性做机器人操作）
- 团队：北京大学董豪课题组（主导）
- 资料类型：官方新闻（会议论文解读，原文 arXiv:2509.17125）
- 发布时间：2026-02
- 主题标签：T6
- URL：https://cfcs.pku.edu.cn/news/d9224712b17b404e96296eda2c4a54dd.htm
- 中文要点：面向插花、放盘、叠杯等关系性物体重排的高精度操作，提出"先想象、再动手"的 3D 模仿学习框架：先用图像编辑+分割+3D 重建生成与真实场景几何对齐的想象目标点云，再通过"变换 token + 软姿态一致性损失"的双重对齐把物体刚体变换信号引导到末端动作预测，避免生成噪声直接传播。RLBench 7 任务平均成功率 0.79，真机 Franka 上 6 任务平均 0.68（基线 3D Diffuser Actor 仅 0.43）。
- 可信度备注：北大前沿计算研究中心官方解读；论文发表于 ICRA 2026，原文 https://arxiv.org/abs/2509.17125 。

### 3.3 复旦大学

#### CN-016 EGM: Efficiently Learning General Motion Tracking Policy for High Dynamic Humanoid Whole-Body Control（EGM：高效学习高动态人形全身控制通用动作跟踪策略）
- 团队：复旦大学（未来信息技术学院 / 智能机器人与先进制造创新学院；Chao Yang, Yingkai Sun, Peng Ye, Xin Chen, Chong Yu, Tao Chen），联合上海创新学院
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-12
- 主题标签：T1、T5
- URL：https://arxiv.org/abs/2512.19043
- 中文要点：针对从人类动作学习人形全身动作跟踪时数据利用率低、高动态动作跟踪差的问题，提出 EGM 框架：基于动作分桶的跨动作课程自适应采样、上下身分组且正交/共享专家解耦的复合解耦 MoE（CDMoE）架构，配合三阶段课程训练。仅用 4.08 小时训练数据即可泛化到 49.25 小时测试动作，在常规与高动态任务上均优于基线。
- 可信度备注：arXiv:2512.19043（2025-12-22）；预印本。

#### CN-017 WholeBodyVLA: Towards Unified Latent VLA for Whole-Body Loco-Manipulation Control（WholeBodyVLA：面向全身移动-操作控制的统一隐空间 VLA）
- 团队：复旦大学（Haoran Jiang, Jin Chen…Hongyang Li），联合香港大学 OpenDriveLab、智元机器人（AgiBot）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-12
- 主题标签：T3、T6
- URL：https://arxiv.org/abs/2512.11047
- 中文要点：针对人形"移动-操作一体（loco-manipulation）"中大空间作业受限的问题，提出统一隐空间学习框架，让 VLA 从低成本无动作的第一视角人视频中学习 loco-manipulation 知识，并设计面向 loco-manipulation 的 RL 策略精确执行前进、转身、下蹲等核心运动。在智元 AgiBot X2 人形上验证，较前序基线提升 21.3%，号称最早实现大空间人形 loco-manipulation 的工作之一。
- 可信度备注：arXiv:2512.11047（v2, 2025-12-15）；预印本。

#### CN-018 Human2Robot: Learning Robot Actions from Paired Human-Robot Videos（Human2Robot：从配对人-机视频中学习机器人动作）
- 团队：复旦大学（Sicheng Xie, Haidong Cao…Zuxuan Wu 吴祖煊, Yu-Gang Jiang 姜育刚）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-02
- 主题标签：T5、T6
- URL：https://arxiv.org/abs/2502.16587
- 中文要点：提出把细粒度人-机对齐当作"条件视频生成"问题：构建 VR 遥操作采集的第三人称配对数据集 H&R（2600 条精确同步人/机动作片段），用视频预测模型从人类输入生成机器人视频以隐式学习机器人动力学，再解耦出动作解码器。真机实验在已见任务上高性能，并对新位置、新物体、新实例乃至新任务类别表现出显著的一次性（one-shot）泛化。
- 可信度备注：arXiv:2502.16587（v4, 2025-11）；预印本。

#### CN-019 SMAP: Self-supervised Motion Adaptation for Physically Plausible Humanoid Whole-body Control（SMAP：面向物理可信人形全身控制的自监督动作适配）
- 团队：复旦大学（Haoyu Zhao, Sixu Lin…Junting Dong 董军霆），联合新加坡国立大学 Hao Fei
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-05
- 主题标签：T1、T5
- URL：https://arxiv.org/abs/2505.19463
- 中文要点：针对人类动作重定向到人形后因运动空间异质性导致训练效率与稳定性下降的问题，提出 SMAP 全身跟踪框架：用向量量化周期自编码器（VQ periodic autoencoder）捕捉通用原子动作、把人类动作适配为物理可信的人形动作以加速收敛，再用特权教师以解耦奖励把精细模仿技能蒸馏到学生策略。仿真与真机均验证了稳定性与性能优于 SOTA。
- 可信度备注：arXiv:2505.19463（2025-05-26，15 页 11 图）；预印本。

#### CN-020 复旦机器人半马首秀：基于 PPO 的长距离人形稳定运行（"具身天工3.0"半程马拉松完赛）
- 团队：复旦大学计算与智能创新学院窦德景团队（直博生魏嘉豪领衔，本科生陈佳鹏、王镜凯）；本体为北京人形机器人创新中心"天工3.0"
- 资料类型：官方新闻（校报）
- 发布时间：2026-05
- 主题标签：T1、T5
- URL：https://news.fudan.edu.cn/2026/0523/c3586a149306/page.htm
- 中文要点：在 2026 北京亦庄人形机器人半程马拉松（21.0975 km，110 余队 300 余机器人）中，复旦团队基于通用"具身天工3.0"本体全自主参赛，以 2 小时 7 分 26 秒完赛、高校组第二。针对长距离稳定运行，从散热、步态、速度三维度出发采用 PPO 强化学习让跑姿对称接近人类，并在仿真中加入多地形与干扰训练提升环境适应性。
- 可信度备注：复旦校报官方报道（2026-05-23）；属公开赛事/工程化成果，非论文。

#### CN-021 复旦大学"光华一号"具身通用人形机器人（全自主研发，两个半月实现行走与上下肢协同）
- 团队：复旦大学工程与应用技术研究院/智能机器人研究院甘中学团队，项目执行负责人刘力政
- 资料类型：官方新闻（项目推进会/十大科技进展）
- 发布时间：2024-04
- 主题标签：T1
- URL：https://faet.fudan.edu.cn/35/92/c23814a669074/page.htm
- 中文要点："光华一号"为复旦全自主研发人形机器人，从立项、设计、制造、调试到初步实现行走功能仅历时两个半月，已可实现上下肢协同运动，成为具备基本运动能力的人形平台；并在中国人形机器人百人会人形机器人大赛/揭榜挂帅中亮相。该成果后入选复旦 2024 年度"十大科技进展"。
- 可信度备注：复旦工研院官方新闻（2024-04-16）；属高校自研硬件平台与运动能力公开进展。

#### CN-022 复旦大学 CITLab 获 ICRA 2025 四足机器人挑战赛（QRC）季军
- 团队：复旦大学智能机器人与先进制造创新学院认知与智能技术实验室（CITLab），张立华教授、翟鹏青年研究员指导
- 资料类型：官方新闻（国际竞赛成果）
- 发布时间：2025-05
- 主题标签：T1、T5、T6
- URL：https://ciram.fudan.edu.cn/32/49/c48841a733769/page.htm
- 中文要点：在 ICRA 2025（亚特兰大）期间的四足机器人挑战赛中，复旦 CITLab 首次参赛即获第三名；在使用上一代 Unitree Go1（对手多为新一代 Go2/Go2-W）的劣势下，现场解决机载电脑故障、电机线路断裂等问题，完成动态复杂地形、沙石坡地、跨越障碍等全部项目，体现系统调优、运动控制策略与任务执行全链路能力。
- 可信度备注：复旦智能机器人与先进制造创新学院官方新闻（2025-05-26）；ICRA 官方配套赛事。

#### CN-023 FRoM-W1: Towards General Humanoid Whole-Body Control with Language Instructions（FRoM-W1：用自然语言指令实现通用人形全身控制）
- 团队：复旦大学（Peng Li…Zuxuan Wu 吴祖煊, Yu-Gang Jiang 姜育刚, Xipeng Qiu 邱锡鹏），联合上海创新学院
- 资料类型：论文（arXiv 预印本，开源框架）
- 发布时间：2026-01
- 主题标签：T1、T3、T5
- URL：https://arxiv.org/abs/2601.12799
- 中文要点：开源"语言驱动人形全身运动"框架，分两阶段：H-GPT 用大规模人类数据训练语言驱动的人体全身动作生成模型（并引入思维链提升指令理解泛化），再把生成动作重定向到人形，由 H-ACT 在物理仿真中预训练并经强化学习微调，使 Unitree H1/G1 准确稳定复现。HumanML3D-X 基准动作生成表现优异，RL 微调持续提升跟踪精度与任务成功率，全框架开源。
- 可信度备注：arXiv:2601.12799（2026-01-19）；预印本，有项目主页。

### 3.4 上海交通大学（补充）

#### CN-024 H-Zero: Cross-Humanoid Locomotion Pretraining Enables Few-shot Novel Embodiment Transfer（H-Zero：跨人形机器人运动预训练实现少样本新本体迁移）
- 团队：上海交通大学（Yunfeng Lin, Yufei Xue, Yong Yu, Weinan Zhang 张伟楠），联合上海人工智能实验室、字节 Seed
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-11
- 主题标签：T1、T5
- URL：https://arxiv.org/abs/2512.00971
- 中文要点：针对人形控制器通常针对特定本体定制、每换一台机器人都要重调奖励与超参的问题，提出跨人形运动预训练流水线，在有限本体上预训练出通用基础策略，实现对新人形机器人的零样本/少样本迁移。仿真中对未见机器人可保持最长 81% 完整回合时长，对未见人形与直立四足仅需约 30 分钟微调即可完成少样本迁移。
- 可信度备注：arXiv:2512.00971（2025-11-30）；标注"under review"，预印本。

#### CN-025 Keep on Going: Learning Robust Humanoid Motion Skills via Selective Adversarial Training（Keep on Going：通过选择性对抗训练学习鲁棒人形运动技能）
- 团队：上海交通大学人工智能研究院 MoE 重点实验室（Yang Zhang…Yue Gao 高跃），联合上海创新学院、联想研究院
- 资料类型：论文（会议论文）
- 发布时间：2025-07
- 主题标签：T5
- URL：https://arxiv.org/abs/2507.08303
- 中文要点：针对 RL 运动策略在长时运行、传感/执行噪声与真实扰动下易失稳的问题，提出选择性对抗攻击鲁棒训练（SA2RT）：让对抗网络在攻击预算约束下稀疏地识别并扰动最脆弱状态/动作，暴露真实弱点而不诱导保守过拟合，通过非零和交替优化持续强化策略。在 Unitree G1 上，地形穿越成功率提升 40%、轨迹跟踪误差降低 32%，并维持长时运动能力。
- 可信度备注：arXiv:2507.08303（v3, 2025-11）；已被 AAAI 2026 接收。

#### CN-026 大模型机器人策略的异步推理与边缘部署（"让大模型大脑跑在实时控制节奏上"，ICLR/ECCV/ICCV 三连）
- 团队：上海交通大学致远学院"致远九期"王皓轩（本科 SJTU，现 UIC 博士）及合作团队
- 资料类型：官方新闻（综述 ICLR 2026 / ECCV 2026 / ICCV 2025 三篇）
- 发布时间：2026-08
- 主题标签：T2、T3
- URL：https://news.sjtu.edu.cn/zhxw/20260801/225244.html
- 中文要点：围绕"学习型机器人策略如何在真实物理世界高效稳定运行"：ICLR 2026 工作提出基于大模型的机器人策略异步推理框架，解耦推理与执行以弥合大模型推理速度与实时控制需求的鸿沟（arXiv:2601.20130）；ECCV 2026 工作提出可按环境反馈实时调整动作块长度的动态方法（arXiv:2602.21445）；ICCV 2025 工作提出高效模型量化方法，使大规模生成模型可部署到算力/内存各异的边缘设备（arXiv:2402.03666），为机器人终端智能提供基础设施。
- 可信度备注：上海交大新闻学术网官方报道（2026-08-01）；三篇分别标注被 ICLR 2026、ECCV 2026、ICCV 2025 接收，论文链接已在文中给出。

### 3.5 哈佛大学

#### INTL-001 Scaling down an insect-size microrobot, HAMR-VI into HAMR-Jr（将昆虫尺度微型机器人 HAMR-VI 缩小为 HAMR-Jr）
- 团队：Harvard Microrobotics Laboratory, Harvard John A. Paulson School of Engineering and Applied Sciences (SEAS) 与 Wyss Institute
- 资料类型：论文（arXiv 预印本，后续发表于 IROS）
- 发布时间：2020-03
- 主题标签：T1、T6
- URL：https://arxiv.org/abs/2003.03337
- 中文要点：发布 HAMR-Jr，一台 22.5 mm、320 mg 的四足微型机器人，具备 8 个独立驱动自由度，是同尺度下机械灵活性最高的腿式机器人之一；在 1–200 Hz 多种步频下以多种步态实现高速运动，最高速度达 13.91 体长/秒，并通过与更大的 HAMR-VI 对比验证了尺度律对跑步性能的预测能力。
- 可信度备注：arXiv:2003.03337（cs.RO），作者 K. Jayaram、R. J. Wood 等；经 Web of Science / IEEE 检索为 IROS 收录论文。

#### INTL-002 A springtail-inspired multimodal walking-jumping microrobot（跳虫启发的多模态行走-跳跃微型机器人）
- 团队：Harvard Microrobotics Laboratory, Harvard University（通讯作者 Robert J. Wood）
- 资料类型：期刊论文（Science Robotics）
- 发布时间：2025-02
- 主题标签：T1、T6
- URL：https://www.science.org/doi/10.1126/scirobotics.adp7854
- 中文要点：在 HAMR 四足平台上加装仿跳虫"弹尾"结构，利用形状记忆合金缓慢储能、过奇点快速释放的 latch-mediated spring actuation 实现跳跃；2.2 g、6.1 cm 长机构水平跳远距离达 1.4 m（23 倍体长），14 ms 起飞阶段高速摄像揭示了此前未记录的起飞动力学，并实现可重复定向起飞与直立着陆。
- 可信度备注：Science Robotics 第 10 卷第 99 期（2025-02-26），DOI: 10.1126/scirobotics.adp7854，同行评议期刊论文；引用 34 次。

#### INTL-003 What a Tangled Robot We Weave（我们编织出的纠结机器人：黑蠕虫启发集群软体平台）
- 团队：Harvard SEAS Designing Emergence Laboratory（PI Justin Werfel），合作 Georgia Tech Saad Bhamla、Robert J. Wood
- 资料类型：官方新闻（配套论文获 ICRA 2025 Best Paper on Mechanisms and Design）
- 发布时间：2025-07
- 主题标签：T6
- URL：https://seas.harvard.edu/news/2025/07/what-tangled-robot-we-weave
- 中文要点：受加州黑蠕虫自组织缠绕成团启发，制作约一英尺长、由合成聚合物制成的软体"虫"形单元，内部气腔加压即卷曲，多只相互缠绕成可整体运动的软体集群，可在陆地与水中移动；长期目标是研究物理纠缠作为凝聚与通信通道的集群动力学，并探索跨越间隙、攀爬建筑等应用。
- 可信度备注：Harvard SEAS 官方新闻稿；对应论文获 IEEE ICRA 2025 "Best Paper on Mechanisms and Design"。

#### INTL-004 Effective Locomotion at Multiple Stride Frequencies Using Proprioceptive Feedback on a Legged Microrobot（腿式微型机器人基于本体感受反馈实现多步频高效运动）
- 团队：Harvard Microrobotics Lab / SEAS（作者 N. Doshi, K. Jayaram, S. Kuindersma, R. J. Wood）
- 资料类型：论文（arXiv 预印本，后被 IOP Bioinspiration & Biomimetics 接收）
- 发布时间：2019-01
- 主题标签：T1、T6
- URL：https://arxiv.org/abs/1901.08715
- 中文要点：在压电驱动四足微型机器人上利用"伴生传感"实现自感知，以计算高效的 LQG 估计与控制框架在 10–50 Hz 宽步频内实现腿部轨迹位置估计（RMSE<16%）与跟踪（RMSE 16%）；在开环性能差的 10–30 Hz 自然动力学区实现高性能运动，识别出低能耗成本（3.33）与腿部滑移<10% 的高动态运动区间。
- 可信度备注：arXiv:1901.08715（cs.RO），v4 注明"Currently in review at IOP Bioinspiration and Biomimetics"。

#### INTL-005 Out of the lab and into patients' hands: Harvard Move Lab makes Reachable（走出实验室进入患者手中：Harvard Move Lab 软体可穿戴康复机器人 Reachable）
- 团队：Harvard Move Lab / Biodesign Lab, SEAS（Faculty Director Conor Walsh；执行总监 Paul Sabin）
- 资料类型：官方新闻
- 发布时间：2025-01
- 主题标签：T6
- URL：https://seas.harvard.edu/news/2025/01/out-lab-and-patients-hands
- 中文要点：介绍软体可穿戴机器人 Reachable——一件轻量化背心式装置，腋下内置可充放气囊并配传感器追踪用户运动、自适应调整支撑力，面向脑卒中后上肢运动障碍患者居家康复；已在 Mass General Hospital 合作下对 30 余名患者测试，获 NSF Convergence Accelerator 三年 500 万美元资助推进产业化。
- 可信度备注：Harvard SEAS 官方新闻稿（2025-01-22），含项目负责人与资助信息，属官方技术转化进展。

#### INTL-006 MIMIC-MJX: Neuromechanical Emulation of Animal Behavior（MIMIC-MJX：动物行为的神经力学仿真框架）
- 团队：Harvard University Department of Organismic and Evolutionary Biology、Center for Brain Science、Kempner Institute（一作 Charles Y. Zhang；合作 Salk、UCSD、MIT 等）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-11
- 主题标签：T1、T5
- URL：https://arxiv.org/abs/2511.20532
- 中文要点：提出在物理仿真中训练神经控制器，驱动动物生物力学模型复现真实运动学轨迹的框架 MIMIC-MJX，用于从运动学数据反演神经运动控制策略；实现精度高、速度快，可在少量运动数据下泛化到多种动物身体模型，可用于建模运动控制策略与仿真行为实验。
- 可信度备注：arXiv:2511.20532（q-bio.NC / cs.RO），v3（2026-08）；跨机构合作，Harvard OEB 为主要单位。

#### INTL-007 IMPACT: Learning Internal-Model Predictive Control for Forceful Robotic Manipulation（IMPACT：学习内模型预测控制以实现用力型机器人操作）
- 团队：Harvard University（Jiawei Gao, Chaoqi Liu, Peilin Wu, Haonan Chen, Yilun Du；Haonan Chen 兼 Stanford）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2026-06
- 主题标签：T6、T4
- URL：https://arxiv.org/abs/2606.10818
- 中文要点：针对用力型操作（使用不同重量工具、搬运不同质量物体、擦桌等接触丰富任务），将任务规划与基于内模型的预测控制解耦；内模型快速预测外部负载并以前馈补偿消除负载，避免了对腕部力/触觉传感器的依赖；仿真与真机实验显示对未见物体重量泛化更好、成功率更高，且更安全节能。
- 可信度备注：arXiv:2606.10818（cs.RO），2026-06-09 提交；HTML 版作者单位栏明确标注 Harvard University。

#### INTL-008 Soft robot helps the heart beat（软体机器人辅助心脏搏动）
- 团队：Harvard SEAS + Wyss Institute + Boston Children's Hospital（一作 Ellen T. Roche，通讯 Conor Walsh）
- 资料类型：官方新闻（对应 Science Translational Medicine 论文）
- 发布时间：2025-10（页面日期；原研究发表于 Science Translational Medicine）
- 主题标签：T6
- URL：https://cns.fas.harvard.edu/soft-robot-helps-the-heart-beat/
- 中文要点：开发可定制的超薄硅胶软体袖套，内置气动人工肌肉环绕心脏，模仿哺乳动物心脏外层肌肉层扭转与压缩，与心跳同步辅助心衰心脏；不直接接触血液，降低血栓风险并免除抗凝药；可按患者左右心衰弱差异定制作动器、随病情调整压力，已在动物模型上验证。
- 可信度备注：Harvard CNS 官方新闻稿；原论文发表于 Science Translational Medicine（同行评议期刊）；Harvard OTD 已提交专利申请。

#### INTL-009 On-body textile hysteresis estimation for personalized physical human-robot interaction（基于在体织物滞后估计的个性化人-机器人物理交互）
- 团队：Harvard Biodesign Lab（C. M. McCann, K. Bertoldi, C. J. Walsh 等）
- 资料类型：论文（IJRR，收录于实验室出版物页）
- 发布时间：2025
- 主题标签：T6
- URL：https://biodesign.seas.harvard.edu/publications/
- 中文要点：针对软体可穿戴机器人依赖织物传力、而织物迟滞导致支撑力过/欠的问题，采用 Preisach 模型从约 90 秒在体数据预测人-机耦合系统的复杂迟滞响应；在肩部辅助软体可穿戴机器人上对 12 名受试者实现平均 5.3° 的肩部抬升角跟踪精度，显著优于既往方法。
- 可信度备注：发表于 The International Journal of Robotics Research (IJRR) 2025；条目经 Harvard Biodesign Lab 官方出版物页核实。

### 3.6 其他国际高校与机构（MIT/Stanford/Berkeley/CMU/ETH/DeepMind/NVIDIA等）

#### INTL-010 RT-2: Vision-Language-Action Models Transfer Web Knowledge to Robotic Control（RT-2：视觉-语言-动作模型将网络知识迁移到机器人控制）
- 团队：Google DeepMind 等（一作 Anthony Brohan，通讯含 Chelsea Finn、Karol Hausmann 等）
- 资料类型：论文（arXiv 预印本；CoRL 2023 接收）
- 发布时间：2023-07
- 主题标签：T3
- URL：https://arxiv.org/abs/2307.15818
- 中文要点：提出将机器人动作表示为文本 token 并直接并入 VLM 训练集的通用配方，即视觉-语言-动作模型（VLA）；6k 次评估试验显示 RT-2 获得网络规模预训练带来的涌现能力——对新物体泛化、解释训练中未出现的指令、并可做链式多步推理（如找石头当临时锤子、给疲惫者选能量饮料）。
- 可信度备注：arXiv:2307.15818（cs.RO）；PMLR v229 收录为 CoRL 2023 论文；Google DeepMind 官方博客同步发布。

#### INTL-011 OpenVLA: An Open-Source Vision-Language-Action Model（OpenVLA：开源视觉-语言-动作模型）
- 团队：Stanford、UC Berkeley、Google DeepMind 等（Moo Jin Kim, Karl Pertsch, … Chelsea Finn, Sergey Levine, Dorsa Sadigh, Percy Liang）
- 资料类型：论文（arXiv 预印本；CoRL 2024）
- 发布时间：2024-06
- 主题标签：T3
- URL：https://arxiv.org/abs/2406.09246
- 中文要点：7B 参数开源 VLA，基于 Llama 2 + 融合 DINOv2 与 SigLIP 的视觉编码器，在 Open X-Embodiment 的 97 万条真机演示上训练；在 29 任务、多本体上以 7 倍更少参数比 RT-2-X（55B）绝对成功率高 16.5%，比从零训练的 Diffusion Policy 高 20.4%，并支持消费级 GPU 上 LoRA 微调与量化部署。
- 可信度备注：arXiv:2406.09246（cs.RO）；CoRL 2024 接收；权重与代码开源。

#### INTL-012 Rapid Locomotion via Reinforcement Learning（基于强化学习的快速运动）
- 团队：MIT Improbable AI Lab（G. B. Margolis, Ge Yang, … Pulkit Agrawal）
- 资料类型：会议论文（RSS 2022）
- 发布时间：2022-05
- 主题标签：T5、T1
- URL：https://arxiv.org/abs/2205.02824
- 中文要点：端到端学习控制器使 MIT Mini Cheetah 四足机器人在草地、冰面、碎石等自然地形上持续跑到 3.9 m/s 并快速转向，对扰动鲁棒；核心是速度指令自适应课程 + 在线系统辨识的 sim-to-real 迁移策略。
- 可信度备注：arXiv:2205.02824；Comments 注明 "Accepted for publication at Robotics: Science and Systems (RSS) 2022"。

#### INTL-013 GR00T N1: An Open Foundation Model for Generalist Humanoid Robots（GR00T N1：通用人形机器人开放基础模型）
- 团队：NVIDIA Research（项目负责人 Linxi "Jim" Fan、Yuke Zhu；合作 Dieter Fox 等）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-03
- 主题标签：T3
- URL：https://arxiv.org/abs/2503.14734
- 中文要点：开放人形机器人 VLA 基础模型，采用双系统架构——System 2（视觉-语言模块）解读环境与指令，System 1（扩散 Transformer）实时生成流畅运动动作，二者端到端联合训练；训练数据混合真机轨迹、人类视频与合成数据，在多本体仿真基准上优于模仿学习基线，并部署到 Fourier GR-1 人形机器人完成语言引导的双臂操作。
- 可信度备注：arXiv:2503.14734（cs.RO），2025-03；NVIDIA 官方发布，开源模型权重。

#### INTL-014 Parkour in the Wild: Learning a General and Extensible Agile Locomotion Policy Using Multi-expert Distillation and RL Fine-tuning（野外跑酷：多专家蒸馏 + RL 微调学习通用可扩展敏捷运动策略）
- 团队：ETH Zurich Robotic Systems Lab（Nikita Rudin, Marco Hutter）；与 NVIDIA 合作
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-05
- 主题标签：T5、T1
- URL：https://arxiv.org/abs/2505.11164
- 中文要点：先为不同地形训练专用专家策略，再用 DAgger 蒸馏成统一基础策略，最后在含真实 3D 扫描的更宽地形集上 RL 微调；策略以深度图为外部感知输入，在 ANYmal D 真机上跨越楼梯、窄梁、间隙等复杂地形，将多地形技能合成进单一控制器。
- 可信度备注：arXiv:2505.11164（cs.RO）；ETH RSL 与 NVIDIA Switzerland 联合工作。

#### INTL-015 Learning to Walk in Minutes Using Massively Parallel Deep Reinforcement Learning（用大规模并行深度强化学习数分钟学会走路）
- 团队：ETH Zurich Robotic Systems Lab（N. Rudin, D. Hoeller, P. Reist, M. Hutter）
- 资料类型：论文（arXiv 预印本；CoRL 2021）
- 发布时间：2021-09
- 主题标签：T5
- URL：https://arxiv.org/abs/2109.11978
- 中文要点：在单工作站 GPU 上并行数千个仿真环境训练，配合游戏化课程，使四足机器人 ANYmal 在平坦地形上 <4 分钟、不平地形上 <20 分钟即学会行走，较此前方法提速数量级；策略成功迁移到真机，代码开源。
- 可信度备注：arXiv:2109.11978（cs.RO）；为大规模并行 RL 训练 legged locomotion 的代表性工作（IsaacGym 范式先驱）。

#### INTL-016 Diffusion Policy: Visuomotor Policy Learning via Action Diffusion（Diffusion Policy：基于动作扩散的视觉运动策略学习）
- 团队：Stanford（Chelsea Finn 组）、Columbia（Eric Cousineau、Shuran Song）、MIT（Russ Tedrake）等
- 资料类型：期刊扩展版（原 RSS 2023）
- 发布时间：2023-03
- 主题标签：T6、T5
- URL：https://arxiv.org/abs/2303.04137
- 中文要点：将机器人视觉运动策略建模为条件去噪扩散过程，通过一系列 Langevin 动力学步骤迭代优化动作；在 4 个操作基准的 12 个任务上平均比此前 SOTA 提升 46.9%，天然处理多模态动作分布、适合高维动作空间且训练稳定。
- 可信度备注：arXiv:2303.04137（cs.RO）；Comments 注明"An extended journal version of the original RSS2023 paper"。

#### INTL-017 Humanoid-VLA: Towards Universal Humanoid Control with Visual Integration（Humanoid-VLA：视觉集成的通用人形控制）
- 团队：学术团队（P. Ding, … D. Wang 等；用户指定对照条目）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-02
- 主题标签：T3
- URL：https://arxiv.org/abs/2502.14795
- 中文要点：面向人形机器人的 VLA 框架，先用非第一人称人体运动数据配文本做"语言-运动预对齐"，再用参数高效的视频条件微调引入第一人称视觉上下文，并以自监督把运动序列自动转成问答对以利用大规模无标注视频；在全身控制架构上实现物体交互与环境探索。
- 可信度备注：arXiv:2502.14795（cs.RO），2025-02；arXiv 预印本，尚未标注会议接收。

#### INTL-018 Learning to Identify Object Instances by Touch: Tactile Recognition via Multimodal Matching（通过触摸识别物体实例：基于多模态匹配的触觉识别）
- 团队：UC Berkeley（Sergey Levine 组）与 Google（R. Calandra）等（J. Lin, R. Calandra, S. Levine）
- 资料类型：会议论文（ICRA 2019）
- 发布时间：2019-03
- 主题标签：T4
- URL：https://arxiv.org/abs/1903.03591
- 中文要点：把触觉实例识别建模为"视觉-触觉是否对应同一物体"的多模态匹配问题，机器人双指各装 GelSight 触觉传感器，自监督采集 98 个物体的触觉与图像数据；仅凭触觉即可准确识别物体实例（含训练未见的新物体），并在该任务上超过人类志愿者。
- 可信度备注：arXiv:1903.03591；Comments 注明"accepted to IEEE ICRA 2019"。

#### INTL-019 Learning to Jump from Pixels（从像素学习跳跃）
- 团队：MIT Improbable AI Lab（G. B. Margolis, Pulkit Agrawal 等，基于 Mini Cheetah 平台）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2021-10
- 主题标签：T5、T6
- URL：https://arxiv.org/abs/2110.15344
- 中文要点：针对间隙、障碍等非连续地形，提出 Depth-based Impulse Control (DIC)：用机载深度相机实时输入，以无模型深度 RL 训练高级控制器预测全身控制 WBIC 的指令，同时以显式地面反力模型优化做正则；仿真与真机验证机器人可实时跨越连续宽间隙。
- 可信度备注：arXiv:2110.15344（cs.RO）；项目页 agility.csail.mit.edu 收录。

#### INTL-020 Sim-to-Real: Learning Agile Locomotion For Quadruped Robots（Sim-to-Real：为四足机器人学习敏捷运动）
- 团队：Google Brain（Jie Tan, Tingnan Zhang, Erwin Coumans, Atil Iscen, … Vincent Vanhoucke）
- 资料类型：会议论文（ICRA 2018）
- 发布时间：2018-04
- 主题标签：T5
- URL：https://arxiv.org/abs/1804.10332
- 中文要点：用深度 RL 在物理仿真中从零学习四足小跑与疾驰两种敏捷步态，通过系统辨识改进作动器模型与延迟仿真、随机化物理环境与加扰动来缩小 reality gap；策略成功部署到真机，是 sim-to-real legged locomotion 的早期经典系统。
- 可信度备注：arXiv:1804.10332（cs.RO）；ICRA 2018 论文。

#### INTL-021 ALOHA Unleashed: A Simple Recipe for Robot Dexterity（ALOHA Unleashed：机器灵巧性的简单配方）
- 团队：Google DeepMind / Stanford（Tony Z. Zhao, Chelsea Finn, Ayzaan Wahid 等）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2024-10
- 主题标签：T6
- URL：https://arxiv.org/abs/2410.13126
- 中文要点：证明在 ALOHA 2 平台上大规模采集数据 + Diffusion Policy 等表达力强的模仿学习模型，即可学会处理可变形物体与丰富接触的双臂灵巧任务；在 5 个真机 + 3 个仿真任务上超过 SOTA 基线，且无需时序集成、直接开环执行动作块。
- 可信度备注：arXiv:2410.13126（cs.RO）；Google DeepMind 官方项目页配套。

#### INTL-022 LeVERB: Humanoid Whole-Body Control with Latent Vision-Language Instruction（LeVERB：基于隐式视觉-语言指令的人形全身控制）
- 团队：UC Berkeley（Haoru Xue, … Trevor Darrell, Koushil Sreenath, Shankar Sastry；合作 NTNU、Simon Fraser）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-06
- 主题标签：T1、T3、T5
- URL：https://arxiv.org/abs/2506.13751
- 中文要点：针对现有 VLA 依赖手工动作词表、无法胜任人形全身动态行为的问题，提出层级框架——上层 VLM 从合成运动学演示学习"隐式动作词表"，下层 RL 全身控制器消费这些隐式动词生成动力学级指令；在 150+ 任务的人形 WBC 基准上简单视觉导航零样本达 80%、总体 58.5%，比朴素层级 VLA-WBC 高 7.8 倍。
- 可信度备注：arXiv:2506.13751（cs.RO），v3（2025-09）。

#### INTL-023 Post-Train NVIDIA Cosmos 3 Edge for On-Device Robot Control（后训练 NVIDIA Cosmos 3 Edge 实现机器人端侧控制）
- 团队：NVIDIA（Technical Blog）
- 资料类型：技术博客/官方教程
- 发布时间：2026-08
- 主题标签：T2
- URL：https://developer.nvidia.com/blog/post-train-nvidia-cosmos-3-edge-for-on-device-robot-control/
- 中文要点：4B 参数 Cosmos 3 Edge 世界基础模型（含 2B Nemotron 推理器）后训练为动作策略后，可原生跑在 Jetson AGX Thor T5000 上；在 640×540、15 Hz 下每动作块约 1.53 秒生成、覆盖约 2.13 秒运动，实现无数据中心 GPU 的连续闭环控制；RoboLab 120 任务闭环成功率 22.9%。
- 可信度备注：NVIDIA 官方技术博客（2026-08-19），含可复现脚本与开源仓库。

#### INTL-024 LiteVLA-Edge: Quantized On-Device Multimodal Control for Embedded Robotics（LiteVLA-Edge：面向嵌入式机器人的量化端侧多模态控制）
- 团队：学术团队（部署导向系统论文）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2026-03
- 主题标签：T2
- URL：https://arxiv.org/abs/2603.03380
- 中文要点：面向 Jetson Orin 级硬件的全端侧 VLA 部署管线——FP32 监督式 image-to-action 微调后做 4-bit GGUF 量化，经 GPU 加速的 llama.cpp 运行时推理；在 ROS 2 感知-推理-动作管线中完全离线运行，端到端平均延迟 150.5 ms（约 6.6 Hz）。
- 可信度备注：arXiv:2603.03380（cs.RO）；arXiv 预印本，系统部署类工作。

#### INTL-025 Compliant Residual DAgger: Improving Real-World Contact-Rich Manipulation with Human Corrections（CR-DAgger：用人类纠正改进真实接触丰富操作）
- 团队：Stanford（Xiaomeng Xu, … Shuran Song）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-06
- 主题标签：T6、T4
- URL：https://arxiv.org/abs/2506.16685
- 中文要点：提出带柔顺干预接口的残差 DAgger：人类可不打断策略执行、以柔顺控制施加温和准确的增量动作纠正，并以融合力反馈/力控的残差策略学习；在翻书、皮带装配、走线、插齿轮 4 个接触丰富任务上以极少量纠正数据把基策略成功率提升 64%，优于重训与微调。
- 可信度备注：arXiv:2506.16685（cs.RO），v5（2025-12）；作者单位 Stanford University。

#### INTL-026 RaC: Robot Learning for Long-Horizon Tasks by Scaling Recovery and Correction（RaC：通过扩展恢复与纠正来学习长时程任务）
- 团队：Carnegie Mellon University Robotics Institute（Zheyuan Hu, Robyn Wu, … Zackory Erickson, Aviral Kumar）
- 资料类型：论文（arXiv 预印本）
- 发布时间：2025-09
- 主题标签：T6、T5
- URL：https://arxiv.org/abs/2509.07953
- 中文要点：在模仿学习预训练后增加"人在环干预"微调阶段——人类在即将失败时把机器人回卷到熟悉分布并提供纠正段，使策略学会重试与恢复；在挂衬衣、密封保鲜盒、打包外卖盒等双臂长时程任务上以 10 倍更少数据采集时间超过此前 SOTA，且性能随恢复动作数线性扩展。
- 可信度备注：arXiv:2509.07953（cs.RO），2025-09-09；HTML 版作者单位栏标注 Carnegie Mellon University。

#### INTL-027 Plan-Seq-Learn: Language Model Guided RL for Solving Long Horizon Robotics Tasks（PSL：语言模型引导强化学习求解长时程机器人任务）
- 团队：Carnegie Mellon University（Murtaza Dalal, Tarun Chiruvolu, Ruslan Salakhutdinov）与 Mistral AI（Devendra Chaplot）
- 资料类型：会议论文（ICLR 2024）
- 发布时间：2024-05
- 主题标签：T3、T5
- URL：https://arxiv.org/abs/2405.01534
- 中文要点：用 LLM 做高层规划、运动规划桥接抽象语言与学习到的底层控制，使 RL 策略无需预定义技能库即可从零在线学习长时程任务；在 4 个基准、最多 10 阶段的 25+ 任务上从原始视觉输入达 85%+ 成功率，超过语言型、经典型与端到端方法。
- 可信度备注：arXiv:2405.01534（cs.LG）；Comments 注明"Published at ICLR 2024"。

#### INTL-028 Variable-Friction In-Hand Manipulation for Arbitrary Objects via Diffusion-Based Imitation Learning（基于扩散模仿学习的任意物体变摩擦手内操作）
- 团队：Princeton University Electrical and Computer Engineering（Qiyang Yan, Zihan Ding, Xin Zhou, Adam J. Spiers）
- 资料类型：会议论文（ICRA 2025）
- 发布时间：2025-03
- 主题标签：T6
- URL：https://arxiv.org/abs/2503.02738
- 中文要点：用仅两根单关节手指的变摩擦手做端到端学习，扩散策略模仿学习 + 仿真与少量真机数据协同训练，2 小时 A100 训练 + 1 小时真机数据即可把多边形/非多边形任意物体精准操到任意目标位姿；平均成功率 71.3%，位姿误差 2.676 mm、1.902°，优于此前逐物体定制策略。
- 可信度备注：arXiv:2503.02738；Comments 注明"Accepted by ICRA 2025"；作者单位 Princeton ECE。

#### INTL-029 3D-ViTac: Learning Fine-Grained Manipulation with Visuo-Tactile Sensing（3D-ViTac：基于视触觉感知学习精细操作）
- 团队：UIUC（Yunzhu Li 组）与 University of Washington（Binghao Huang, Yiyue Luo 等）
- 资料类型：会议论文（CoRL 2024）
- 发布时间：2024-10
- 主题标签：T4
- URL：https://arxiv.org/abs/2410.24091
- 中文要点：为双臂灵巧操作配备每 3 mm² 一个感知单元的低成本柔性触觉传感器，将触觉与视觉融合进保留三维结构的统一 3D 表征空间，再接扩散策略模仿学习；即便低成本机器人也能精细操作，在易碎物安全交互与手内长时程任务上显著优于纯视觉策略。
- 可信度备注：arXiv:2410.24091；Comments 注明"Accepted at Conference on Robot Learning (CoRL) 2024"。

#### INTL-030 OpenPi π₀.₅ on Jetson Thor（在 Jetson Thor 上部署 Physical Intelligence OpenPi π₀.₅ VLA）
- 团队：NVIDIA Jetson AI Lab（部署 Physical Intelligence 开源 OpenPi π₀.₅ 模型）
- 资料类型：官方技术教程/项目页
- 发布时间：2026（页面最近更新 2026-07）
- 主题标签：T2
- URL：https://www.jetson-ai-lab.com/tutorials/openpi_on_thor/
- 中文要点：把 1 万+ 小时机器人数据预训练的 π₀.₅ flow-matching VLA 经 JAX→PyTorch→ONNX（FP8+NVFP4）→TensorRT 管线部署到 Jetson AGX Thor；端到端总延迟从 PyTorch BF16 的约 132 ms 降到 TensorRT FP8+NVFP4 的约 49 ms（2.7 倍加速），余弦相似度≈0.99，实现无外接 GPU 服务器的闭环机器人控制。
- 可信度备注：NVIDIA Jetson AI Lab 官方教程页（2026），含实测延迟表与可复现命令。

## 4. 企业工程落地成果

### 4.1 宇树科技 Unitree Robotics

#### ENT-001 Unitree G1 人形机器人产品页（官方参数）
- 团队：宇树科技 Unitree Robotics
- 资料类型：官网产品页
- 发布时间：日期未标注（页面持续更新，2024 年发布）
- 主题标签：T1、T2、T6
- URL：https://www.unitree.com/g1/
- 中文要点：G1 站立高约 1320mm（EDU），带电池重约 35kg，总自由度 23~43（可扩展至 45），膝关节最大扭矩 120N·m，小跑速度 >2m/s；整机由模仿学习与强化学习驱动，配力控灵巧手可完成精细操作。是宇树面向科研与量产的主力人形平台，对应 T1 运动控制、T2 端侧关节、T6 操作落地。
- 可信度备注：官方一手产品页。

#### ENT-002 Unitree G1 开发者文档（About G1，结构与机载计算）
- 团队：宇树科技 Unitree Robotics
- 资料类型：官方开发者文档
- 发布时间：日期未标注（页面更新至 2026-09）
- 主题标签：T2
- URL：https://support.unitree.com/home/en/G1_developer/
- 中文要点：开发者手册给出 G1 整机上下分体结构、单臂 5 自由度、单腿 6 自由度、腰部 1 自由度（可选扩展），并说明 G1 基础版 23 自由度配置；灵巧手数组传感器数量、腕部相机参数（1080P/60fps）等，体现端侧实时控制与感知硬件配置。
- 可信度备注：官方一手开发者文档。

#### ENT-003 Unitree H1 / H1-2 通用人形机器人产品页
- 团队：宇树科技 Unitree Robotics
- 资料类型：官网产品页
- 发布时间：日期未标注（H1 于 2023 世界机器人大会首发）
- 主题标签：T1、T2
- URL：https://www.unitree.com/h1/
- 中文要点：H1 身高约 180cm、重约 47kg，单腿 5 自由度、单臂 4（可扩展），整机 19 自由度，行走速度 3.3m/s（当时全尺寸人形纪录），峰值扭矩密度 189N·m/kg，配自研大扭矩关节电机；H1-2 升级为单腿 6、单臂 7 自由度、整机约 70kg。为国内首台能跑的全尺寸通用人形机器人。
- 可信度备注：官方一手产品页（速度/重量等亦见官方 WRC2024 新闻 https://www.unitree.com/news1/）。

#### ENT-004 Unitree Go2 四足机器人产品页
- 团队：宇树科技 Unitree Robotics
- 资料类型：官网产品页
- 发布时间：日期未标注（2023 年发布）
- 主题标签：T1、T2
- URL：https://www.unitree.com/en/go2/
- 中文要点：Go2 整机约 15kg，速度 0~2.5m/s，负载约 7kg（最大约 10kg），最大爬坡 30°、越障 15cm；配 ISS 2.0 智能跟随系统（无线矢量定位，定位精度提升 50%，遥控距离 >30m），电池 8000mAh（可选 15000mAh），起售价约 1600 美元起。是宇树消费级/科研级四足标杆。
- 可信度备注：官方一手产品页。

#### ENT-005 Unitree B2 工业级四足机器人产品页
- 团队：宇树科技 Unitree Robotics
- 资料类型：官网产品页
- 发布时间：日期未标注（2023 年发布）
- 主题标签：T1、T2
- URL：https://www.unitree.com/mobile/b2/
- 中文要点：B2 最大奔跑速度 >6m/s，最大关节扭矩约 360N·m（关节性能较上代提升 170%），最远跳跃 >1.6m，站立负载 ≥120kg、连续行走负载 >40kg，越障 40cm、爬坡 >45°，无载连续行走 >5h/>20km；采用自研新关节电机，面向工业巡检/配送场景。
- 可信度备注：官方一手产品页。

#### ENT-006 宇树科技公司介绍（全栈自研核心零部件与专利规模）
- 团队：宇树科技 Unitree Robotics
- 资料类型：官网公司页
- 发布时间：日期未标注（页面更新至 2026-09）
- 主题标签：T2
- URL：https://www.unitree.com/operate/company/
- 中文要点：官方自述全自研电机、减速器、控制器、激光雷达等关键零部件与高性能感知及运动控制算法；累计申请国内外专利 200 余项、授权 180 余项，覆盖机器人核心零部件、运动控制、感知综合领域，是 T2 端侧硬件自研能力的官方背书。
- 可信度备注：官方一手（专利数量为公司自述口径）。

#### ENT-007 美国授权专利 US12584539《Integrated articulated power unit and legged robot using the same（一体化关节动力单元及足式机器人）》
- 团队：宇树科技（HangZhou YuShu Technology Co., Ltd.，发明人 Xingxing Wang 王兴兴）
- 资料类型：专利（美国发明专利授权）
- 发布时间：申请日 2022-12-14，授权公告日 2026-03-24
- 主题标签：T2
- URL：https://patents.justia.com/assignee/hangzhou-yushu-technology-co-ltd
- 中文要点：该专利公开一体化关节动力单元结构——基座内置齿轮箱单元、第一行星架与安装座同轴布置，通过隔套与输入轴承固定，形成紧凑高集成关节模组；直接对应宇树足式机器人自研关节电机/执行器的端侧硬件路线（T2）。
- 可信度备注：专利公开号 US12584539，经 Justia 受让人页核验（受让人=杭州宇树，发明人=王兴兴）。

#### ENT-008 美国授权专利 US12411198《Robot accompaniment device and four-legged robot using the same（机器人跟随装置及四足机器人）》
- 团队：宇树科技（发明人 Xingxing Wang 王兴兴）
- 资料类型：专利（美国发明专利授权）
- 发布时间：申请日 2021-11-09，授权公告日 2025-09-09
- 主题标签：T4
- URL：https://patents.justia.com/assignee/hangzhou-yushu-technology-co-ltd
- 中文要点：该专利公开带双天线定向组件的跟随装置，实现跟随者与被跟随目标间的定位定向，使机器人识别目标相对位置、朝向与转角并随行转向——对应 Go2 的 ISS 智能跟随系统，是多模态感知（定位+相对位姿）驱动整机运动的早期工程化方案。
- 可信度备注：专利公开号 US12411198，经 Justia 受让人页核验。

#### ENT-009 Unitree Dex1-1 仿生灵巧手产品页
- 团队：宇树科技 Unitree Robotics
- 资料类型：官网产品页
- 发布时间：日期未标注（页面更新至 2026-09）
- 主题标签：T6
- URL：https://www.unitree.com/Dex1-1/
- 中文要点：Dex1-1 为面向具身智能应用设计的仿生灵巧手，力控范围 5~120N，摩擦抓取负载 5kg，适配 G1/H2 人形本体；面向科研教育、快递分拣、3C 电子、工业自动化、新零售等场景，是感知-抓取-执行联动（T6）的执行器部件。
- 可信度备注：官方一手产品页。

#### ENT-010 宇树 G1 力控灵巧手精细操作演示（开可乐/砸核桃/烙铁焊接）
- 团队：宇树科技 Unitree Robotics
- 资料类型：官方新闻（WRC2024 回顾）
- 发布时间：2024-08（WRC2024）
- 主题标签：T6
- URL：https://www.unitree.com/news1/
- 中文要点：官方披露 G1 力控灵巧手可完成开可乐瓶、砸核桃甚至烙铁焊接等精细操作，并可结合 AI 持续学习优化技能；G1 量产版于 2024-08-19 正式发布。体现 T6 感知决策-灵巧操作一体的整机演示。
- 可信度备注：官方一手新闻稿。

#### ENT-011 王兴兴 WRC 2026 主题演讲《从展品到产品：人形机器人产业的下一个十年》
- 团队：宇树科技（创始人、董事长王兴兴）
- 资料类型：公开演讲（媒体转述）
- 发布时间：2026-08-20
- 主题标签：T3、T5
- URL：http://www.cnstock.com/commonDetail/764009
- 中文要点：王兴兴指出当前最大瓶颈是具身智能泛化能力不足，产业临界点是机器人在陌生环境仅凭语言指令完成约 80% 任务（预计 2~10 年）；并透露公司正预研"物理 AI 机器人自进化"体系——由大模型驱动、让 AI 自主检索论文/自动编写控制代码在仿真中闭环迭代，属企业层面 LLM 驱动机体（T3）与 sim-to-real 自进化（T5）路线的公开表述。
- 可信度备注：媒体二手报道（上海证券报·中国证券网；另见光明网 http://tech.gmw.cn/2026-08/20/content_38954217.htm 转述"物理AI自进化"）。

#### ENT-012 Unitree IM6014 仿生机器人关节电机产品页
- 团队：宇树科技 Unitree Robotics
- 资料类型：官网产品页
- 发布时间：日期未标注（页面更新至 2026-08）
- 主题标签：T2
- URL：https://www.unitree.com/IM6014/
- 中文要点：IM6014 为小体积高功率密度关节电机，重量仅 535g，采用新型定子制造工艺与高精度轴承，支持菊花链级联，定位为四足/人形/小型机械臂的高性能关节，是宇树自研执行器对外零售/配套的端侧硬件（T2）。
- 可信度备注：官方一手产品页。

### 4.2 众擎科技 EngineAI

#### ENT-013 ENGINEAI SE01 全尺寸通用人形机器人产品页
- 团队：众擎机器人 ENGINEAI（深圳众擎机器人科技股份有限公司）
- 资料类型：官网产品页
- 发布时间：日期未标注（2024-10 高交会首发）
- 主题标签：T1、T2、T4
- URL：https://www.engineai.com.cn/product-se01.html
- 中文要点：SE01 身高 170cm、常态步速 2m/s、全身 32 自由度，航空级铝材机身，行星/谐波/直线核心关节全栈自研；配 Engine Sense 视听感知系统（激光雷达+深度相机+红外）与五指灵巧手，官方称"全球首例实现拟人步态的全尺寸通用人形"，采用端到端神经网络步态方案。对应 T1 拟人步态、T2 自研关节、T4 多模态感知。
- 可信度备注：官方一手产品页。

#### ENT-014 ENGINEAI PM01 全开放通用具身智能体产品页
- 团队：众擎机器人 ENGINEAI
- 资料类型：官网产品页
- 发布时间：日期未标注（2025-02 前后发布）
- 主题标签：T1、T2
- URL：https://www.engineai.com.cn/product-pm01
- 中文要点：PM01 整机高 138cm、24 自由度、峰值扭矩密度 130N·m/kg，一体化自研关节模组峰值扭矩 130N·m，腰部可 320° 旋转；官方称完成"全球首例人形机器人前空翻"，可做跌倒自主爬起、斧头舞等高动态动作，并开放硬件底层接口与训练/部署代码（全开放平台）。售价 18.8 万元（见 product-purchase 页）。
- 可信度备注：官方一手产品页（售价见 https://www.engineai.com.cn/product-purchase ）。

#### ENT-015 ENGINEAI SA01 高拓展双足机器人（媒体披露参数）
- 团队：众擎机器人 ENGINEAI
- 资料类型：媒体报道（参数引自官方）
- 发布时间：2025-01-13
- 主题标签：T1、T2
- URL：https://www.shobserver.cn/wx/detail.do?id=843704
- 中文要点：SA01 为 2024-07 推出的首款专业级双足机器人，面向科研教育，整机约 40kg、12 个全身自由度、单腿 6 自由度，膝关节最大扭矩 160N·m、脚踝 96N·m，配自研 S160 电机，可直膝行走、单脚站立；售价约 3.85 万元、订单交付过百台。是低成本开源双足平台（T1/T2）。
- 可信度备注：媒体二手（上观新闻；参数与官方/新湖南 https://m.voc.com.cn/xhn/news/202504/28492547.html 一致）。

#### ENT-016 ENGINEAI T800 全尺寸人形机器人产品页（英文版）
- 团队：众擎机器人 ENGINEAI
- 资料类型：官网产品页
- 发布时间：日期未标注（页面更新至 2026-09）
- 主题标签：T1、T2
- URL：https://en.engineai.com.cn/product-t800
- 中文要点：T800 身高 173cm，重量约 75~85kg（依版本），小腿+大腿长 91cm，单手握 7 自由度，关节采用行星+直线力控方案、最大扭矩 450N·m，关节双绝对值编码器；电池可选三元锂（2.5h 充满）或固态电池（3h），顶配售价 80,800 美元。450N·m 膝关节支撑跑跳、回旋踢、格斗等高动态动作（T1/T2）。
- 可信度备注：官方一手产品页（450N·m 亦见人民日报海外版 http://paper.people.com.cn/rmrbhwb/pad/content/202601/20/content_30133856.html ）。

#### ENT-017 ENGINEAI JS01 强载级四足具身智能体产品页
- 团队：众擎机器人 ENGINEAI
- 资料类型：官网产品页
- 发布时间：日期未标注（页面更新至 2026-08）
- 主题标签：T1
- URL：https://www.engineai.com.cn/product-js01.html
- 中文要点：JS01 为众擎首款强载级、高机动、多领域四足机器人，负载能力高达 80kg，强调高动态高稳定响应与全向融合感知，定位多领域作业场景；体现众擎从人形向四足高负载平台的运动控制外延（T1）。
- 可信度备注：官方一手产品页。

#### ENT-018 众擎连续完成 Pre-A++ 与 A1 轮融资（官方新闻，披露 Sim2Real 技术壁垒）
- 团队：众擎机器人 ENGINEAI
- 资料类型：官方新闻稿
- 发布时间：2025-07-21
- 主题标签：T5
- URL：https://www.engineai.com.cn/about-news-media/11.html
- 中文要点：官方披露硬件本体层面全自研关节模块在爆发力、力矩、转速处于领先；算法体系中运控团队"攻克 Sim2Real 技术难关并形成独特壁垒"，高效消除仿真与物理世界的映射差距，支撑复杂舞蹈、空翻等高动态动作。这是众擎公开 RL/sim-to-real 路线（T5）的直接官方表述。
- 可信度备注：官方一手新闻稿。

#### ENT-019 全球首例人形机器人前空翻——赵同阳访谈（澎湃新闻）
- 团队：众擎机器人 ENGINEAI（创始人兼 CEO 赵同阳）
- 资料类型：公开演讲/访谈（媒体报道）
- 发布时间：2025-03-04
- 主题标签：T1、T5
- URL：https://www.thepaper.cn/newsDetail_forward_30299316
- 中文要点：赵同阳介绍 PM01 不靠助跑完成前空翻，空中需按约每千分之一秒频率协同调整 20 多个关节（空中 1 秒调整四五百次），依靠陀螺仪、动力关节与神经网络完成；翻后落地冲击对结构强度要求极高。该特技被官方称为全球首例人形前空翻，是高动态运动控制（T1）与神经网络/RL 控制（T5）的标志性演示。
- 可信度备注：媒体二手（澎湃新闻；另见人民网 http://sz.people.com.cn/n2/2025/0307/c202846-41156601.html ）。

#### ENT-020 中国授权专利《一种人形机器人起身控制的方法及人形机器人》（企查查专利公开页）
- 团队：深圳众擎机器人科技股份有限公司（发明人：赵同阳、赵玉栋、李渠、李冠达）
- 资料类型：专利（发明公布）
- 发布时间：日期未标注（页面更新至 2026-05）
- 主题标签：T1、T5
- URL：https://m.qcc.com/zhuanliDetail/350847d07909558f52b25f3bc95fbe4f.html
- 中文要点：该公开专利 IPC 分类含 G05B19/042、B25J9/16、G06N3/008、G06N20/00（机器学习/神经网络控制），指向人形机器人跌倒后起身控制方法，对应 PM01"跌倒自主爬起"功能，是众擎 RL/运动控制方向的专利布局（T1/T5）。
- 可信度备注：专利公开信息页（企查查聚合，受让人=深圳众擎，发明人含赵同阳）；建议以国家知识产权局原文为准。

#### ENT-021 众擎荣登 2025 福布斯中国 AI 科技企业 TOP 50（官方新闻）
- 团队：众擎机器人 ENGINEAI
- 资料类型：官方新闻稿
- 发布时间：2025-05-13
- 主题标签：T6
- URL：https://www.engineai.com.cn/about-news-media/27.html
- 中文要点：官方综述公司 2023-10 成立，SA01 以亲民价格打破行业壁垒、SE01 以自然步态重定义运动美学、PM01 作为开源通用人形平台广泛适配教育/娱乐/医疗等场景；反映众擎"硬件开源+算法平台"的量产与场景落地策略（T6）。
- 可信度备注：官方一手新闻稿。

#### ENT-022 对话赵同阳：人形机器人自由格斗联赛 URKL（南方+访谈）
- 团队：众擎机器人 ENGINEAI（赵同阳）
- 资料类型：公开访谈（媒体报道）
- 发布时间：2026-08-22
- 主题标签：T1
- URL：https://www.nfnews.com/content/J3WY1VLMoz.html
- 中文要点：赵同阳解释众擎选择机器人格斗（全球人形自由格斗联赛 URKL）作为展示形态，将成熟本体与底层代码向全球开放，通过二次开发满足工业、巡检、服务等规模化场景；格斗对关节爆发力、抗冲击与实时平衡控制要求极高，是高动态运动控制（T1）的公开演示载体。
- 可信度备注：媒体二手报道（南方+）。

#### ENT-023 SE01 深圳街头行走走红、英伟达科学家点赞（多模态感知配置）
- 团队：众擎机器人 ENGINEAI
- 资料类型：媒体报道
- 发布时间：2025-01-13
- 主题标签：T4
- URL：https://www.shobserver.cn/wx/detail.do?id=843704
- 中文要点：媒体报道 SE01 在深圳街头无缆行走引发关注，整机约 55kg、32 自由度、常态 2m/s、续航约 2h；感知上配 Intel RealSense D435 深度相机、360° 激光雷达与 6 颗高清摄像头，经多层规划算法实现导航与避障，是视觉+激光+多摄融合的整机户外多模态演示（T4）。
- 可信度备注：媒体二手（上观新闻；硬件配置口径见官方/媒体，以官网为准）。

### 4.3 补充企业（Figure/智元/Boston Dynamics/Tesla）

#### ENT-024 Helix: A Vision-Language-Action Model for Generalist Humanoid Control（Figure 官方）
- 团队：Figure AI（美国）
- 资料类型：官方技术博客/新闻
- 发布时间：2025-02-20
- 主题标签：T3
- URL：https://www.figure.ai/news/helix
- 中文要点：Figure 发布自研 VLA 模型 Helix，统一感知、语言理解与学习式控制，是首个以高频率输出控制整个上半身的 VLA，采用"系统1/系统2"双系统架构，直接从像素到动作（pixels-to-actions）。是企业级 VLA 操控人形本体的标杆对照（T3）。
- 可信度备注：官方一手。

#### ENT-025 Introducing Helix 02: Full-Body Autonomy（Figure 官方）
- 团队：Figure AI（美国）
- 资料类型：官方技术博客/新闻
- 发布时间：2026-01-27
- 主题标签：T3
- URL：https://www.figure.ai/news/helix-02
- 中文要点：Helix 02 把单网络控制从上半身扩展到全身——行走、操作、平衡作为一个连续系统统一控制，是全身 VLA 自主的进阶对照（T3）。
- 可信度备注：官方一手。

#### ENT-026 F.03 Arrives at BMW（Figure 官方，产线落地）
- 团队：Figure AI（美国）
- 资料类型：官方新闻
- 发布时间：2026-06-30
- 主题标签：T6
- URL：https://www.figure.ai/news/f-03-at-bmw
- 中文要点：Figure 03 进驻宝马 Spartanburg 工厂 52 号装配与物流车间；官方称 Figure 02 上一年在宝马参与了 30,000 辆汽车装配。是人形机器人整机量产进厂（T6）的国际标杆对照。
- 可信度备注：官方一手。

#### ENT-027 AgiBot World Colosseo：大规模真机操作数据集与 GO-1 模型（智元）
- 团队：智元机器人 Agibot（联合上海 AI Lab / 港大 OpenDriveLab 等）
- 资料类型：公开论文/技术报告（PDF）
- 发布时间：2025-04（数据集论文）
- 主题标签：T5、T6
- URL：https://agibot-world.com/blog/agibot_go1.pdf
- 中文要点：AgiBot World 开源生态发布大规模真机操作数据集（约 100 万条轨迹、约 2976 小时、217 任务/87 技能/106 场景），由 100+ 台智元 G1 遥操作采集，并配套 GO-1 基础策略模型；是企业级 imitation/RL 训练数据与抓取操作（T5/T6）的对照标杆。
- 可信度备注：官方站点论文 PDF（规模口径另见 https://www.zhiyuan-robot.com/article/188/detail/80.html ）。

#### ENT-028 An Electric New Era for Atlas / Atlas' Evolution（Boston Dynamics 官方）
- 团队：Boston Dynamics（美国，现代集团）
- 资料类型：官方博客
- 发布时间：2024-04-17（全电动 Atlas 发布）
- 主题标签：T1
- URL：https://bostondynamics.com/blog/electric-new-era-for-atlas/
- 中文要点：2024-04 波士顿动力退役液压 Atlas、发布全电驱动 Atlas，以降低复杂度、降噪、提能效并面向工业部署；其跑跳/空翻/跑酷长期作为动态运动控制（T1）的国际标杆。
- 可信度备注：官方一手。

#### ENT-029 Tesla, Inc. Q2 2026 Update（Optimus 产线与神经网络）
- 团队：Tesla（特斯拉，美国）
- 资料类型：官方财报/投资者材料（SEC 文件）
- 发布时间：2026-07-22
- 主题标签：T3、T6
- URL：https://ir.tesla.com/_flysystem/s3/sec/000162828026049213/tsla-20260722-gen.pdf
- 中文要点：官方投资者材料披露 Fremont 工厂已退役 Model S/X 产线、安装第一代 Optimus 产线并即将投产，首批机体将用于"Optimus Academy"采集训练数据与功能开发；Optimus 复用 FSD 神经网络架构做视觉到动作控制。是企业级大模型/神经网络驱动机体与量产（T3/T6）的对照。
- 可信度备注：官方一手（IR/SEC 文件）。

## 5. 高校 vs 企业对比分析

| 对比维度 | 高校学术研究 | 企业工程落地 |
|---|---|---|
| 研究取向 | 偏算法/模型/基准/数据集与新原理（VLA、RL、扩散策略、触觉传感） | 偏整机、关节电机/执行器与产品化落地（人形/四足平台、量产） |
| 技术成熟度 | 多为 arXiv 预印本或会议论文，基准 SOTA，真机多为实验室验证 | 已有量产整机进厂（Figure@BMW、宇树 G1 量产版），产品参数以官网为准 |
| 开源/数据 | 高度开源：Humanoid-Gym、X-VLA、OpenVLA、RoboMIND、AgiBot World 等 | 多数闭源；众擎 PM01 开放硬件底层与训练/部署代码为少数例外 |
| 硬件与端侧 | 在 Jetson 等商用模组上做推理加速/量化/异步部署优化 | 自研关节电机/减速器/控制器（宇树专利与 IM6014、众擎全栈关节） |
| 落地场景 | 实验室、赛事（RoboCup 冠军、ICRA QRC 季军、半马）、康复/医疗科研 | 工业巡检、工厂产线、科研教育、格斗/表演等公开演示 |
| 信息来源类型 | arXiv 论文、会议论文、高校官网新闻、顶级期刊（Science Robotics/RSS/CoRL） | 官网产品页、开发者文档、专利、公开演讲/媒体访谈、投资者材料 |

## 6. 重要核实与局限

- **Humanoid-VLA（arXiv:2502.14795）归属已核实**：作者单位为西湖大学/浙江大学，仅在宇树 G1 硬件上部署，不能算作宇树科技自有 VLA 论文。
- **众擎科技无公开 arXiv 论文**：以官网产品页、专利聚合页、公开演讲与权威媒体报道替代；部分专利号来自聚合页（太平洋科技/企查查），未逐件打开国家知识产权局/Google Patents 原文，故未按已核验收录。
- **主题稀缺性**：T2 端侧自研推理芯片、T3 企业自有大模型、T4 视语力融合整机在部分机构偏稀缺。
- **参数口径**：标注「媒体报道/二手」的参数以官网为准；发布时间标注「日期未标注」者不作猜测。

## 7. 全部参考来源清单（85 条）

| 编号 | 标题 | 机构/企业 | 资料类型 | 发布时间 | URL |
|---|---|---|---|---|---|
| CN-001 | Humanoid-Gym: Reinforcement Learning for Humanoid Robot with Zero-Shot Sim2Real Transfer（Humanoid-Gym：面向人形机器人零样本 Sim2Real 迁移的强化学习框架） | 清华大学交叉信息研究院（IIIS）陈建宇研究组（Xinyang Gu, Yen-Jen Wang, Jianyu Chen）；联合星动纪元（RobotEra） | 论文（arXiv 预印本） | 2024-04 | https://arxiv.org/abs/2404.05695 |
| CN-002 | Advancing Humanoid Locomotion: Mastering Challenging Terrains with Denoising World Model Learning（基于去噪世界模型学习攻克复杂地形的人形机器人运动控制，简称 DWL） | 清华大学交叉信息研究院陈建宇研究组（Xinyang Gu, Yen-Jen Wang…Jianyu Chen）；上海期智研究院、星动纪元联合 | 论文（会议论文） | 2024-08 | https://arxiv.org/abs/2408.14472 |
| CN-003 | Booster Gym: An End-to-End Reinforcement Learning Framework for Humanoid Robot Locomotion（Booster Gym：面向人形机器人运动的端到端强化学习框架） | 清华大学自动化系赵明国团队（Yushi Wang, Penghui Chen, Xinyu Han, Feng Wu, Mingguo Zhao） | 论文（arXiv 预印本，开源工具库） | 2025-06 | https://arxiv.org/abs/2506.15132 |
| CN-004 | Humanoid Parkour Learning（人形机器人跑酷学习） | 清华大学（Ziwen Zhuang, Shenzhe Yao, Hang Zhao 赵行） | 论文（会议论文） | 2024-06 | https://arxiv.org/abs/2406.10759 |
| CN-005 | X-VLA: Soft-Prompted Transformer as Scalable Cross-Embodiment Vision-Language-Action Model（X-VLA：以软提示 Transformer 为可扩展跨本体视觉-语言-动作模型） | 清华大学智能产业研究院（AIR）詹仙园、王泰团队，联合上海人工智能实验室；作者含 Jinliang Zheng, Jianxiong Li…Jingjing Liu, Tai Wang, Xianyuan Zhan 等 | 官网项目页/官方新闻（论文为 ICLR 2026） | 2025-10 | https://air.tsinghua.edu.cn/info/1007/2467.htm |
| CN-006 | ViLa: Robotic Vision-Language Planning（ViLa：利用 GPT-4V 充当机器人大脑的视觉-语言规划） | 清华大学交叉信息研究院高阳、弋力研究组 | 官方新闻（论文解读） | 2023-12 | https://iiis.tsinghua.edu.cn/info/1018/1401.htm |
| CN-007 | Learning vision-driven reactive soccer skills for humanoid robots（人形机器人视觉驱动反应式足球技能学习） | 清华大学自动化系赵明国团队（第一作者王与时，通讯赵明国）；联合字节跳动 Seed、中国农业大学工学院、清华具身智能与机器人研究院 | 官方新闻（对应 Science Robotics 论文） | 2026-08 | https://www.au.tsinghua.edu.cn/info/1062/4568.htm |
| CN-008 | 脉冲—语言双编码贯通人工触觉系统中的快速感知与深度推理（类脑触觉感知-认知系统） | 清华大学计算机系孙富春团队，联合中国科学院北京纳米能源与系统研究所 | 官方新闻（对应期刊论文） | 2026-07 | https://www.cs.tsinghua.edu.cn/info/1088/7226.htm |
| CN-009 | Dribble Master: Learning Agile Humanoid Dribbling through Legged Locomotion（Dribble Master：通过足式运动学习敏捷人形带球） | 清华大学（Zhuoheng Wang, Jinyin Zhou, Qi Wu 吴祺；标注含 Tsinghua University 合作） | 论文（arXiv 预印本） | 2025-05 | https://arxiv.org/abs/2505.12679 |
| CN-010 | TacThru: Simultaneous Tactile-Visual Perception for Learning Multimodal Robot Manipulation（TacThru：面向多模态机器人操作学习的同步视触觉感知） | 北京大学人工智能研究院/心理与认知科学学院朱毅鑫助理教授团队，联合北京通用人工智能研究院（BAAI） | 官方新闻（对应 RA-L 论文） | 2026-03 | https://www.ai.pku.edu.cn/info/1053/3730.htm |
| CN-011 | RoboMIND: Benchmark on Multi-embodiment Intelligence Normative Data for Robot Manipulation（RoboMIND：面向机器人操作的多本体智能规范化数据基准） | 北京大学计算机系 Shanghang Zhang（张尚航）团队及合作单位（Kun Wu, Chengkai Hou…Shanghang Zhang, Jian Tang） | 论文（会议论文） | 2024-12 | https://arxiv.org/abs/2412.13877 |
| CN-012 | Being-0: A Humanoid Robotic Agent with Vision-Language Models and Modular Skills（Being-0：集成视觉语言模型与模块化技能库的人形智能体） | 北京大学（Haoqi Yuan…Zongqing Lu 卢宗青），联合 BAAI、BeingBeyond | 论文（arXiv 预印本） | 2025-03 | https://arxiv.org/abs/2503.12533 |
| CN-013 | AC-DiT: Adaptive Coordination Diffusion Transformer for Mobile Manipulation（AC-DiT：面向移动操作的自适应协调扩散 Transformer） | 北京大学计算机系多媒体信息处理国家重点实验室（Sixiang Chen…Shanghang Zhang），联合南京大学、港中文、BAAI | 论文（arXiv 预印本） | 2025-07 | https://arxiv.org/abs/2507.01961 |
| CN-014 | Jetson-PI: Towards Onboard Real-Time Robot Control via Foresight-Aligned Asynchronous Inference（Jetson-PI：基于前瞻对齐异步推理的机载实时机器人控制） | 北京大学（PKU-SEC-Lab，含 Hao Dong 董豪、Meng Li 等；Zebin Yang, Qi Wang, Yunhe Wang…Hao Dong, Meng Li） | 论文（会议论文） | 2026-07 | https://arxiv.org/abs/2607.12659 |
| CN-015 | Imagine2Act: Leveraging Object-Action Motion Consistency from Imagined Goals for Robotic Manipulation（Imagine2Act：利用"想象目标"中的物体-动作运动一致性做机器人操作） | 北京大学董豪课题组（主导） | 官方新闻（会议论文解读，原文 arXiv:2509.17125） | 2026-02 | https://cfcs.pku.edu.cn/news/d9224712b17b404e96296eda2c4a54dd.htm |
| CN-016 | EGM: Efficiently Learning General Motion Tracking Policy for High Dynamic Humanoid Whole-Body Control（EGM：高效学习高动态人形全身控制通用动作跟踪策略） | 复旦大学（未来信息技术学院 / 智能机器人与先进制造创新学院；Chao Yang, Yingkai Sun, Peng Ye, Xin Chen, Chong Yu, Tao Chen），联合上海创新学院 | 论文（arXiv 预印本） | 2025-12 | https://arxiv.org/abs/2512.19043 |
| CN-017 | WholeBodyVLA: Towards Unified Latent VLA for Whole-Body Loco-Manipulation Control（WholeBodyVLA：面向全身移动-操作控制的统一隐空间 VLA） | 复旦大学（Haoran Jiang, Jin Chen…Hongyang Li），联合香港大学 OpenDriveLab、智元机器人（AgiBot） | 论文（arXiv 预印本） | 2025-12 | https://arxiv.org/abs/2512.11047 |
| CN-018 | Human2Robot: Learning Robot Actions from Paired Human-Robot Videos（Human2Robot：从配对人-机视频中学习机器人动作） | 复旦大学（Sicheng Xie, Haidong Cao…Zuxuan Wu 吴祖煊, Yu-Gang Jiang 姜育刚） | 论文（arXiv 预印本） | 2025-02 | https://arxiv.org/abs/2502.16587 |
| CN-019 | SMAP: Self-supervised Motion Adaptation for Physically Plausible Humanoid Whole-body Control（SMAP：面向物理可信人形全身控制的自监督动作适配） | 复旦大学（Haoyu Zhao, Sixu Lin…Junting Dong 董军霆），联合新加坡国立大学 Hao Fei | 论文（arXiv 预印本） | 2025-05 | https://arxiv.org/abs/2505.19463 |
| CN-020 | 复旦机器人半马首秀：基于 PPO 的长距离人形稳定运行（"具身天工3.0"半程马拉松完赛） | 复旦大学计算与智能创新学院窦德景团队（直博生魏嘉豪领衔，本科生陈佳鹏、王镜凯）；本体为北京人形机器人创新中心"天工3.0" | 官方新闻（校报） | 2026-05 | https://news.fudan.edu.cn/2026/0523/c3586a149306/page.htm |
| CN-021 | 复旦大学"光华一号"具身通用人形机器人（全自主研发，两个半月实现行走与上下肢协同） | 复旦大学工程与应用技术研究院/智能机器人研究院甘中学团队，项目执行负责人刘力政 | 官方新闻（项目推进会/十大科技进展） | 2024-04 | https://faet.fudan.edu.cn/35/92/c23814a669074/page.htm |
| CN-022 | 复旦大学 CITLab 获 ICRA 2025 四足机器人挑战赛（QRC）季军 | 复旦大学智能机器人与先进制造创新学院认知与智能技术实验室（CITLab），张立华教授、翟鹏青年研究员指导 | 官方新闻（国际竞赛成果） | 2025-05 | https://ciram.fudan.edu.cn/32/49/c48841a733769/page.htm |
| CN-023 | FRoM-W1: Towards General Humanoid Whole-Body Control with Language Instructions（FRoM-W1：用自然语言指令实现通用人形全身控制） | 复旦大学（Peng Li…Zuxuan Wu 吴祖煊, Yu-Gang Jiang 姜育刚, Xipeng Qiu 邱锡鹏），联合上海创新学院 | 论文（arXiv 预印本，开源框架） | 2026-01 | https://arxiv.org/abs/2601.12799 |
| CN-024 | H-Zero: Cross-Humanoid Locomotion Pretraining Enables Few-shot Novel Embodiment Transfer（H-Zero：跨人形机器人运动预训练实现少样本新本体迁移） | 上海交通大学（Yunfeng Lin, Yufei Xue, Yong Yu, Weinan Zhang 张伟楠），联合上海人工智能实验室、字节 Seed | 论文（arXiv 预印本） | 2025-11 | https://arxiv.org/abs/2512.00971 |
| CN-025 | Keep on Going: Learning Robust Humanoid Motion Skills via Selective Adversarial Training（Keep on Going：通过选择性对抗训练学习鲁棒人形运动技能） | 上海交通大学人工智能研究院 MoE 重点实验室（Yang Zhang…Yue Gao 高跃），联合上海创新学院、联想研究院 | 论文（会议论文） | 2025-07 | https://arxiv.org/abs/2507.08303 |
| CN-026 | 大模型机器人策略的异步推理与边缘部署（"让大模型大脑跑在实时控制节奏上"，ICLR/ECCV/ICCV 三连） | 上海交通大学致远学院"致远九期"王皓轩（本科 SJTU，现 UIC 博士）及合作团队 | 官方新闻（综述 ICLR 2026 / ECCV 2026 / ICCV 2025 三篇） | 2026-08 | https://news.sjtu.edu.cn/zhxw/20260801/225244.html |
| INTL-001 | Scaling down an insect-size microrobot, HAMR-VI into HAMR-Jr（将昆虫尺度微型机器人 HAMR-VI 缩小为 HAMR-Jr） | Harvard Microrobotics Laboratory, Harvard John A. Paulson School of Engineering and Applied Sciences (SEAS) 与 Wyss Institute | 论文（arXiv 预印本，后续发表于 IROS） | 2020-03 | https://arxiv.org/abs/2003.03337 |
| INTL-002 | A springtail-inspired multimodal walking-jumping microrobot（跳虫启发的多模态行走-跳跃微型机器人） | Harvard Microrobotics Laboratory, Harvard University（通讯作者 Robert J. Wood） | 期刊论文（Science Robotics） | 2025-02 | https://www.science.org/doi/10.1126/scirobotics.adp7854 |
| INTL-003 | What a Tangled Robot We Weave（我们编织出的纠结机器人：黑蠕虫启发集群软体平台） | Harvard SEAS Designing Emergence Laboratory（PI Justin Werfel），合作 Georgia Tech Saad Bhamla、Robert J. Wood | 官方新闻（配套论文获 ICRA 2025 Best Paper on Mechanisms and Design） | 2025-07 | https://seas.harvard.edu/news/2025/07/what-tangled-robot-we-weave |
| INTL-004 | Effective Locomotion at Multiple Stride Frequencies Using Proprioceptive Feedback on a Legged Microrobot（腿式微型机器人基于本体感受反馈实现多步频高效运动） | Harvard Microrobotics Lab / SEAS（作者 N. Doshi, K. Jayaram, S. Kuindersma, R. J. Wood） | 论文（arXiv 预印本，后被 IOP Bioinspiration & Biomimetics 接收） | 2019-01 | https://arxiv.org/abs/1901.08715 |
| INTL-005 | Out of the lab and into patients' hands: Harvard Move Lab makes Reachable（走出实验室进入患者手中：Harvard Move Lab 软体可穿戴康复机器人 Reachable） | Harvard Move Lab / Biodesign Lab, SEAS（Faculty Director Conor Walsh；执行总监 Paul Sabin） | 官方新闻 | 2025-01 | https://seas.harvard.edu/news/2025/01/out-lab-and-patients-hands |
| INTL-006 | MIMIC-MJX: Neuromechanical Emulation of Animal Behavior（MIMIC-MJX：动物行为的神经力学仿真框架） | Harvard University Department of Organismic and Evolutionary Biology、Center for Brain Science、Kempner Institute（一作 Charles Y. Zhang；合作 Salk、UCSD、MIT 等） | 论文（arXiv 预印本） | 2025-11 | https://arxiv.org/abs/2511.20532 |
| INTL-007 | IMPACT: Learning Internal-Model Predictive Control for Forceful Robotic Manipulation（IMPACT：学习内模型预测控制以实现用力型机器人操作） | Harvard University（Jiawei Gao, Chaoqi Liu, Peilin Wu, Haonan Chen, Yilun Du；Haonan Chen 兼 Stanford） | 论文（arXiv 预印本） | 2026-06 | https://arxiv.org/abs/2606.10818 |
| INTL-008 | Soft robot helps the heart beat（软体机器人辅助心脏搏动） | Harvard SEAS + Wyss Institute + Boston Children's Hospital（一作 Ellen T. Roche，通讯 Conor Walsh） | 官方新闻（对应 Science Translational Medicine 论文） | 2025-10（页面日期；原研究发表于 Science Translational Medicine） | https://cns.fas.harvard.edu/soft-robot-helps-the-heart-beat/ |
| INTL-009 | On-body textile hysteresis estimation for personalized physical human-robot interaction（基于在体织物滞后估计的个性化人-机器人物理交互） | Harvard Biodesign Lab（C. M. McCann, K. Bertoldi, C. J. Walsh 等） | 论文（IJRR，收录于实验室出版物页） | 2025 | https://biodesign.seas.harvard.edu/publications/ |
| INTL-010 | RT-2: Vision-Language-Action Models Transfer Web Knowledge to Robotic Control（RT-2：视觉-语言-动作模型将网络知识迁移到机器人控制） | Google DeepMind 等（一作 Anthony Brohan，通讯含 Chelsea Finn、Karol Hausmann 等） | 论文（arXiv 预印本；CoRL 2023 接收） | 2023-07 | https://arxiv.org/abs/2307.15818 |
| INTL-011 | OpenVLA: An Open-Source Vision-Language-Action Model（OpenVLA：开源视觉-语言-动作模型） | Stanford、UC Berkeley、Google DeepMind 等（Moo Jin Kim, Karl Pertsch, … Chelsea Finn, Sergey Levine, Dorsa Sadigh, Percy Liang） | 论文（arXiv 预印本；CoRL 2024） | 2024-06 | https://arxiv.org/abs/2406.09246 |
| INTL-012 | Rapid Locomotion via Reinforcement Learning（基于强化学习的快速运动） | MIT Improbable AI Lab（G. B. Margolis, Ge Yang, … Pulkit Agrawal） | 会议论文（RSS 2022） | 2022-05 | https://arxiv.org/abs/2205.02824 |
| INTL-013 | GR00T N1: An Open Foundation Model for Generalist Humanoid Robots（GR00T N1：通用人形机器人开放基础模型） | NVIDIA Research（项目负责人 Linxi "Jim" Fan、Yuke Zhu；合作 Dieter Fox 等） | 论文（arXiv 预印本） | 2025-03 | https://arxiv.org/abs/2503.14734 |
| INTL-014 | Parkour in the Wild: Learning a General and Extensible Agile Locomotion Policy Using Multi-expert Distillation and RL Fine-tuning（野外跑酷：多专家蒸馏 + RL 微调学习通用可扩展敏捷运动策略） | ETH Zurich Robotic Systems Lab（Nikita Rudin, Marco Hutter）；与 NVIDIA 合作 | 论文（arXiv 预印本） | 2025-05 | https://arxiv.org/abs/2505.11164 |
| INTL-015 | Learning to Walk in Minutes Using Massively Parallel Deep Reinforcement Learning（用大规模并行深度强化学习数分钟学会走路） | ETH Zurich Robotic Systems Lab（N. Rudin, D. Hoeller, P. Reist, M. Hutter） | 论文（arXiv 预印本；CoRL 2021） | 2021-09 | https://arxiv.org/abs/2109.11978 |
| INTL-016 | Diffusion Policy: Visuomotor Policy Learning via Action Diffusion（Diffusion Policy：基于动作扩散的视觉运动策略学习） | Stanford（Chelsea Finn 组）、Columbia（Eric Cousineau、Shuran Song）、MIT（Russ Tedrake）等 | 期刊扩展版（原 RSS 2023） | 2023-03 | https://arxiv.org/abs/2303.04137 |
| INTL-017 | Humanoid-VLA: Towards Universal Humanoid Control with Visual Integration（Humanoid-VLA：视觉集成的通用人形控制） | 学术团队（P. Ding, … D. Wang 等；用户指定对照条目） | 论文（arXiv 预印本） | 2025-02 | https://arxiv.org/abs/2502.14795 |
| INTL-018 | Learning to Identify Object Instances by Touch: Tactile Recognition via Multimodal Matching（通过触摸识别物体实例：基于多模态匹配的触觉识别） | UC Berkeley（Sergey Levine 组）与 Google（R. Calandra）等（J. Lin, R. Calandra, S. Levine） | 会议论文（ICRA 2019） | 2019-03 | https://arxiv.org/abs/1903.03591 |
| INTL-019 | Learning to Jump from Pixels（从像素学习跳跃） | MIT Improbable AI Lab（G. B. Margolis, Pulkit Agrawal 等，基于 Mini Cheetah 平台） | 论文（arXiv 预印本） | 2021-10 | https://arxiv.org/abs/2110.15344 |
| INTL-020 | Sim-to-Real: Learning Agile Locomotion For Quadruped Robots（Sim-to-Real：为四足机器人学习敏捷运动） | Google Brain（Jie Tan, Tingnan Zhang, Erwin Coumans, Atil Iscen, … Vincent Vanhoucke） | 会议论文（ICRA 2018） | 2018-04 | https://arxiv.org/abs/1804.10332 |
| INTL-021 | ALOHA Unleashed: A Simple Recipe for Robot Dexterity（ALOHA Unleashed：机器灵巧性的简单配方） | Google DeepMind / Stanford（Tony Z. Zhao, Chelsea Finn, Ayzaan Wahid 等） | 论文（arXiv 预印本） | 2024-10 | https://arxiv.org/abs/2410.13126 |
| INTL-022 | LeVERB: Humanoid Whole-Body Control with Latent Vision-Language Instruction（LeVERB：基于隐式视觉-语言指令的人形全身控制） | UC Berkeley（Haoru Xue, … Trevor Darrell, Koushil Sreenath, Shankar Sastry；合作 NTNU、Simon Fraser） | 论文（arXiv 预印本） | 2025-06 | https://arxiv.org/abs/2506.13751 |
| INTL-023 | Post-Train NVIDIA Cosmos 3 Edge for On-Device Robot Control（后训练 NVIDIA Cosmos 3 Edge 实现机器人端侧控制） | NVIDIA（Technical Blog） | 技术博客/官方教程 | 2026-08 | https://developer.nvidia.com/blog/post-train-nvidia-cosmos-3-edge-for-on-device-robot-control/ |
| INTL-024 | LiteVLA-Edge: Quantized On-Device Multimodal Control for Embedded Robotics（LiteVLA-Edge：面向嵌入式机器人的量化端侧多模态控制） | 学术团队（部署导向系统论文） | 论文（arXiv 预印本） | 2026-03 | https://arxiv.org/abs/2603.03380 |
| INTL-025 | Compliant Residual DAgger: Improving Real-World Contact-Rich Manipulation with Human Corrections（CR-DAgger：用人类纠正改进真实接触丰富操作） | Stanford（Xiaomeng Xu, … Shuran Song） | 论文（arXiv 预印本） | 2025-06 | https://arxiv.org/abs/2506.16685 |
| INTL-026 | RaC: Robot Learning for Long-Horizon Tasks by Scaling Recovery and Correction（RaC：通过扩展恢复与纠正来学习长时程任务） | Carnegie Mellon University Robotics Institute（Zheyuan Hu, Robyn Wu, … Zackory Erickson, Aviral Kumar） | 论文（arXiv 预印本） | 2025-09 | https://arxiv.org/abs/2509.07953 |
| INTL-027 | Plan-Seq-Learn: Language Model Guided RL for Solving Long Horizon Robotics Tasks（PSL：语言模型引导强化学习求解长时程机器人任务） | Carnegie Mellon University（Murtaza Dalal, Tarun Chiruvolu, Ruslan Salakhutdinov）与 Mistral AI（Devendra Chaplot） | 会议论文（ICLR 2024） | 2024-05 | https://arxiv.org/abs/2405.01534 |
| INTL-028 | Variable-Friction In-Hand Manipulation for Arbitrary Objects via Diffusion-Based Imitation Learning（基于扩散模仿学习的任意物体变摩擦手内操作） | Princeton University Electrical and Computer Engineering（Qiyang Yan, Zihan Ding, Xin Zhou, Adam J. Spiers） | 会议论文（ICRA 2025） | 2025-03 | https://arxiv.org/abs/2503.02738 |
| INTL-029 | 3D-ViTac: Learning Fine-Grained Manipulation with Visuo-Tactile Sensing（3D-ViTac：基于视触觉感知学习精细操作） | UIUC（Yunzhu Li 组）与 University of Washington（Binghao Huang, Yiyue Luo 等） | 会议论文（CoRL 2024） | 2024-10 | https://arxiv.org/abs/2410.24091 |
| INTL-030 | OpenPi π₀.₅ on Jetson Thor（在 Jetson Thor 上部署 Physical Intelligence OpenPi π₀.₅ VLA） | NVIDIA Jetson AI Lab（部署 Physical Intelligence 开源 OpenPi π₀.₅ 模型） | 官方技术教程/项目页 | 2026（页面最近更新 2026-07） | https://www.jetson-ai-lab.com/tutorials/openpi_on_thor/ |
| ENT-001 | Unitree G1 人形机器人产品页（官方参数） | 宇树科技 Unitree Robotics | 官网产品页 | 日期未标注（页面持续更新，2024 年发布） | https://www.unitree.com/g1/ |
| ENT-002 | Unitree G1 开发者文档（About G1，结构与机载计算） | 宇树科技 Unitree Robotics | 官方开发者文档 | 日期未标注（页面更新至 2026-09） | https://support.unitree.com/home/en/G1_developer/ |
| ENT-003 | Unitree H1 / H1-2 通用人形机器人产品页 | 宇树科技 Unitree Robotics | 官网产品页 | 日期未标注（H1 于 2023 世界机器人大会首发） | https://www.unitree.com/h1/ |
| ENT-004 | Unitree Go2 四足机器人产品页 | 宇树科技 Unitree Robotics | 官网产品页 | 日期未标注（2023 年发布） | https://www.unitree.com/en/go2/ |
| ENT-005 | Unitree B2 工业级四足机器人产品页 | 宇树科技 Unitree Robotics | 官网产品页 | 日期未标注（2023 年发布） | https://www.unitree.com/mobile/b2/ |
| ENT-006 | 宇树科技公司介绍（全栈自研核心零部件与专利规模） | 宇树科技 Unitree Robotics | 官网公司页 | 日期未标注（页面更新至 2026-09） | https://www.unitree.com/operate/company/ |
| ENT-007 | 美国授权专利 US12584539《Integrated articulated power unit and legged robot using the same（一体化关节动力单元及足式机器人）》 | 宇树科技（HangZhou YuShu Technology Co., Ltd.，发明人 Xingxing Wang 王兴兴） | 专利（美国发明专利授权） | 申请日 2022-12-14，授权公告日 2026-03-24 | https://patents.justia.com/assignee/hangzhou-yushu-technology-co-ltd |
| ENT-008 | 美国授权专利 US12411198《Robot accompaniment device and four-legged robot using the same（机器人跟随装置及四足机器人）》 | 宇树科技（发明人 Xingxing Wang 王兴兴） | 专利（美国发明专利授权） | 申请日 2021-11-09，授权公告日 2025-09-09 | https://patents.justia.com/assignee/hangzhou-yushu-technology-co-ltd |
| ENT-009 | Unitree Dex1-1 仿生灵巧手产品页 | 宇树科技 Unitree Robotics | 官网产品页 | 日期未标注（页面更新至 2026-09） | https://www.unitree.com/Dex1-1/ |
| ENT-010 | 宇树 G1 力控灵巧手精细操作演示（开可乐/砸核桃/烙铁焊接） | 宇树科技 Unitree Robotics | 官方新闻（WRC2024 回顾） | 2024-08（WRC2024） | https://www.unitree.com/news1/ |
| ENT-011 | 王兴兴 WRC 2026 主题演讲《从展品到产品：人形机器人产业的下一个十年》 | 宇树科技（创始人、董事长王兴兴） | 公开演讲（媒体转述） | 2026-08-20 | http://www.cnstock.com/commonDetail/764009 |
| ENT-012 | Unitree IM6014 仿生机器人关节电机产品页 | 宇树科技 Unitree Robotics | 官网产品页 | 日期未标注（页面更新至 2026-08） | https://www.unitree.com/IM6014/ |
| ENT-013 | ENGINEAI SE01 全尺寸通用人形机器人产品页 | 众擎机器人 ENGINEAI（深圳众擎机器人科技股份有限公司） | 官网产品页 | 日期未标注（2024-10 高交会首发） | https://www.engineai.com.cn/product-se01.html |
| ENT-014 | ENGINEAI PM01 全开放通用具身智能体产品页 | 众擎机器人 ENGINEAI | 官网产品页 | 日期未标注（2025-02 前后发布） | https://www.engineai.com.cn/product-pm01 |
| ENT-015 | ENGINEAI SA01 高拓展双足机器人（媒体披露参数） | 众擎机器人 ENGINEAI | 媒体报道（参数引自官方） | 2025-01-13 | https://www.shobserver.cn/wx/detail.do?id=843704 |
| ENT-016 | ENGINEAI T800 全尺寸人形机器人产品页（英文版） | 众擎机器人 ENGINEAI | 官网产品页 | 日期未标注（页面更新至 2026-09） | https://en.engineai.com.cn/product-t800 |
| ENT-017 | ENGINEAI JS01 强载级四足具身智能体产品页 | 众擎机器人 ENGINEAI | 官网产品页 | 日期未标注（页面更新至 2026-08） | https://www.engineai.com.cn/product-js01.html |
| ENT-018 | 众擎连续完成 Pre-A++ 与 A1 轮融资（官方新闻，披露 Sim2Real 技术壁垒） | 众擎机器人 ENGINEAI | 官方新闻稿 | 2025-07-21 | https://www.engineai.com.cn/about-news-media/11.html |
| ENT-019 | 全球首例人形机器人前空翻——赵同阳访谈（澎湃新闻） | 众擎机器人 ENGINEAI（创始人兼 CEO 赵同阳） | 公开演讲/访谈（媒体报道） | 2025-03-04 | https://www.thepaper.cn/newsDetail_forward_30299316 |
| ENT-020 | 中国授权专利《一种人形机器人起身控制的方法及人形机器人》（企查查专利公开页） | 深圳众擎机器人科技股份有限公司（发明人：赵同阳、赵玉栋、李渠、李冠达） | 专利（发明公布） | 日期未标注（页面更新至 2026-05） | https://m.qcc.com/zhuanliDetail/350847d07909558f52b25f3bc95fbe4f.html |
| ENT-021 | 众擎荣登 2025 福布斯中国 AI 科技企业 TOP 50（官方新闻） | 众擎机器人 ENGINEAI | 官方新闻稿 | 2025-05-13 | https://www.engineai.com.cn/about-news-media/27.html |
| ENT-022 | 对话赵同阳：人形机器人自由格斗联赛 URKL（南方+访谈） | 众擎机器人 ENGINEAI（赵同阳） | 公开访谈（媒体报道） | 2026-08-22 | https://www.nfnews.com/content/J3WY1VLMoz.html |
| ENT-023 | SE01 深圳街头行走走红、英伟达科学家点赞（多模态感知配置） | 众擎机器人 ENGINEAI | 媒体报道 | 2025-01-13 | https://www.shobserver.cn/wx/detail.do?id=843704 |
| ENT-024 | Helix: A Vision-Language-Action Model for Generalist Humanoid Control（Figure 官方） | Figure AI（美国） | 官方技术博客/新闻 | 2025-02-20 | https://www.figure.ai/news/helix |
| ENT-025 | Introducing Helix 02: Full-Body Autonomy（Figure 官方） | Figure AI（美国） | 官方技术博客/新闻 | 2026-01-27 | https://www.figure.ai/news/helix-02 |
| ENT-026 | F.03 Arrives at BMW（Figure 官方，产线落地） | Figure AI（美国） | 官方新闻 | 2026-06-30 | https://www.figure.ai/news/f-03-at-bmw |
| ENT-027 | AgiBot World Colosseo：大规模真机操作数据集与 GO-1 模型（智元） | 智元机器人 Agibot（联合上海 AI Lab / 港大 OpenDriveLab 等） | 公开论文/技术报告（PDF） | 2025-04（数据集论文） | https://agibot-world.com/blog/agibot_go1.pdf |
| ENT-028 | An Electric New Era for Atlas / Atlas' Evolution（Boston Dynamics 官方） | Boston Dynamics（美国，现代集团） | 官方博客 | 2024-04-17（全电动 Atlas 发布） | https://bostondynamics.com/blog/electric-new-era-for-atlas/ |
| ENT-029 | Tesla, Inc. Q2 2026 Update（Optimus 产线与神经网络） | Tesla（特斯拉，美国） | 官方财报/投资者材料（SEC 文件） | 2026-07-22 | https://ir.tesla.com/_flysystem/s3/sec/000162828026049213/tsla-20260722-gen.pdf |

## 8. 检索未果说明

### 8.1 中国高校线

- 检索未果说明（尝试过但未能纳入的方向）
- **T2 端侧 AI / 自研推理芯片/模组**：本轮三所必保高校中，公开可核实的"机载推理芯片/模组自研"纯硬件成果极少。检索到的多为"在 Jetson Orin 等商用模组上做部署优化"（如北大 Jetson-PI、SJTU 王皓轩），而非高校自研控制 SoC/NPU。曾尝试检索"清华/北大/复旦 机器人 控制芯片 自研 推理模组 专利"，未找到三校署名、可打开核实的公开专利或芯片发布页；故 T2 仅收录 3 条（CN-013 为多模态、CN-014、CN-026），其中严格意义上的"端侧部署"为 CN-014、CN-026。
- **T4 多模态（尤其力觉/触觉）**：除已收录的北大 TacThru、清华孙富春类脑触觉外，曾检索 AdapTac（arXiv:2505.13982）、ViTacFormer（arXiv:2506.15953）、FTP-1（arXiv:2606.13102，清华+SJTU+复旦联合）等候选，但因未逐一打开核实作者单位与三校归属，未强行收录以免误标；如后续需要扩充 T4，FTP-1（触觉通用基础策略，清华孙富春/张涛团队参与）是值得二次核实的高相关条目。
- **清华 DEMOS（ICRA 2024 去中心化全身控制）、Hiking in the Wild（2601.07718）、HuB 极致平衡（2505.07294）、北大 NavSpace（ICRA 2026 空间导航）、北大 Uni-NaVid/He Wang 组、复旦 ProphRL（世界模型+RL 闭环）等**：均在搜索阶段出现且高度相关，但本轮未逐一打开 arXiv/官网页核实作者单位与发布日期，按"未核实不写入"的硬性要求暂不收录，列入后续补充清单。
- **已公开专利**：按提示在 Google Patents / 国家知识产权局方向检索三校"人形机器人 运动控制 步态"相关专利，但公开专利检索页多需交互/结果不稳定，本轮未取得可稳定打开、可核实权利人的专利条目，故本批暂无论文/技术报告/新闻以外的专利类收录。
- **复旦"第三代光华一号"RAP 音乐节奏关节柔性控制（ciram 新闻）、道通 2026 Physical AI 大赛金奖（ciram 新闻）**：页面已在搜索结果中出现，但因与已收录的 CN-021/CN-022 内容部分重叠且偏赛事/表演，未单独成条。

### 8.2 哈佛及国际线

- 检索未果说明
- **Google Patents 已公开专利**：本次检索未逐件调取 Google Patents 全文库（专利号需精确检索），仅在 Harvard 软体心脏袖套条目中记录了"Harvard OTD 已提交专利申请"这一官方表述，未给出具体公开号；如需专利级条目，需另立专项按机构/发明人检索 USPTO/Espacenet。
- **Princeton 强化学习实验室（Benjamin Eysenbach）机器人方向**：检索到其实验室主页与若干 RL 基础理论论文，但未找到一篇同时满足"面向真实机器人本体 + 已真机验证 + 可核实 URL"的公开论文条目，故未强行收录，仅以 Princeton ECE 的 INTL-028 代表 Princeton。
- **Harvard 纯"AI 学习控制"类论文稀缺**：Harvard SEAS 的 AI 机器人学习方向（如 Heng Yang 控制组）多为凸优化/感知控制理论，未检索到符合"真机 VLA/RL 操控机械本体"范式且可核实的代表作；Harvard 在本主题线的优势集中在微型机器人（HAMR/RoboBee 谱系）、软体与穿戴机器人，故 T3（大模型操控）方向无 Harvard 条目，特此说明。
- **T2 端侧主题仅 3 条**：端侧 VLA 实时部署是 2025–2026 年新兴方向，可核实且来自指定高校/企业研究院的成熟公开论文/官方页较少；除 NVIDIA 两条官方部署资源外，其余多为 2026 年新出 arXiv 预印本（如 LiteVLA-Edge），会议接收状态尚不明朗，已如实标注。
- **Humanoid-VLA（INTL-017）机构归属**：该论文作者单位未在 arXiv 摘要页完整列出，非用户指定的必列八家机构；因其被用户在 T3 主题中明确点名（"Humanoid-VLA 等"），按对照目的收录，并已在"成果归属"栏如实标注为学术团队对照条目。
- **部分 arXiv 条目（如 LiteVLA-Edge、MIMIC-MJX、IMPACT）**为预印本，尚未标注会议/期刊接收状态，已在"同行评议/可信度备注"中注明。

### 8.3 企业线

- 检索未果说明（如实记录）
- **宇树"Humanoid-VLA"归属已核实、并非宇树署名论文**：任务提示中提到的"宇树 Humanoid-VLA"经逐条核验，arXiv:2502.14795《Humanoid-VLA: Towards Universal Humanoid Control with Visual Integration》作者单位为西湖大学/浙江大学（一作 Pengxiang Ding，通讯 Donglin Wang 等，见 https://www.alphaxiv.org/overview/2502.14795v2 与 Google Scholar），论文只是在 Unitree G1 硬件上做真机部署，**不是宇树科技公司署名论文**，故未作为宇树自有 VLA 收录；仅在本说明中澄清，避免误归属。
- **宇树公司自有署名 arXiv 论文未核实到专门条目**：检索到大量"基于 Unitree G1/Go2 做实验"的高校论文（如 Berkeley、各高校 sim-to-real 工作），但作者单位非宇树；宇树官方公开的成果以官网产品页、开发者文档、专利和王兴兴公开演讲为主，未检索到宇树作为署名单位、专门发表于 arXiv 的 VLA/RL 论文。T3（企业自有 VLA）在宇树侧目前只能以王兴兴 WRC2026"物理 AI 自进化/大模型驱动"演讲作为官方表述，缺一手论文/模型权重发布。
- **众擎科技公开学术论文稀缺**：按任务预期，未检索到众擎作为署名单位的 arXiv/会议论文；其技术公开主要依赖官网产品页、官方融资新闻（披露 Sim2Real 路线）、专利（企查查/佰腾聚合页）与创始人赵同阳的公开演讲/媒体访谈。专利号（如骨骼映射拟人运动控制 CN120134329B、真实场景运动训练 CN120116237B）来自太平洋科技/企查查等聚合页，未在本次逐条打开国家知识产权局/Google Patents 原文，故未在正文中把这两个号作为已核验专利条目收录，仅以可打开的企查查起身控制专利页（ENT-020）作为代表，特此说明，未编造专利号与参数。
- **T4 多模态融合整机演示在两家中国企业侧偏薄**：宇树以 ISS 跟随专利、G1 头部/腕部相机配置为间接证据；众擎以 SE01"激光雷达+深度相机+多摄"为代表；缺两家企业公开发表的、带定量成功率的"视觉+语言+力觉"融合整机论文级演示。
- **参数口径**：众擎 SE01/T800 部分感知与续航参数来自媒体二手（上观、抖音科普等），已在条目中标注"媒体二手/以官网为准"；宇树参数均以官网产品页/开发者文档为准。所有 URL 均为本次检索真实返回页面，未访问到的方向已写入本条而非编造。
