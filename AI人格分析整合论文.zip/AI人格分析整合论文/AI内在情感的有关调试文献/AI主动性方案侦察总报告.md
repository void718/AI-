# AI 主动性方案侦察总报告
## ——让 AI 具备时间感、主动性、能自然起话头与拐弯的已有方案全景

> 侦察日期：2026-09-27
> 范围：主题A（时间感/时序感知）、主题B（主动性/自主起话）、主题C（话题漂移/自然拐弯）
> 来源四层：学术论文 / 工业方案 / 工程博客与社区 / 反面材料
> 铁律：不编造论文、repo、产品功能；区分官方说明与第三方推测；成熟度宁可低不可高。

---

## 一、方案清单表（按主题分组，组内按成熟度降序）

### 主题A：AI 的时间感 / 时序感知

**A1** = turn timing / conversation clock / response latency
**A2** = agent 生活时间线 / 自传式记忆
**A3** = time-aware dialogue / temporal grounding
**A4** = 延迟回复模拟 / typing indicator / response delay

#### 成熟度 5（已产品化、稳定复现）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| OpenAI ChatGPT Memory + Dreaming | help.openai.com/articles/8590148；Dreaming 官方公告 2026-06-04 | 产品（官方） | A2 | 后台异步进程跨对话综合记忆，随时间自动改写时态（"你七月要去"→"你七月去过"） | 5 | 机制可迁移（需后台cron+额外LLM调用），但3B做跨对话摘要质量存疑 |
| Anthropic Claude Memory Tool | docs.anthropic.com/en/docs/agents-and-tools/tool-use/memory-tool | 产品（官方API） | A2 | 记忆当作持久化文件目录，模型自己CRUD，just-in-time检索；可由宿主写入时间戳 | 5 | 完全可迁移——本地memory文件夹+每次注入"今天日期"，3B可模仿 |
| Google Gemini Memories / Memory Bank | 9to5google.com/2024/11/19/gemini-remember-saved-info；企业版 docs.cloud.google.com/gemini-enterprise-agent-platform | 产品（官方） | A2 | 用户显式"记住…"存入；企业版做extraction→consolidation去重/更新矛盾 | 5 | 可迁移（抽取-合并两阶段），但需自建向量库与去重逻辑 |
| Replika 分层记忆 | help.replika.com/hc/en-us/articles/37208679176077 | 产品（官方+第三方实测） | A2 | 可见Memory Tab存结构化事实，深层从全部对话史抽模式，weeks后可召回 | 5 | "记忆盒子+向量检索"可复刻；"深层模式"黑盒不可迁移 |
| Character.AI Pinned + Chat Memories | pocketanimus.com/guides/character-ai-memory（**第三方推测**，官方无机制文档） | 产品（第三方） | A2 | 手动pin最多15条消息常驻上下文；其余靠滚动窗口+摘要；新对话独立 | 4（功能上线但黑盒） | 完全可迁移——"置顶N条常驻system prompt"是本地最易复刻的一招 |

#### 成熟度 4（有开源实现、可直接跑）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| SillyTavern 时间宏 + World Info Timed Effects | docs.sillytavern.app/usage/core-concepts/macros/ | 开源（官方文档） | A1/A3 | prompt里写`{{time}}{{date}}{{weekday}}`由前端替换为系统时间；World Info支持sticky/cooldown/delay（按消息条数计时） | 4 | 最直接可用——前端拼时间戳进prompt即可，无需训练 |
| MemoryBank（艾宾浩斯遗忘曲线） | arxiv.org/pdf/2305.10250；github.com/zhongwanjun/MemoryBank-SiliconFriend | 论文+开源（AAAI 2024） | A2 | 每条记忆带strength，按`R(t)=e^{-t/S}`随真实时间衰减，被检索时强化；相似度+衰减共同决定注入 | 4 | 可迁移——打分公式在宿主Python算，3B只负责生成；注意第三方审查指出实现方向可能与论文相反 |
| CrewAI `inject_date: true` | docs.crewai.com/concepts/agents | 开源框架（官方） | A1/A3 | 一行配置即在prompt注入当前日期，记忆事件带`save_time_ms` | 4 | 可迁移——配置级时间注入，任何框架照抄 |
| AG2/AutoGen 按天落盘时间戳摘要 | docs.ag2.ai/latest/docs/blog/2026/03/16/AG2-Beta/ | 开源框架（官方） | A2 | 每天对话写成`YYYY-MM-DD.md`；ConversationSummaryAggregate写带时间戳摘要 | 4 | 可迁移——按日期分文件+摘要是本地轻量方案范本 |
| Rasa Duckling时间实体 + current_datetime注入 | rasa.com/docs/reference/config/components/llm-command-generators/ | 开源框架（官方） | A1/A3 | Duckling抽"明天/下周三"成slot；同时把current_datetime注入LLM模板 | 4 | 可迁移——Duckling/正则抽时间+系统时间注入是标准工程件 |
| OpenClaw Heartbeat + cron + 按日记笔记 | open-claw.org | 开源项目（MIT） | A2/A4 | 每30分钟后台心跳，agent读HEARTBEAT.md决定是否主动发消息；`memory/YYYY-MM-DD.md`记当天 | 4 | 可迁移但重——需常驻后台进程，3B可当大脑但心跳调度必须外挂 |
| CortexGraph fastMCP 时间衰减记忆 | pypi.org/project/cortexgraph-fastmcp/ | 开源（MCP server） | A2 | 记忆做成MCP server，内置类艾宾浩斯衰减，7天后score 0.210 | 4 | 可迁移——直接装包接MCP，本地模型无需自己实现衰减 |
| Tavus 2.3s延迟+typing indicator实验 | tavus.io/post/latency-of-response-in-conversational-ai | 工程博客（209人对照实验） | A4 | 有typing indicator时2.3s延迟满意度(5.62/7)与秒回(5.67/7)无差异；无indicator掉到4.40 | 4 | 可迁移——前端"正在输入…"+人为等1-2.5秒，与模型大小无关 |

#### 成熟度 3（论文级、有代码但不完整）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| Chronos 双日历时间感知 | arxiv.org/html/2603.16862v1 | 论文 | A2/A3 | 事件日历（结构化datetime区间）+轮次日历（原始对话），配合turn级稠密检索 | 3 | 思路可迁移，但多分辨率时间抽取依赖强模型，3B易漏 |
| GapChat 跨会话时间间隔感知 | arxiv.org/pdf/2310.15415v1 | 论文+数据集 | A3 | 构建多session对话数据集，相邻session时间间隔随机变化，让模型学会根据"隔了多久"决定话题有效性 | 3 | 数据/训练难迁移；但"prompt里写'距上次已过去X天'"可纯外挂 |
| Theanine 关系链记忆+时间线增强 | arxiv.org/html/2406.10996v2/ | 论文 | A2 | 不删记忆，按时间与因果关系串成链；生成时把相关记忆时间线注入上下文 | 3 | "按时间排序取最近K条"可外挂，但自动建因果图对小模型偏难 |
| Echo 带时间情景记忆 | arxiv.org/html/2502.16090v1/ | 论文 | A2 | 训练时给每段对话注入时间背景，用角色-剧情-环境三要素合成数据 | 3 | 训练侧方案，3B不重训无法获得；可借鉴"每条记忆带时间戳"格式 |
| TIMER 从"回什么"到"何时回" | arxiv.org/pdf/2506.14285v1 | 论文 | A4 | 训练模型预测合适回复时机（user-simulator生成"X分钟后回复"事件驱动数据） | 3 | 训练侧；但"情感强就快回、闲聊就延迟"的决策可用规则外挂近似 |
| Time-R1 3B量级时序推理RL | arxiv.org/html/2505.13508v2 | 论文 | A3 | 三阶段RL把3B模型练出时间理解/未来预测/时间创意 | 3 | 少数明确在3B上做的时序工作，但需RL管线，普通用户复现门槛高 |
| 超长对话记忆评测（事件图+日期） | ar5iv.labs.arxiv.org/html/2402.17753 | 论文（评测基准） | A2 | 用户生活建成带发生日期的事件图+因果边，跨度6-12个月 | 3 | 提供了自传式记忆schema（事件+日期+因果边），可直接当本地数据结构 |
| Tap-to-Adapt 语音回复时机在线学习 | arxiv.org/pdf/2603.14449 | 论文 | A1 | 用户点按/打断作在线标签，训练Dilated TCN让语音agent开口时机贴合用户节奏 | 3 | 语音向，文本陪伴参考有限；启示是"回复时机是可学习的时序信号" |
| MRTM 客服"该不该现在回"触发模型 | dl.acm.org/doi/pdf/10.1145/3394486.3403390 | 论文 | A4 | 从大规模人-人客服对话自监督学习"何时触发回复"，避免每句都回 | 3 | 可规则化——只在问句/情感句后回复，陈述性自言自语不打扰 |
| FADEMEM/Oblivion 生物启发记忆衰减 | arxiv.org/pdf/2601.18642；arxiv.org/html/2604.00131 | 论文 | A2 | 可变指数函数`v_i(t)=v_i(0)·exp(-λ_i(t-τ_i)^β_i)`按重要性差异化衰减，被召回时回弹 | 3 | 衰减公式可在宿主侧实现，比MemoryBank更细；评测/实现不完整 |

#### 成熟度 2（只有思路或demo）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| 逐条打时间戳+过期衰减补丁 | donbard.com/the-llm-time-blindness-patch/ | 工程博客 | A1/A2 | 不只在会话开头给冻结时间戳；给每条检索记忆标录入时间，按事实类型加衰减权重 | 2 | 完全可迁移，纯外挂（检索结果拼`[记录于2026-03-12]`） |
| ProactiveAgent wake→decide→respond→sleep循环 | leomariga.github.io/ProactiveAgent/；pypi.org/project/proactiveagent/0.1.1/ | 开源demo | A4 | agent按调度周期醒来，评估状态决定是否主动发消息，再算下次唤醒时间休眠 | 2 | 思路可迁移，需常驻进程；与OpenClaw心跳同思路 |
| 掘金：时间线chapters+第一人称叙事 | juejin.cn/post/7672695131032354868 | 中文工程博客 | A2 | 记忆分三轨道——碎片事实+时间线chapters+第一人称叙事；要有合并/衰减/重要性 | 2 | 时间线分章可用markdown按日期分章实现；3B做叙事化总结可行 |
| Mudguy NPC昼夜作息 | GitHub（Mudguy: AI NPC Agent System，搜索摘要） | 开源demo | A2/A4 | NPC按活跃度在不同时间"睡觉"，最后一个睡后开新一天，全员带昨日摘要醒来 | 2 | 机制简单（一天循环+摘要），本地可复刻，但属游戏NPC范式 |

---

### 主题B：AI 的主动性 / 自主起话

**B1** = proactive dialogue / topic initiation / mixed-initiative
**B2** = unprompted utterance / spontaneous turn-taking
**B3** = curiosity-driven / topic proposal
**B4** = AI companion life simulation / background activity

#### 成熟度 5（已产品化、稳定复现）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| Nomi.ai Proactive Messaging | nomi.ai/nomi-knowledge/proactive-messaging-when-your-nomi-messages-you-first/（官方知识库） | 产品（官方） | B1/B2 | 用户离开后后端定时唤醒Nomi"思考并活动"，以push主动发跟进内容，非固定模板 | 5 | 机制可迁移，但"离开期间后台思考"需常驻进程+推送通道；3B可复现"定时触发一次生成" |
| Kindroid Proactive Mode | kindroid.ai/v2/docs/chat-features-and-tools/（官方文档） | 产品（官方） | B1/B3 | 分析对话模式自动决定外联时机，可选文字/语音/自拍/电话，支持Quiet hours，显示thought bubble | 5 | 决策引擎可迁移为状态机；3B可跑"是否开口"二分类+生成，但多模态需额外管线 |
| Replika 主动通知/联系 | help.replika.com/hc/en-us/articles/360027515872（官方帮助中心） | 产品（官方） | B2 | 开启通知后全天主动推送"温柔提醒/聊天邀请"，记住之前对话使消息个人化 | 5 | 推送通道是产品壳；"个人化主动文案"可本地复现（定时取记忆→生成问候），3B短问候够用 |
| SillyTavern Idle扩展（内置） | docs.sillytavern.app/extensions/；git.durrantlab.pitt.edu/SillyTavern/Extension-Idle | 开源/前端扩展 | B2 | 用户idle一段时间后自动注入"idle prompting"，让角色自然续聊 | 5 | **完全可迁移**——前端定时器+预设prompt塞进上下文，本地任意模型可跑，最轻量主动起话实现 |
| Rasa trigger_intent「Reaching Out」 | rasa.com/docs/rasa/next/reaching-out-to-user/（官方文档） | 开源框架（官方） | B1 | 外部设备/定时任务向trigger_intent端点POST伪造user intent，bot按正常流程回复 | 5 | **完全可迁移**——"外部事件注入一条user turn"，与模型大小无关 |

#### 成熟度 4（有开源实现、可直接跑）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| Open-LLM-VTuber「AI主动说话」 | docs.llmvtuber.com/docs/intro/；配置项proactive_speak_prompt | 开源项目 | B2/B4 | idle达阈值后用独立`proactive_speak_prompt`触发一次LLM生成；支持"内心OS"（想而不说） | 4 | 原生就是本地轻量方案（支持GGUF/Ollama），3B可跑但主动语自然度明显下降 |
| Steam《AI Desktop Pet》(42kami) | store.steampowered.com/app/4227700/AI_Desktop_Pet/ | 产品 | B4 | 内置本地LLM的桌面桌宠，能看屏幕并"自己开始对话"，支持BYO GGUF | 4 | 原生支持本地GGUF，是"本地轻量+主动开口"最现成参照；视觉搭话对3B要求较高 |
| AstrBot | github.com/AstrBotDevs/AstrBot（第三方指南blog.csdn.net/cccxcmm/article/details/159720064） | 开源框架 | B1/B3 | 开源IM（微信/QQ）机器人框架，可被定时/事件触发主动向IM推送 | 4 | 可迁移——后端常驻+IM通道，LLM可换3B；但微信/QQ合规与封号风险自评估 |
| memu-py（24/7 Always-On Proactive Memory） | pypi.org/project/memu-py/ | 开源库 | B1/B3 | 面向7×24常驻agent的记忆框架，持续捕捉用户意图，无命令时预判并主动行动，主打降token成本 | 4 | 可迁移——把"常驻思考"压缩成低token事件流，3B适合轻量意图推断；需持久化状态 |
| proactiveagent（PyPI 0.1.1） | pypi.org/project/proactiveagent/0.1.1/ | 开源库 | B2 | 多因子决策引擎决定"何时开口"，动态计时响应间隔，分析对话流/参与度/紧急度 | 4 | 决策引擎是规则+小模型判断，3B足够；包很早期需自行验证 |
| ProactiveAgent（THUNLP, ICLR 2025） | arxiv.org/pdf/2410.12361v1.pdf；openreview.net/forum?id=sRIU6k2TcU | 论文+开源 | B1 | 收集真实人类活动→生成"用户可能接下来要做的任务"预测数据→训练agent无显式请求时主动提示 | 4 | 数据pipeline开源，但主动预判质量依赖大模型；3B做"活动→任务预测"偏弱 |

#### 成熟度 3（论文级、有代码但不完整）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| iPET：LLM虚拟宠物世界模拟 | aclanthology.org/2025.acl-demo.40/（ACL 2025 Demo） | 论文/系统 | B4 | 三段式世界模拟（大纲→日程→细节），用户不在线时宠物也"过日子"，回来汇报经历 | 3 | 思路可迁移——离线跑一次"日程生成"存记忆，上线念出来；3B可简化为单段日程脚本 |
| A Survey on Proactive Dialogue Systems | arxiv.org/pdf/2305.02750.pdf | 论文综述 | 全部B | 系统梳理澄清式/目标引导式/非协作式主动对话的问题定义、数据集与开放挑战 | 3 | 选型地图；其中"目标引导开放域对话"最适合本地轻量实现 |
| Proactive CoT Prompting | aclanthology.org/people/lizi-liao/（论文：Prompting and Evaluating LLMs for Proactive Dialogues） | 论文 | B1/B3（跨C） | 用"主动链思维"prompt给LLM加装目标规划能力，在推理链上主动澄清、引导话题 | 3 | **高度可迁移**——纯prompt工程，3B也能套用CoT模板，主动质量随模型能力下降 |
| Inner Thoughts 内心OS触发时机 | arxiv.org/html/2501.00383v1 | 论文 | B2/B3（跨C） | AI先产出"内心想法"再决定何时开口、说什么，区分overt/covert proactivity | 3 | 可迁移为两层prompt（先thinking再decide to speak），3B可跑但时机感弱 |
| PaRT 个性化实时检索主动社交 | arxiv.org/html/2504.20624v1（SIGIR 2025） | 论文 | B3（跨C） | LLM先精化用户意图→生成个性化话题→再用话题作query检索语料，据此主动开聊 | 3 | 可迁移——话题生成+检索是外挂组件，3B做话题生成、本地向量库做检索 |
| ComPeer 主动同伴支持 | arxiv.org/html/2407.18064v1 | 论文 | B1 | LLM检测对话中重要事件，主动规划关怀时机与内容，结合同伴支持策略与persona | 3 | 事件检测+时机规划可外挂，3B可做"是否该发关怀"轻量判断，但情感细腻度不足 |
| PIVOT 围绕用户偏好主动获取信息 | arxiv.org/html/2504.07698 | 论文 | B3 | 定义PIVOT任务，研究如何在用户偏好话题上自然主动插话获取信息，含抑制突兀发言策略 | 3 | 思路可迁移；"抑制突兀发言"约束对3B尤为重要（小模型容易硬切话题） |
| UPC Critic引导的用户导向主动 | arxiv.org/pdf/2505.12334v1.pdf | 论文 | B3（跨C） | 先训练critic评估主动发言是否贴合用户偏好，再引导对话走向 | 3 | critic是额外一次LLM调用，3B可当弱critic，但双倍token开销 |
| ProactiveEval 主动对话统一评测 | arxiv.org/html/2508.20973v1 | 论文/评测 | 全部B | 统一主动对话任务定义与指标，合成评测数据 | 3 | 不直接产生方案，但可用来评判3B主动发言质量，避免"自嗨式主动" |
| TACT 任务型与闲聊间主动切换 | aclanthology.org/2025.emnlp-main.672/（EMNLP 2025） | 论文/数据 | B1（跨C） | TACT数据集支持user-driven与agent-driven模式切换，研究bot主动在任务与闲聊间过渡 | 3 | 状态机思路可迁移——本地维护"任务/闲聊"状态，由LLM决定切换 |
| CURIO 好奇心奖励驱动多轮对话 | arxiv.org/html/2504.03206v2/ | 论文 | B3 | 把好奇心/内在动机作为user-modeling奖励信号，让LLM主动探索用户未知信息 | 3 | 纯prompt/RL思路，3B难训练奖励模型，但可简化为"每轮提一个好奇问题"模板 |
| LlamaPIE 耳戴设备主动辅助 | arxiv.org/html/2505.04066v1 | 论文 | B2 | 大部分时间沉默，只在预判用户需要时通过耳机耳语1-3词提示 | 3 | "沉默为主、极少开口"时机策略对本地轻量场景极有参考价值；硬件不可迁移 |
| CodingGenie VSCode主动编程助手 | arxiv.org/pdf/2503.14724v1.pdf | 论文/工具 | B1 | 基于代码上下文自主弹出聊天建议，可配置建议类型，分析了"主动化的成本" | 3 | "监控上下文→主动建议"事件驱动模式可迁移；成本分析（每次主动=一次LLM调用）是关键约束 |
| Pet-Bench LLM电子宠物能力基准 | arxiv.org/pdf/2506.03761v3 | 论文/基准 | B4 | 评测LLM在智能调度/记忆对话/心理对话等"宠物自我演化"任务表现，7500+实例 | 3 | 不产生方案，但给出"生活模拟"该测哪些能力的清单 |
| Long-term Task-oriented Agent 意图条件监控 | arxiv.org/html/2601.09382v1 | 论文 | B1 | agent自主根据对话历史写出触发条件，环境命中后主动找用户跟进 | 3 | "让LLM自己生成trigger condition再由定时器轮询"是工程化可迁移模式，3B可生成简单条件 |

#### 成熟度 2（只有思路或demo）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| Meta AI Studio 主动follow-up | digit.in/news/general/metas-ai-chatbots-may-soon-slide-into-your-dms（第三方报道，Meta向TechCrunch确认） | 产品（测试中） | B2 | AI Studio创建的chatbot可不经用户先发消息就主动开聊，记住之前话题后续跟进 | 2 | 仅测试无公开实现；验证了"主动follow-up"是行业共识方向 |
| 巴布机器人（心言） | 36kr.com/p/3904049563731849（36氪报道） | 产品（硬件） | B1 | 去掉唤醒词，通过面部/肢体/空间距离感知自主判断情境并主动反馈 | 2 | 多模态感知重，但"感知信号→是否开口"决策思路可迁移；3B难做实时视觉 |
| 伴里（微信小程序AI语音陪伴） | 36kr.com/p/3985517674822404（36氪报道） | 产品 | B1/B4 | AI主动问候，跨天记住用药/老友/天气等细节并自然接续 | 2 | 跨天记忆+主动问候形态可参考，小程序通道与本地部署不同 |
| Nuerogotchi（Apple Intelligence桌宠） | apps.apple.com/rs/app/nuerogotchi/id6759503329 | 产品 | B4 | 端侧Apple Intelligence驱动虚拟宠物，喂食/对话/派出去冒险，无服务器无订阅 | 2 | "端侧无服务器虚拟宠物"是本地轻量理想形态，但绑定Apple Intelligence不可直接迁移 |
| animalhouse.ai AI agent养电子宠物 | animalhouse.ai | Web产品 | B4 | agent注册后领养蛋，状态实时衰减（喂/玩/清洁/药/管教/睡/反思），宠物按照料方式演化 | 2 | 纯状态机+衰减数值，极轻量，3B完全可复现"后台过日子"机制 |

---

### 主题C：话题漂移 / 自然拐弯

**C1** = topic shift / topic drift / digression
**C2** = associative dialogue / free-association chatting
**C3** = non-sequitur handling / conversational meandering

#### 成熟度 5（已产品化、稳定复现）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| SillyTavern World Info / Lorebook | docs.sillytavern.app/usage/core-concepts/worldinfo/ | 开源产品（官方） | C2 | 维护"动态词典"，消息中出现某条目关键词时自动把对应lore片段插入prompt，使模型在新话题有料可接 | 5 | 关键词匹配极轻量；3B可跑注入逻辑，但"用不用得好"取决于底座 |
| Rasa Stories / CALM Flows + Conversation Patterns | rasa.com/docs/rasa/next/writing-stories/；rasa.com/docs/rasa/contextual-conversations/ | 开源产品（官方） | C1 | 用stories显式编写"从流程A切到插话话题、办完再切回A"路径；CALM配chitchat/search/recover等可复用pattern | 5（工程成熟，但属任务型非开放闲聊） | 状态机思路可借鉴，但Rasa整套栈重，不适合纯本地3B轻量闲聊 |

#### 成熟度 4（有开源实现、可直接跑）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| MapDia / ChMapData 记忆感知主动话题转移 | arxiv.org/abs/2503.05150；github.com/FrontierLabs/MapDia | 论文+开源 | C1 | RAG三段式：话题摘要→相关历史话题召回（排序模型）→主动漂移时机检测与生成（带CoT判断该不该切） | 4（用7B训练即A/B超GPT-4） | 3B可跑召回/摘要小模块，但"切话题时机判断+自然生成"对3B偏难 |
| Rhea 角色感知情景记忆注意力 | arxiv.org/abs/2512.06869；github.com/ddInference/Rhea | 论文+开源 | C1 | 历史拆成"指令记忆IM+情景记忆EM"，非对称噪声控制+启发式检索做优先级注意力，只把高信噪比片段塞回prompt | 4 | 工程层（记忆检索/注意力调度）可移植；"判断什么该留"仍依赖较强底座 |

#### 成熟度 3（论文级、有代码但不完整）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| CNTD 中文话题漂移检测 | arxiv.org/abs/2305.01195 | 论文 | C1（检测） | 标注1308段中文自然对话；师生知识蒸馏+层次对比学习，在"无回复"条件下预测是否漂移（BERT-base F1≈54%） | 3 | BERT-base量级极轻，可直接做"漂移检测器"外挂；只检测不生成 |
| TACT 任务↔闲聊转换感知 | aclanthology.org/2025.emnlp-main.672.pdf（EMNLP 2025） | 论文+数据集 | C1（跨B） | 构造TCT与CTC流，提出Switch与Recovery指标，训练模型主动发起并从模式切换中恢复 | 3 | 数据集可用；生成质量仍需中大型模型 |
| CANTTALKABOUTTHIS 抗干扰守话题 | arxiv.org/abs/2404.03820 | 论文+数据集 | C3（反面校准） | 构造混入干扰轮次的合成对话，微调模型抗住"故意带偏"、保持话题一致 | 3 | 数据/方法轻；但解决的是"别乱飘"，做闲聊需反向使用 |
| GauchoChat 主动可控个性化社交对话 | cdn.amazon.science/.../gauchochat-towards-proactive-controllable-and-personalized-social-conversation.pdf | 论文（Amazon） | C1 | Promptist根据用户意图/人设/情绪动态选提示策略；proactive topic switching模块判断何时切换并织入外部素材 | 3 | 思路可借鉴；依赖外部素材检索 |
| 统一模型系统发起话题转换句 | dl.acm.org/doi/fullHtml/10.1145/3571884.3597125（ACM WWW） | 论文 | C1 | 训练离散token或连续prompt，让统一模型主动产出transition sentence触发模式切换 | 3 | 离散token思路轻量，但需微调 |
| ProCoT 主动对话思维链 | arxiv.org/abs/2305.13626 | 论文+prompt | C1（跨B） | proactive CoT提示激发LLM规划能力；论文指出不加约束时LLM会"过激地"把话题拽向指定目标 | 3 | 纯prompt，3B能跑但效果弱（论文明示小模型主动提问仍差） |
| SalesBot 2.0 意图引导平滑过渡 | arxiv.org/abs/2308.14266 | 论文+数据集 | C1 | 先找"当前话题与目标意图的交集话题"，再多轮逐步过渡，要求transition自然不突兀 | 3 | 提示范式可直接复用 |
| PaRT 个性化实时检索主动社交 | arxiv.org/abs/2504.20624（SIGIR 2025） | 论文 | C1（跨B） | 用户画像+上下文喂LLM，先精化意图再生成个性化话题，作query检索语料织入回复 | 3 | 依赖外部检索库与较强LLM，3B吃力 |
| UPC Critic引导用户导向主动 | arxiv.org/abs/2505.12334 | 论文 | C1（跨B） | LLM-as-a-judge做critic评估主动度，bot/user两agent互聊生成高主动度语料做SFT | 3 | 依赖较强LLM当裁判与生成器 |

#### 成熟度 2（思路/demo/工程博客）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| STAR-BTM 多轮对话话题相关性建模 | arxiv.org/abs/2009.12735 | 论文 | C1 | Biterm Topic Model在话题级判断哪些历史上下文与当前轮相关，再生成回应 | 2 | 话题模型可外挂，但工程较旧 |
| Convergent & Divergent Decoding（topic drifter） | arxiv.org/abs/2005.03174 | 论文 | C2 | 设topic drifter从上下文与事实产出"漂移词"，从当前话题候选往外扩，提升多样性 | 2 | 解码层思路可借鉴；实现偏旧 |
| DASH-DTS 公共频道话题分段 | arxiv.org/abs/2512.15042 | 论文 | C1 | 握手识别模块找"开启新话题的短互动线索"，对话相似度引导的in-context检索做话题切分 | 2 | 需检索/ICL，3B做握手判断偏难 |
| Membox 话题连续性织进长程记忆 | arxiv.org/abs/2601.03785 | 论文 | C1 | 反对"切碎再embedding检索"，改用层次记忆结构保留叙事/因果流，避免检索偏向词面相似 | 2 | 偏记忆架构研究，3B难落地 |
| Think Before You Speak 内心独白主动避题 | arxiv.org/abs/2311.07445 | 论文 | C1 | inner monologue让模型意识到"这个话题不熟/该回避"，再主动做topic transition切到熟悉内容 | 2 | 思路可prompt化；"判断该不该转"对3B难 |
| AutoReply 自省式检测nonsense | arxiv.org/abs/2211.12615 | 论文 | C3 | 模型自省式判别当前回复是否属于重复/无意义等nonsense类型 | 2 | 判别思路轻，可做输出过滤器 |

#### 社区/工程博客（prompt级与反面材料）

| 方案名 | 出处 | 类型 | 解决主题 | 核心机制 | 成熟度 | 可迁移本地轻量模型 |
|---|---|---|---|---|---|---|
| "Interrupt and Redirect"两行式换话题提示 | aiangels.io/blog/interrupt-and-redirect-prompt-two-line-pattern-ai-companion-subject-change | 工程博客（社区经验） | C1 | 第一行明确"上一话题关闭"中断信号，第二行给新话题具体引导，两步拆开避免模型黏住 | 3（社区反复验证） | 纯prompt，3B可试但遵循度弱 |
| "Hard Pivot / Hard No"换话题脚本系列 | aiangels.io/blog/hard-pivot-script-change-subject-ai-companion-no-loop | 工程博客 | C1 | "承认→桥接过渡词(speaking of which)→给明确新话题"三段式，不给模型留情绪尾巴可追 | 3 | 纯prompt |
| 中文"像朋友一样聊天"提示词 | cnblogs.com/ghj1976/p/18657144/ | 博客园 | C2 | 每轮结尾延伸相关新话题、主动提具体话题（美食/电影/旅游），避免问"有什么要聊的"泛问 | 2-3 | 纯prompt，3B可直接试 |
| "The Passivity Problem" | whitepapers.gravity7.com/notes/the-passivity-problem | 分析博客 | C3（反面） | RLHF优化"单轮有用性"，系统性侵蚀多轮对话与主动性；越被动越"显得权威" | 2（观点性） | 诊断，非方案 |
| Character.AI为何"擅自换场景" | roborhythms.com/character-ai-bot-changes-scenario/（**第三方推测**） | 博客 | C3（反面） | 原场景滚出上下文窗后，模型从最近一条消息重建场景、用训练数据填空，于是"换了剧情"——是coherence failure非人设 | 2 | 诊断 |
| Google论坛：模型死盯最后一条消息 | discuss.ai.google.dev/t/context-memory-problem/51505 | 社区帖子（**第三方反馈**） | C3（反面） | 所有主流模型过度聚焦最后一条user message，忽略全程上下文，长对话里"拐不动"（recency bias） | 2 | 诊断 |

---

## 二、「prompt 可做 vs 需工程」二分清单

### ✅ 纯靠 prompt 就能实现（不写代码/不挂后台进程）

| 方案 | 所属主题 | 具体做法 |
|---|---|---|
| 系统时间戳注入 | A | system prompt写`{{date}} {{time}} {{weekday}}`，让模型会说"早上好/深夜了" |
| 距上次对话时长提示 | A | prompt里写"现在距上次对话已过去N天"，调整寒暄与话题接续 |
| 时态/相对时间换算指令 | A | 显式要求模型区分时态、把"明天/下周"与当前日期做换算 |
| 置顶关键记忆常驻prompt | A | Character.AI pinned思路——N条关键记忆常驻system prompt |
| 规则化"何时该回" | A | prompt写"问句/情感句才主动回，陈述句不打扰"（MRTM的prompt近似） |
| Proactive CoT Prompting | B/C | system prompt要求"先规划目标再主动澄清/引导话题" |
| Inner Thoughts两层prompt | B/C | 先输出内心OS再决定是否开口，纯prompt结构 |
| CURIO好奇心提问模板 | B | 退化为"每轮结尾提一个好奇问题" |
| SillyTavern Idle续聊prompt（内容层） | B | 注入一段idle续聊prompt即可（触发仍需定时器，但内容是prompt） |
| 主动问候文案生成 | B | 把"基于最近记忆写一条问候"写成单次prompt |
| Interrupt and Redirect两行模板 | C | 第一行关闭上话题，第二行引导新话题 |
| Hard Pivot/Hard No三段式 | C | "承认→桥接过渡词→明确新话题" |
| 中文"像朋友聊天"提示词 | C | 每轮结尾延伸具体新话题，避免泛问 |
| SalesBot 2.0过渡提示范式 | C | 先找两话题交集、再多轮平滑过渡 |
| 通用"允许自然拐弯"指令 | C | system prompt写"允许在合适时机自然开启新话题、用'说到这个/对了'过渡、不要每次硬扣回上一句" |

> **纯 prompt 的根本局限**：只能在"已有对话回合内"主动，**无法在用户不发消息时自己醒来**——触发动作仍需外部定时器。时间感上，模型只能"被喂时间戳后按指令套用格式"，不能自己感知时间流逝。

### 🔧 需要外挂工程（注入时间戳 / 状态机 / 后台进程 / 检索）

| 方案 | 所属主题 | 外挂件 |
|---|---|---|
| 每条记忆打录入时间戳+检索期过滤衰减 | A | 检索系统+时间字段+衰减公式 |
| 记忆衰减调度（MemoryBank/CortexGraph/FADEMEM） | A | 宿主数据库+时间字段+定时打分 |
| 按天落盘/摘要（AG2/OpenClaw） | A | 文件系统+定时摘要job |
| 后台心跳/cron主动发消息 | A/B | 常驻进程（Python schedule+线程） |
| 后台"做梦"整理记忆（OpenAI Dreaming式） | A | 离线job+跨会话数据层 |
| typing indicator+人为1-2.5s延迟 | A | 前端层 |
| 相对时间实体抽取（Duckling） | A | NLU组件把"下周三"解析成绝对日期 |
| 所有真正的"离开后主动发消息" | B | 常驻进程/定时器→状态机判断→注入user turn或push→LLM生成→推送通道 |
| 生活模拟后台状态衰减器 | B | 世界状态机（饥饿/心情/日程随时间变化） |
| PaRT话题检索层 | B/C | 向量库+检索 |
| Long-term Agent trigger condition轮询 | B | LLM生成条件+外部定时器轮询 |
| CNTD话题漂移检测器 | C | BERT-base分类器外挂判断"用户这轮是不是要换话题" |
| MapDia三段式RAG | C | 话题摘要+历史话题召回排序+漂移时机检测 |
| SillyTavern World Info关键词触发 | C | 关键词匹配引擎+lore库 |
| Rasa Stories/CALM状态机 | C | 对话管理栈+NLU训练 |
| Rhea记忆调度（IM/EM双记忆+优先级注意力） | C | 记忆检索/注意力调度层 |
| CrewAI Conversational Flows | C | 每轮intent分类+route_turn路由 |

---

## 三、三个必须回答的问题

### 问题①：哪些方案能纯靠 prompt 实现？

**答案：以上"✅纯靠prompt"清单中的15项，核心可归纳为四类：**

1. **时间感知的prompt模拟**：注入系统时间戳、距上次对话时长、时态换算指令、置顶记忆。本质是"把时间信息当文本喂给模型，让它按格式说话"。
2. **主动性的prompt引导**：Proactive CoT、Inner Thoughts两层、好奇心提问模板、主动问候生成。本质是"在已有回合内让模型多走一步推理再决定说什么"。
3. **话题拐弯的prompt模板**：Interrupt and Redirect、Hard Pivot、"像朋友聊天"提示词、SalesBot过渡范式、通用"允许自然拐弯"指令。本质是"给模型明确的过渡话术和许可"。
4. **回复时机的规则化prompt**："问句/情感句才回，陈述句不打扰"。

**判断依据**：这些方案的共同特征是——不需要模型在用户不发言时自行唤醒，不需要持久化状态，不需要外部检索，不需要训练。它们都在"单次LLM调用"的边界内完成。

**但要诚实标注**：纯prompt实现的"主动性"是**被动中的主动**——只有用户发了消息，模型才能在回复里多问一句、多拐一个弯。真正的"AI自己找你"必须有外部触发器。

---

### 问题②：哪些方案需要外挂工程？

**答案：以上"🔧需外挂工程"清单中的17项，按外挂类型分三类：**

1. **时间注入与记忆工程**（主题A为主）：每条记忆打时间戳、艾宾浩斯衰减调度、按天落盘摘要、后台做梦整理、Duckling时间实体抽取。共性是需要**持久化存储+时间字段+定时任务**。
2. **主动触发与后台进程**（主题B为主）：所有"离开后主动发消息"方案（Nomi/Kindroid/Replika/Open-LLM-VTuber/Rasa trigger_intent/memu-py/proactiveagent）、生活模拟状态衰减器、trigger condition轮询。共性是需要**常驻进程/定时器+状态机+推送通道**。
3. **话题检测与检索联想**（主题C为主）：CNTD漂移检测器、MapDia RAG、World Info关键词触发、Rasa状态机、Rhea记忆调度、PaRT检索层。共性是需要**分类器/检索库/关键词引擎**。

**判断依据**：这些方案的共同特征是——需要在LLM调用之外维护状态、监听事件、或检索外部信息。单次prompt无法覆盖。

**最干净的工程范式推荐**：
- **主动性**：Rasa `trigger_intent`——外部事件注入一条伪造user turn，bot按正常流程回复，架构最简洁。
- **时间感**：SillyTavern `{{time}}`宏+MemoryBank衰减——前端注入时间戳+宿主侧算衰减，3B模型只负责生成。
- **话题漂移**：CNTD检测器（BERT-base，极轻）+ 过渡句prompt——把"判断该不该切"外包给小分类器，3B只负责生成过渡句。

---

### 问题③：哪些方案在小模型（3B级）上无效？为什么？

**答案：以下方案在3B上会明显退化或失效，按原因分组：**

#### 原因一：需要长程推理/复杂意图理解，3B语义敏感性不足
- **MapDia的"主动漂移时机判断+自然生成"**：时机判断本质是隐式语用推理，3B判别力弱，容易"该切不切/乱切"；官方用7B才超过GPT-4。
- **PaRT话题意图精化**：先理解用户潜在意图再生成话题，3B在意图精化环节容易丢失或臆测意图。
- **GauchoChat主动话题切换模块**：依赖动态提示策略选择+外部素材织入，3B策略选择能力弱。
- **ComPeer情感时机判断**："该不该现在发关怀"依赖细腻情感与社会推理，3B容易要么太频繁要么太冷漠。

#### 原因二：需要LLM-as-judge/双agent互聊，3B当不了裁判
- **UPC Critic引导主动**：critic是额外一次LLM调用，3B可当弱critic但质量不足，且双倍token开销。
- **ProactiveEval评测**：需要较强模型做评判，3B自评不可靠。

#### 原因三：需要训练/微调，3B不重训无法获得
- **Echo带时间情景记忆**：训练侧方案，需合成数据+微调。
- **TIMER回复时机预测**：需user-simulator数据+训练。
- **Time-R1时序推理RL**：虽在3B上做，但需三阶段RL管线，普通用户复现门槛极高。
- **CANTTALKABOUTTHIS抗干扰**：需微调。
- **统一模型转换句（离散token）**：需prompt-tuning/微调。

#### 原因四：需要多模态/实时感知，3B视觉基本不可用
- **巴布机器人多模态主动感知**：实时视觉判断"用户现在什么状态"。
- **AI Desktop Pet看屏幕搭话**：视觉理解对3B要求较高。

#### 原因五：需要跨多会话后台记忆综合，3B摘要质量不足
- **OpenAI Dreaming式跨会话记忆综合**：长文档摘要+时间区间抽取对小模型质量不足。
- **Chronos事件抽取+双日历**：多分辨率时间抽取依赖强模型，3B易漏。
- **Theanine自动建因果记忆图**：3B抽不准事件、判不准因果。

#### 原因六：7×24常驻的算力/显存约束
- **memu-py/CodingGenie式高成本主动监控**：即使模型能跑，常驻在本地小模型上也要持续占显存/算力，工程上需事件触发而非真正常驻推理。

**核心结论**：3B模型是**"时间的执行者，不是时间的感知者"**；是**"过渡句的生成者，不是拐弯时机的判断者"**；是**"被触发后的回复者，不是主动醒来的发起者"**。在3B上最靠谱的策略是——把"判断/感知/触发"全部外包给规则、小分类器、定时器和检索，只让3B负责"按指令生成自然语言"。

---

## 四、现有方案共同的没解决的缺口

### 缺口1：没有任何方案实现"真正的主观时间体验"
所有时间感方案都是**外部时间戳注入+工程衰减**，没有一个让模型真正"经历"时间。模型知道"现在是下午3点"是因为prompt里写了，不是因为它从上午等到了下午。反面论文（ACL Findings 2026）证明：即使显式注入时间信息，agent仍与人类时间感知不对齐。这是架构级缺口，不是prompt或工程能弥补的。

### 缺口2：主动性的"度"没有统一解
- 太主动→用户反感（ChatGPT自主开口遭用户抵制、Nomi被批"制造需要感"、Fawn Friends被骂打断工作）。
- 太被动→用户觉得"AI一根筋、不贴心"。
- 现有方案要么靠固定定时器（SillyTavern Idle），要么靠黑盒决策引擎（Kindroid），**没有一个公开的、可复现的"主动度自适应"方案**。ProactiveEval等评测框架刚出现，但离产品化还远。

### 缺口3：话题漂移的"自然感"缺乏评测标准
学术上有topic shift detection（检测用户换话题），但**"AI主动换话题换得自不自然"几乎没有公认指标**。MapDia做了A/B测试，但样本和场景有限。社区靠"感觉"判断，工业界靠留存率间接衡量。这导致方案优化缺乏明确方向。

### 缺口4：三个主题的整合方案几乎空白
- 时间感、主动性、话题漂移在学术和工业中大多**独立研究**。
- 真实的"人味对话"需要三者联动：AI因为"过了三天没聊"（时间感）→决定主动发消息（主动性）→从"上次聊的电影"自然拐到"你最近有没有看新片"（话题漂移）。
- 现有产品（Nomi/Kindroid/Replika）可能内部做了整合，但**无官方技术文档说明三者如何协同**；开源界没有一个框架同时覆盖三者。

### 缺口5：本地轻量模型的"人味"几乎是空白
- 所有成熟产品方案（Nomi/Kindroid/Replika/OpenAI/Anthropic/Google）都依赖云端大模型。
- 开源方案（SillyTavern/Open-LLM-VTuber/Rasa）提供了工程骨架，但**3B级模型在语用推理、情感时机、话题自然度上的表现与大模型有质的差距**，且没有针对小模型的"人味优化"数据集或训练范式。
- Time-R1是少数在3B上做时序的，但需RL训练，不可开箱即用。

### 缺口6：安全/合规与主动性的矛盾未解决
- 中国《AI陪伴办法》要求连续使用2小时强制提醒、防沉迷、危机干预。
- OpenAI/Anthropic默认"用户控制权优先"，不让模型主动联系用户。
- **"主动关心"与"情感操纵/骚扰"的边界**没有技术方案能自动判定，Nomi被批"guilt-trip提升留存"就是例证。

### 缺口7：跨会话"生活连续性"的工程成本极高
- 要让AI有"自己的生活时间线"，需要7×24后台进程、持久化记忆、定时整理、状态衰减。
- 这在云端是钱（每次主动=一次LLM调用，CodingGenie论文实测分析了成本），在本地是电和显存。
- **没有低成本的"轻量生活模拟"标准方案**——animalhouse.ai的纯状态机是一个方向，但太简单，缺乏自然语言生成的融合。

---

## 五、一句话结论

> **现有方案能让AI"看起来有时间感、会主动、能拐弯"，但全部依赖外部工程（时间戳注入+定时器+检索+状态机），没有一个方案让AI真正"拥有"这些能力；本地3B模型的最佳策略是把判断/感知/触发全部外包给工程件，只让模型负责生成自然语言，而三者联动的"人味整合方案"和小模型专用优化仍是空白。**

---

## 附录：检索覆盖与诚实声明

### 四层来源覆盖情况
- **学术论文**：ACL/EMNLP/NAACL/CHI/CSCW/SIGDIAL/arXiv均有覆盖，共收录论文级方案约35篇。
- **工业方案**：OpenAI/Anthropic/Google/Replika/Character.AI/Nomi/Kindroid/SillyTavern/Rasa/AutoGen(AG2)/CrewAI均有涉及。
- **工程博客与社区**：掘金/博客园/36氪/aiangels.io/Amazon Science/Tavus等，中英文均有。
- **反面材料**：每个主题均有专门反面材料小节，共约15条。

### 明确标注"未找到"的项
- **Character.AI**：无官方记忆/主动性/话题机制文档，所有机制描述均为第三方推测/实测。
- **Replika**：未找到"话题自然转换机制"的官方技术文档。
- **OpenAI**：未找到专门讲"对话话题管理/主动拐弯"的官方文档（只有通用memory/chat history）。
- **OpenDialog**：未检索到与时间感/话题漂移相关的实质机制页面。
- **AutoGen**：无原生话题漂移机制，GroupChatManager只做speaker selection；其"主动性"是agent间任务轮转，非陪伴场景主动找用户。
- **知乎/少数派**：具体文章多在登录墙后，未取得全文，以掘金/博客园/36氪公开文作为中文社区侧证据。

### 跨主题重叠说明
以下方案同时涉及多个主题，在清单中以"（跨B）""（跨C）"标注，未重复计数：
- PaRT（B3 + C1）
- TACT（B1 + C1）
- ProCoT（B1 + C1）
- UPC（B3 + C1）
- Inner Thoughts（B2 + C1）
- SillyTavern（A时间宏 + B Idle扩展 + C World Info，为三个不同功能，分列）
- Rasa（A时间实体 + B trigger_intent + C Stories，为三个不同功能，分列）

### 方案总数
去重后共 **约78条独立方案**（主题A 27条 + 主题B 31条 + 主题C 25条 - 跨主题重叠约5条），另附反面材料约15条。
