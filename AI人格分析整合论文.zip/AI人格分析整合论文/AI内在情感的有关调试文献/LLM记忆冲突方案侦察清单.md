# LLM 记忆冲突方案侦察清单（工业 + 开源侧）

> 侦察日期：2026-09-27　范围：维度2（记忆架构，结构上避免）/ 维度4（纠错与可撤销）/ 维度5（输出前自检）
> 成熟度口径：5=产品化/稳定复现；4=开源可直接跑；3=论文有代码；2=demo；1=概念。宁可低不可高。
> 类型标注：【工业产品】【开源库】【工程博客（经验，非论文结论）】【论文+代码】。
> star 量级为检索时点公开榜单的近似值（不同榜单口径有 ±20% 误差），非实时精确值。

---

## 一、方案清单表（按维度分组，组内成熟度降序）

### 维度2：记忆架构——从结构上避免冲突

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 本地3B适配 |
|---|---|---|---|---|---|---|
| OpenAI ChatGPT Memory（Saved Memories + Dreaming） | https://openai.com/index/memory-and-new-controls-for-chatgpt/ ；Dreaming 博客 2026-06 | 工业产品 | 2 | 跨对话保存偏好/事实的 bullet 记忆，2026 年上线后台"Dreaming"长期上下文合成，专门解决 staleness（过时）/correctness（正确性）/scalability | 5 | 否（托管大模型） |
| Zep 商用 Context Lake（时序知识图谱） | https://help.getzep.com/v3/graph-overview ；https://www.getzep.com/ai-agents/temporal-knowledge-graph/ | 工业产品 | 2,4 | bi-temporal 事实：每条边带 valid-from/valid-to，新事实与旧事实矛盾时旧边"关闭失效"而非删除，历史可查 | 5 | 否（托管+图谱抽取需强模型） |
| Anthropic Claude Memory Tool | https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool | 工业产品 | 2,4 | 以"记忆文件目录"做 just-in-time 检索，Claude 自己 create/read/update/delete 持久化文件，不把全量塞上下文 | 5 | 否（托管） |
| Google Gemini Saved Info / Personal Context | https://insiderllm.com/pdfs/ai-memory-wall-why-chatbot-forgets.pdf （二手综述，Gemini 官方文档未单列冲突机制） | 工业产品 | 2 | 保存稳定偏好（Saved Info）+ 跨会话召回（Personal Context），仅 Google One AI Premium 开放 | 4 | 否（托管） |
| Letta（原 MemGPT） | https://github.com/letta-ai/letta （约 24k★）；https://docs.letta.com （论坛：https://forum.letta.com/t/88） | 开源库 | 2,4 | 三层：Core Memory（persona+human 命名块，常驻上下文、agent 自编辑）/ Recall（可搜对话史）/ Archival（向量长期库），"LLM 操作系统"式分页 | 4 | 部分（自编辑 core 块强依赖 tool-calling 能力，3B 偏弱） |
| Mem0 开源记忆层 | https://github.com/mem0ai/mem0 （约 60k★）；https://docs.mem0.ai ；论文 arXiv:2504.19413 | 开源库 | 2,4 | 混合存储（向量+KV+图谱），旧版抽取时输出 ADD/UPDATE/DELETE/NOOP 四动作解决冲突；2026-04 新算法 v3 改为"单次 ADD-only"只追加不覆盖，配合实体链接+多信号检索 | 4 | 部分（后端可插拔，能接本地 3B+本地 embedding，但抽取/实体链接质量在 3B 上明显下降） |
| Graphiti（Zep 的开源时序图谱引擎） | https://github.com/getzep/graphiti （约 31k★）；论文 arXiv:2501.13956 | 开源库 | 2,4 | 实时时序知识图谱，bi-temporal 事实+provenance，被新事实 supersede 的旧事实打 valid-to 时间戳而非删除 | 4 | 部分（自托管可跑，但实体/边抽取 LLM 步骤重，依赖 Neo4j/FalkorDB，3B 抽图质量差） |
| Cognee | https://github.com/topoteretes/cognee （约 30k★）；https://docs.cognee.ai | 开源库 | 2 | 三存储（关系型 PostgreSQL/SQLite + 向量 + 图谱），ECL（Extract-Cognify-Load）管线，会话热缓存+后台异步同步永久图谱，提供 forget()/improve() | 4 | 部分（有嵌入式默认 SQLite/LanceDB/Kuzu 可本地起，但 ECL 抽图管线 LLM 密集） |
| LangGraph Stores / LangChain Memory | https://docs.langchain.com/oss/python/langgraph/memory ；https://github.com/langchain-ai/langgraph （约 41k★） | 开源库 | 2,4 | 跨线程长期记忆存为 JSON 文档，按 namespace/user_id + key 分层组织；另有 EntityMemory（按实体攒事实）、ConversationSummaryMemory | 4 | 是（存储层是纯 KV/JSON，不强依赖大模型；检索/总结才需要 LLM） |
| Microsoft Foundry Memory | https://learn.microsoft.com/azure/foundry/how-to/develop/langchain-memory | 工业产品 | 2 | 显式分两类：user profile memory（稳定事实/偏好，跨会话身份锚）+ chat summary memory（蒸馏话题摘要），用 user_id 做 scope 绑定 | 4 | 否（Azure 托管） |
| MemoryBank（Ebbinghaus 遗忘曲线） | https://github.com/zhongwanjun/MemoryBank-SiliconFriend ；论文 arXiv:2305.10250 | 论文+代码 | 2 | 双层存储（原始对话日志 + 高层摘要/用户画像），按艾宾浩斯 R=e^{-t/S} 做记忆强度衰减，被回忆则强化、否则自然淡化——用"主动遗忘"清理过时记忆 | 3 | 部分（衰减公式是纯数学可本地跑；摘要/画像抽取仍需 LLM） |
| Memary | https://github.com/kingjulio8238/Memary （约 2.5k★） | 开源库 | 2 | 模拟人类记忆：MemoryStream 短期流 → EntityKnowledgeStore 长期（聚合实体出现频次+最近时间戳），自动生成/更新知识图谱 | 3 | 部分（小仓库，抽取靠 LLM；图谱结构可本地） |
| PersonaAgent（episodic+semantic 画像） | https://arxiv.org/pdf/2506.06254 | 论文+代码 | 2 | episodic 记忆存带时间的个人经历，semantic 记忆把反复互动蒸馏成紧凑稳定用户画像（持久跨会话），检索时两者合并 | 3 | 部分（研究原型，蒸馏步骤吃 LLM） |
| Bi-Mem（persona-level 全局约束） | https://arxiv.org/html/2601.06490 | 论文+代码 | 2,4 | 提出 persona-level memory P（5 维：basic-info/interests/…）作为全局约束保证记忆一致性，归纳-反思双向构建分层记忆 | 3 | 否（研究原型，依赖较大模型） |
| 结构化 vs 向量记忆对比（工程经验） | https://memnode.dev/articles/agent-memory-vs-vector-db ；https://www.cognee.ai/blog/fundamentals/agent-memory ；https://dev.to/priyeshdave6/why-we-ditched-vectors-and-graphs-for-sql... | 工程博客（经验） | 2 | 经验结论：向量库擅长语义相似检索但丢实体/关系/时序，精确 ID、身份字段、偏好更新应走结构化 SQL/JSON/图谱；生产系统多为向量+图谱+BM25 混合 | 2 | 是（结构化 KV/SQL 这层本身可本地） |

### 维度4：纠错与可撤销

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 本地3B适配 |
|---|---|---|---|---|---|---|
| Mem0 update/delete API | https://docs.mem0.ai/getting-started/quickstart | 开源库 | 4 | client.update(memory_id, data=新内容) 原地改写；delete(memory_id) 删单条、delete_all(user_id) 清用户；CLI 同构 | 4 | 部分（API 本地可跑，改写判断可由本地模型做但弱） |
| Zep/Graphiti 事实失效（bi-temporal invalidation） | https://help.getzep.com/v2/concepts ；https://www.getzep.com/ai-agents/persistent-memory-for-ai-agents/ | 工业产品/开源库 | 4,2 | 纠错不是"删旧记忆"而是给旧边写 valid-to 时间窗，新事实开窗；错误事实被关闭后不再被检索命中，从机制上阻断错误扩散 | 4 | 部分（机制本地可跑，抽图 LLM 是瓶颈） |
| Anthropic Memory 文件 CRUD | https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool | 工业产品 | 4 | 记忆就是文件，用户/agent 可直接 read/update/delete 任意记忆文件，天然可撤销 | 5 | 否（托管） |
| OpenAI 记忆删除 / "忘记" | https://openai.com/index/memory-and-new-controls-for-chatgpt/ | 工业产品 | 4 | 用户可自然语言说"忘掉 X"，也可在设置里查看/删除单条记忆或全清；删对话不自动删记忆，必须显式删记忆本身 | 5 | 否（托管） |
| EasyEdit（统一 ROME/MEMIT/KN 等） | https://github.com/zjunlp/EasyEdit ；论文 arXiv:2308.07269 / ACL24 arXiv:2401.01286 | 开源库 | 4 | 统一封装模型层知识编辑：ROME（定位 MLP 单步编辑）、MEMIT（跨层批量编辑）、KN/Knowledge Neurons（先定位神经元再改）、SERAC/GRACE（memory-based 遗忘/反学习） | 3 | 部分（VRAM 上 3B 可跑编辑；但改的是参数化知识而非用户记忆，且见下方"编辑不彻底"警告） |
| ROME（Locating/Editing 事实） | https://arxiv.org/abs/2202.05262 （Meng et al.） | 论文+代码 | 4 | 因果追踪定位事实存储的 MLP 层，直接修改权重矩阵完成"改一条记忆" | 3 | 部分（小模型可跑，但需预计算因果定位） |
| MEMIT（Mass-Editing Memory） | https://arxiv.org/abs/2305.13172 | 论文+代码 | 4 | 把 ROME 扩展到跨多层批量编辑上千条事实，减少互相干扰 | 3 | 部分 |
| GRACE / SERAC（unlearning 方向） | 经 EasyEdit 收录：https://github.com/zjunlp/EasyEdit | 论文+代码 | 4 | memory-based 反学习：不改原权重，用外部记忆/超网络在推理时屏蔽旧事实，实现可撤销的"遗忘" | 3 | 部分 |
| "编辑并未真正擦除知识"（研究警告） | https://en.papernotes.org/ACL2026/one-mask-to-rule-them-all... （ACL26 论文解读） | 论文结论 | 4 | 正式研究结论：ROME/MEMIT 类编辑只是用 overattention 压制旧事实，旧事实仍留在 MLP/残差路径里，小 mask 即可让旧事实复活——模型层纠错不可靠 | 3 | —（依据，非落地项） |
| 错误扩散阻断（工程经验） | https://www.getzep.com/ai-agents/persistent-memory-for-ai-agents/ ；Mem0 v3 ADD-only 说明 https://pypi.org/project/mem0ai/ | 工程博客（经验） | 4,2 | 经验：靠"追加不覆盖 + bi-temporal 失效 + provenance 溯源"让错误记忆不再被下游检索命中，而非指望一次性改对 | 2 | 是（溯源/时间窗逻辑可本地实现） |

### 维度5：输出前自检

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 本地3B适配 |
|---|---|---|---|---|---|---|
| RAGAS Response Groundedness / Faithfulness | https://docs.ragas.io/en/stable/concepts/metrics/available_metrics/nvidia_metrics/ ；https://github.com/explodinggradients/ragas | 开源库 | 5 | 自动判断回答中每条 claim 能否在检索到的上下文里找到支撑（0/1/2 分），生成后做 groundedness 校验 | 4 | 部分（评测器本身再调一个 LLM 打分，3B 当裁判偏弱） |
| 结构化输出 / JSON Schema / 受限解码约束身份字段 | llama.cpp GBNF、outlines（https://github.com/dottxt-ai/outlines）；工程实践见 https://cloud.tencent.com/developer/article/2647966 | 开源库/工程实践 | 5,2 | 用 JSON schema / function calling / 语法约束解码，强制身份字段（姓名/偏好/ID）输出为固定枚举或类型，从生成端杜绝身份漂移 | 4 | 是（最吃 3B 的一项：语法约束解码在小模型上稳定，不依赖大模型推理） |
| 引用强制 / citation enforcement | https://learnixo.io/blog/safe-rag-vs-hallucination ；https://ai-tldr.dev/learn/rag/advanced-rag/add-citations-to-rag/ | 工程博客（经验） | 5 | 要求每条事实 claim 后挂 [Doc:id] 引用，输出带 confidence+citations 的 JSON，便于自动 NLI 校验与人工复核 | 2 | 部分（模板可本地，引用质量看模型） |
| Self-RAG（反思 token） | https://selfrag.github.io/ ；论文 arXiv:2310.11511 | 论文+代码 | 5 | 模型自带 ISREL/ISSUP/ISUSE 反思 token：生成前判断"要不要检索"、生成后判断"检索段是否支撑本段"，不支撑就重生成 | 3 | 否（需专门微调的 Self-RAG 权重，小模型版弱） |
| Self-Consistency（多路径投票） | Wang et al. 2022，arXiv:2203.11171 | 论文+代码 | 5 | 对同一问题采样多条 CoT 推理路径，取多数一致答案作为输出，降低单条错误推理被当成记忆事实的概率 | 3 | 部分（可在 3B 上跑，但要采样 N 次，慢；小模型路径多样性差、投票收益缩水） |
| CRITIC（外部工具批判校验） | Gou et al. 2023，arXiv:2305.11738 | 论文+代码 | 5 | 生成后让模型调用外部工具（搜索/知识库/计算器）对自己的关键陈述做批判性核查再修订，属"外部纠正" | 3 | 否（强依赖工具调用与强批判能力，3B 难稳定） |
| Self-Refine（自评-自改循环） | Madaan et al. 2023，arXiv:2303.17651 | 论文+代码 | 5 | draft → critique → refine 闭环，带最大迭代次数与"答案不再变化"停止条件，可在记忆场景里自检"我记住的偏好和刚说的是否矛盾" | 3 | 部分（3B 自我批评能力弱，循环容易空转或越改越差） |
| 自我纠正基准研究（警告） | https://papers.nips.cc/paper_files/paper/2025/file/...Can-LLMs-Correct-Themselves.pdf ；https://arxiv.org/html/2407.14507v3 | 论文结论 | 5 | 正式研究结论：无外部信号的"纯自我纠正"在事实类任务上常不升反降；CRITIC 类带外部资源的纠正才有效——纯靠小模型自省不可靠 | 3 | —（依据，非落地项） |

---

## 二、两个子问题的直接回答

### 子问题1：有没有方案明确提出"身份锚点"这种分层记忆结构？叫什么、做到什么程度？

**有，但"身份锚点"这个词本身是工程圈叫法，产品里它有多个等价名字，成熟度分三档：**

1. **最接近产品化、且真正做到"常驻身份块"的是 Letta（原 MemGPT）**。它把 Core Memory 拆成命名块，其中 `persona`（agent 自己是谁）和 `human`（用户是谁）两块**永远渲染进系统提示**，agent 用专用 memory tool 自己改写。这就是事实上的"身份锚点"——与可被检索替换的 Archival/Recall 记忆分层。成熟度 4（开源可直接跑）。但它不强制 schema，块内容是自由文本，靠 LLM 自觉维护。

2. **微软 Foundry Memory 是命名最直白的一档**：直接分 `user profile memory`（稳定事实/偏好，跨会话身份锚）+ `chat summary memory`（话题摘要），用 user_id 绑定 scope。它把"身份/偏好"和"事件摘要"在产品文档里就分开了，但这是 Azure 托管，不开放本地。

3. **学术侧把它讲得最清楚的是 Bi-Mem（arXiv:2601.06490）和 PersonaAgent（arXiv:2506.06254）**：
   - Bi-Mem 明确提出 **persona-level memory P 作为"全局约束"（global constraint）来保证记忆一致性**，并把 persona 拆成 5 维（basic-info / interests / …）——这正是"身份锚点"的学术表述。
   - PersonaAgent 用 episodic（带时间的事件）vs semantic（蒸馏出的稳定用户画像）两层，semantic 层就是锚点。
   - 另有 PILA workshop 论文《More Than a Role》提出 Character-side memory 的 **Identity State（核心特质/语言风格/知识边界）** 用来对抗角色漂移。
   - 这些都是**论文+代码级（成熟度 3）**，不是开箱产品。

4. **工程白皮书/博客层**：parslee.ai 的《State-Based Context Architecture》直接把四层里第一层命名为 **"Identity & Role"**，与 "Persistent Facts / Working Set / Environmental Signals" 分开生命周期；CallSphere、Beluga AI 等博客也讲 "identity core + episodic + semantic"。这层是**经验、非论文结论（成熟度 1-2）**。

**结论**：真正"结构上把身份锚点单独成层、且能跑"的，工程首选 **Letta 的 persona/human core block**（自由文本块）+ **LangGraph 的 namespace/user_id 分层 JSON 存储**（结构化 KV）；想要"强 schema 身份锚"目前没有现成产品，得自己用 JSON schema/受限解码把身份字段钉死（见维度5那一行，这反而是 3B 上最稳的做法）。

### 子问题2：哪些能在本地小模型（3B）上落地，哪些只是大模型奢侈品？

**判断依据**：一个记忆方案拆成两部分看——(a) 存储/索引/时间窗/衰减等"数据结构层"，(b) 抽取/编辑/自检等"LLM 推理层"。前者任何模型都能跑；后者才是 3B 的瓶颈。

| 落地档位 | 方案 | 依据 |
|---|---|---|
| **能落地（是）** | LangGraph/LangChain stores 的 namespace+JSON KV 存储；结构化 SQL/JSON 记忆后端；**受限解码/JSON schema/GBNF 约束身份字段**；MemoryBank 的艾宾浩斯衰减公式；bi-temporal 时间窗与 provenance 溯源逻辑 | 这些是纯数据结构/语法约束，不依赖强 LLM 推理。尤其"用 schema 把姓名/偏好/ID 钉成枚举"在 3B 上最稳，是小模型防身份漂移的主力 |
| **部分落地（部分）** | Mem0（后端可插拔接本地 3B+本地 embedding，但 ADD 抽取、实体链接、UPDATE/DELETE 判别在 3B 上质量明显下降）；Cognee（有 SQLite/LanceDB/Kuzu 嵌入式默认值可本地起，但 ECL 抽图管线 LLM 密集）；Graphiti/Zep（机制可自托管，但实体/关系抽取吃强模型，还依赖 Neo4j）；Self-Consistency（3B 能跑但要采样 N 次很慢，且小模型路径多样性差、投票收益缩水）；Self-Refine（3B 自我批评弱，循环易空转）；EasyEdit 改 3B 权重（VRAM 上可行，但改的是参数化知识而非用户记忆） | 存储/索引能本地，但"智能抽取与判别"这一步 3B 会掉点，需要靠 prompt 工程+schema 兜底，或把难的抽取步骤丢给云端大模型 |
| **大模型奢侈品（否）** | Letta 的 agent 自编辑 core memory（强依赖稳定 tool-calling，3B 容易把 persona 块写坏）；Zep/OpenAI/Anthropic/Gemini 托管记忆；CRITIC（外部工具批判）；Self-RAG 反思 token（需专门微调权重）；OpenAI Dreaming 式后台长期上下文合成 | 这些要么是托管服务，要么依赖强工具调用/强批判/专门微调，3B 上既不稳也不划算 |

**一句话依据**：记忆冲突的"存储侧解法"（结构化、分层、时间窗、schema 约束）对 3B 友好且应优先用；"LLM 侧解法"（自动抽取、自动判别冲突、自动纠错、自检循环）在 3B 上会显著退化——研究已证明无外部信号的纯自我纠正会反噬（NeurIPS2025 基准），模型层 ROME/MEMIT 编辑也"并未真正擦除旧知识"（ACL26）。所以本地 3B 路线应**重结构化存储 + 受限解码 + 人工/云端兜底纠错**，而不是指望小模型自己聪明地记和改。

---

## 三、检索过的关键词与仓库清单

**检索关键词（中英混合）**：
- `Mem0 github memory layer update delete`、`Mem0 ADD UPDATE DELETE NOOP algorithm`
- `Letta MemGPT core memory archival recall`
- `Zep temporal knowledge graph fact invalidation bi-temporal Graphiti`
- `Cognee memory graph ECL pipeline`、`structured vs vector database agent memory`
- `MemoryBank Ebbinghaus forgetting curve github`、`Memary github knowledge graph memory`
- `LangGraph store memory namespace`、`EntityMemory ConversationSummaryMemory`
- `OpenAI ChatGPT memory Dreaming`、`Anthropic Claude memory tool`、`Gemini Saved Info Personal Context`
- `ROME MEMIT Knowledge Neurons EasyEdit unlearning GRACE SERAC`
- `Self-Consistency CRITIC Self-Refine Self-RAG`
- `RAG groundedness citation hallucination ragas constrained decoding JSON schema`
- `agent memory identity anchor persona three-layer episodic semantic`

**核验过的真实 GitHub 仓库（URL + star 量级）**：
- https://github.com/mem0ai/mem0 — 约 60k★（不同榜单 41k–66k）
- https://github.com/letta-ai/letta — 约 24k★
- https://github.com/getzep/graphiti — 约 31k★
- https://github.com/topoteretes/cognee — 约 30k★（榜单 27k–31k）
- https://github.com/langchain-ai/langgraph — 约 41k★
- https://github.com/zhongwanjun/MemoryBank-SiliconFriend — MemoryBank 参考实现（小仓库）
- https://github.com/kingjulio8238/Memary — 约 2.5k★
- https://github.com/zjunlp/EasyEdit — 知识编辑统一框架
- https://github.com/explodinggradients/ragas — RAG 评测
- https://github.com/dottxt-ai/outlines — 受限解码（JSON schema 约束）

**主要官方文档 URL**：
- Mem0: https://docs.mem0.ai ；Zep: https://help.getzep.com ；Letta: https://docs.letta.com / https://forum.letta.com
- Anthropic memory tool: https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool
- OpenAI memory: https://openai.com/index/memory-and-new-controls-for-chatgpt/
- LangGraph memory: https://docs.langchain.com/oss/python/langgraph/memory

---

## 四、未找到 / 未坐实的项（诚实声明）

1. **"身份锚点"作为一个被某主流产品正式命名的专有术语**：没有找到任何主流产品用"identity anchor"这个原词做功能名。最接近的是 Letta 的 persona/human core block、Foundry 的 user profile memory、Bi-Mem 的 persona-level memory。该词目前主要出现在工程博客/白皮书。
2. **Google Gemini 记忆的冲突处理细节**：只查到 Saved Info / Personal Context 是付费功能、存稳定偏好，**未找到 Gemini 官方文档专门讲它如何处理记忆冲突或纠错**，上表标注为二手综述来源。
3. **Mem0 新旧算法的冲突语义**：官方文档/ PyPI 显示 2026-04 后新算法改为 ADD-only（不覆盖），但 API 仍保留 update()/delete()；二者关系（自动抽取不覆盖 vs 人工显式改写）我按文档字面并列呈现，**未在源码层逐行确认**。
4. **Memary（kingjulio8238/Memary）的最近活跃度与 star 精确值**：只查到约 2.5k★、代码可读，未确认其是否仍在维护，成熟度保守给 3。
5. **各仓库 star 精确数**：均来自第三方榜单聚合，非 GitHub 实时 API，存在 ±20% 口径误差，已用"约/量级"表述。
6. **"error propagation prevention"（错误记忆扩散阻断）的专门开源实现**：没有找到以此命名的独立库；目前是 Zep bi-temporal invalidation、Mem0 ADD-only、provenance 溯源等**机制隐含**解决，而非专门产品。
7. **维度5在"记忆场景"的直接落地代码**：Self-Consistency/CRITIC/Self-Refine/Self-RAG 都是通用推理方法，**未找到把它们专门封装成"记忆一致性自检"模块的成熟开源库**，多为论文/通用 prompt 模板。
