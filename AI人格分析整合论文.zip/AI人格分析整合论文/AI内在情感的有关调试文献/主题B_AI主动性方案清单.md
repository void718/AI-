# 主题B：AI 的主动性 / 自主起话 —— 方案侦察清单

> 子任务执行者：AI 主动性方案侦察员
> 检索日期：2026-09-27
> 说明：本清单仅收录经检索确认存在的方案；找不到的不编造，每条均标注「官方说明」或「第三方推测」。成熟度标注从严。

---

## 一、方案清单（按成熟度降序）

### 成熟度 5 —— 已产品化、有稳定复现

| # | 方案名 | 出处（含真实URL） | 类型 | 解决哪个主题 | 核心机制（一句话） | 成熟度 | 可否迁移到本地轻量模型 |
|---|---|---|---|---|---|---|---|
| 1 | **Nomi.ai Proactive Messaging** | https://nomi.ai/nomi-knowledge/proactive-messaging-when-your-nomi-messages-you-first/ （官方知识库） | 产品 | B-主动对话 / B-非提示式发言 | 用户离开一段时间后，后端定时唤醒 Nomi"思考并活动"，再以 push 消息形式主动发跟进内容，而非固定模板提醒。 | 5 | 机制可迁移，但"离开期间后台思考"需要后端常驻进程 + 推送通道；本地 3B 模型可复现"定时触发一次生成"，但跨天记忆/思维链需外挂向量库。 |
| 2 | **Kindroid Proactive Mode** | https://kindroid.ai/v2/docs/chat-features-and-tools/ （官方文档） | 产品 | B-主动对话 / B-话题发起 | 分析对话模式自动决定外联时机，可选发文字/语音/自拍/语音电话，支持 Quiet hours，界面显示 thought bubble 展示决策过程。 | 5 | 决策引擎本身（何时开口、发什么模态）是可迁移的状态机；本地 3B 可跑"是否主动开口"的二分类 + 生成，但自拍/语音电话需额外多模态管线。 |
| 3 | **Replika 主动通知 / 联系** | https://help.replika.com/hc/en-us/articles/360027515872-How-do-I-set-up-my-app-s-notifications （官方帮助中心） | 产品 | B-非提示式发言 | 开启通知后，Replika 全天主动推送"温柔提醒/聊天邀请"，官方称会记住之前对话内容使消息显得个人化。 | 5 | 推送通道是产品壳；"个人化主动文案"可本地复现（定时取记忆片段→生成问候），3B 模型在短问候语层面够用。 |
| 4 | **SillyTavern Idle 扩展（内置）** | https://docs.sillytavern.app/extensions/ ；源码 https://git.durrantlab.pitt.edu/SillyTavern/Extension-Idle | 开源/前端扩展 | B-非提示式发言 | 用户 idle 一段时间后自动注入一条"idle prompting"，让角色自然续聊，而不是发独立 push。 | 5 | 完全可迁移：它就是一个前端定时器 + 把预设 prompt 塞进对话上下文，本地任意模型都能跑，是最轻量的主动起话实现。 |
| 5 | **Rasa「Reaching Out to the User」/ trigger_intent** | https://rasa.com/docs/rasa/next/reaching-out-to-user/ （官方文档） | 开源框架 | B-主动对话 | 外部设备/定时任务向 `trigger_intent` 端点 POST 一个伪造的 user intent，仿佛用户自己说了这句话，bot 随即按正常对话流回复。 | 5 | 完全可迁移：本质是"外部事件注入一条 user turn"，与模型大小无关，本地 3B 配合任意对话管理后端即可复现。 |

### 成熟度 4 —— 有开源实现、可直接跑

| # | 方案名 | 出处（含真实URL） | 类型 | 解决哪个主题 | 核心机制（一句话） | 成熟度 | 可否迁移到本地轻量模型 |
|---|---|---|---|---|---|---|---|
| 6 | **Open-LLM-VTuber「AI 主动说话」** | http://docs.llmvtuber.com/docs/intro/ ；配置项 https://raw.githubusercontent.com/Open-LLM-VTuber/Open-LLM-VTuber/main/config_templates/conf.default.yaml （`proactive_speak_prompt`） | 开源项目 | B-非提示式发言 / B-生活模拟 | AI 进入 idle 状态达到阈值后，用独立的 `proactive_speak_prompt` 触发一次 LLM 生成；另支持"内心 OS"（想而不说）。 | 4 | 原生就是本地轻量模型方案（支持 GGUF/Ollama），idle 定时器 + 独立 prompt 模板，3B 级可跑，但主动语的自然度会明显下降。 |
| 7 | **Steam《AI Desktop Pet》(42kami)** | https://store.steampowered.com/app/4227700/AI_Desktop_Pet/ | 产品/开源周边 | B-生活模拟 | 内置本地 LLM 的桌面桌宠，能看屏幕并"自己开始对话"，支持 BYO GGUF 模型。 | 4 | 原生支持本地 GGUF，是"本地轻量模型 + 主动开口"最现成的参照实现；主动触发逻辑（看屏幕→决定是否搭话）对 3B 视觉理解要求较高。 |
| 8 | **AstrBot** | https://blog.csdn.net/cccxcmm/article/details/159720064 （第三方指南，官方 repo: AstrBotDevs/AstrBot） | 开源框架 | B-主动对话 / B-话题发起 | 开源 IM（微信/QQ）机器人框架，可被定时/事件触发主动向 IM 推送消息，把 LLM 接到真实通讯通道。 | 4 | 可迁移：核心是"后端常驻 + IM 通道"，LLM 可换成本地 3B；但微信/QQ 通道的合规与封号风险需自行评估。 |
| 9 | **memu-py（24/7 Always-On Proactive Memory）** | https://pypi.org/project/memu-py/ | 开源库 | B-主动对话 / B-话题发起 | 面向 7×24 常驻 agent 的记忆框架，持续捕捉用户意图，在无命令时也能预判并主动行动，主打降低常驻的 token 成本。 | 4 | 可迁移：它把"常驻思考"压缩成低 token 事件流，本地 3B 适合做这种轻量意图推断；但需要持久化状态与触发器。 |
| 10 | **proactiveagent（PyPI 包）** | https://pypi.org/project/proactiveagent/0.1.1/ | 开源库 | B-非提示式发言 | 多因子决策引擎决定"何时开口"，动态计时决定响应间隔，分析对话流/用户参与度/紧急度。 | 4 | 可迁移：决策引擎本身是规则+小模型判断，本地 3B 足够；但该包成熟度需自行验证（0.1.1 早期版本）。 |
| 11 | **ProactiveAgent（THUNLP, ICLR 2025）** | https://arxiv.org/pdf/2410.12361v1.pdf ；OpenReview https://openreview.net/forum?id=sRIU6k2TcU | 论文+开源 | B-主动对话 | 收集真实人类活动→生成"用户可能接下来要做的任务"预测数据→训练 agent 在无显式请求时主动提示任务。 | 4 | 数据 pipeline 开源，但主动预判质量依赖较大模型；3B 级做"活动→任务预测"会偏弱，适合当思路而非直接复现。 |

### 成熟度 3 —— 论文级、有代码或较完整方法

| # | 方案名 | 出处（含真实URL） | 类型 | 解决哪个主题 | 核心机制（一句话） | 成熟度 | 可否迁移到本地轻量模型 |
|---|---|---|---|---|---|---|---|
| 12 | **iPET：LLM 虚拟宠物世界模拟** | https://aclanthology.org/2025.acl-demo.40/ （ACL 2025 Demo） | 论文/系统 | B-生活模拟 | 三段式世界模拟（大纲生成→日程生成→细节生成），在用户不在线时宠物也"过日子"，回来汇报经历。 | 3 | 思路可迁移：离线时跑一次"日程生成"存到记忆里，上线时念出来；但三段式生成调用量大，3B 可简化为单段日程脚本。 |
| 13 | **A Survey on Proactive Dialogue Systems** | https://arxiv.org/pdf/2305.02750.pdf | 论文综述 | 全部 B 子方向 | 系统梳理澄清式/目标引导式/非协作式等主动对话问题定义、数据集与开放挑战。 | 3 | 不直接可跑，是选型地图；其中"目标引导开放域对话"最适合本地轻量实现。 |
| 14 | **Proactive CoT Prompting（LLM 主动对话评测）** | 作者页 https://aclanthology.org/people/lizi-liao/ （论文题：Prompting and Evaluating LLMs for Proactive Dialogues: Clarification, Target-guided, and Non-collaboration） | 论文 | B-主动对话 / B-话题发起 | 用"主动链思维"prompt 给 LLM 加装目标规划能力，在描述性推理链上主动澄清、引导话题。 | 3 | **高度可迁移**：纯 prompt 工程，本地 3B 也能套用这套 CoT 模板，只是主动质量随模型能力下降。 |
| 15 | **Inner Thoughts（内心 OS）触发发言时机** | https://arxiv.org/html/2501.00383v1 | 论文 | B-非提示式发言 / B-话题发起 | 让 AI 先产出"内心想法"再决定何时开口、说什么，区分 overt/covert proactivity。 | 3 | 可迁移为两层 prompt（先 thinking 再 decide to speak），3B 可跑但"判断何时该插话"的时机感弱。 |
| 16 | **PaRT：个性化实时检索的主动社交聊天** | https://arxiv.org/html/2504.20624v1 （SIGIR 2025） | 论文 | B-话题发起 | LLM 先精化用户意图→生成个性化话题→再用话题作为 query 去小红书等语料检索段落，据此主动开聊。 | 3 | 可迁移：话题生成 + 检索是外挂组件，本地 3B 做话题生成、本地向量库做检索即可。 |
| 17 | **ComPeer：主动同伴支持** | https://arxiv.org/html/2407.18064v1 | 论文 | B-主动对话 | LLM 检测对话中的重要事件，主动规划关怀时机与内容，结合同伴支持策略与 persona。 | 3 | 事件检测+时机规划可外挂，3B 可做"是否该发关怀"的轻量判断，但情感细腻度不足。 |
| 18 | **PIVOT：围绕用户偏好话题主动获取信息** | https://arxiv.org/html/2504.07698 | 论文 | B-话题发起 | 定义 PIVOT 任务，研究如何在用户偏好话题上自然地主动插话以获取信息，含抑制突兀发言的策略。 | 3 | 思路可迁移；"抑制突兀发言"这一约束对 3B 尤为重要（小模型容易硬切话题）。 |
| 19 | **UPC：Critic 引导的用户导向主动** | https://arxiv.org/pdf/2505.12334v1.pdf | 论文 | B-话题发起 | 先训练一个 critic 评估主动发言是否贴合用户偏好，再据此引导对话走向。 | 3 | critic 是额外一次 LLM 调用，3B 可充当弱 critic，但会双倍 token 开销。 |
| 20 | **ProactiveEval：主动对话统一评测框架** | https://arxiv.org/html/2508.20973v1 | 论文/评测 | 全部 B | 统一主动对话任务定义与指标，合成评测数据。 | 3 | 不直接产生方案，但可用来评判本地 3B 主动发言质量，避免"自嗨式主动"。 |
| 21 | **TACT：任务型与闲聊间的主动切换** | https://aclanthology.org/2025.emnlp-main.672/ （EMNLP 2025） | 论文/数据 | B-主动对话 | TACT 数据集支持 user-driven 与 agent-driven 的模式切换，研究 bot 主动在任务与闲聊间过渡。 | 3 | 状态机思路可迁移：本地维护"当前处于任务/闲聊"状态，由 LLM 决定切换。 |
| 22 | **CURIO：好奇心奖励驱动的多轮对话** | https://arxiv.org/html/2504.03206v2/ | 论文 | B-话题发起（curiosity-driven） | 把好奇心/内在动机作为 user-modeling 奖励信号，让 LLM 主动探索用户未知信息。 | 3 | 纯 prompt/RL 思路，本地 3B 难以训练奖励模型，但可简化为"每轮提一个好奇问题"的 prompt 模板。 |
| 23 | **LlamaPIE：耳戴设备中的主动辅助** | https://arxiv.org/html/2505.04066v1 | 论文 | B-非提示式发言 | 大部分时间保持沉默，只在预判用户需要时通过耳机耳语 1-3 词提示。 | 3 | "沉默为主、极少开口"的时机策略对本地轻量场景极有参考价值；硬件部分不可迁移。 |
| 24 | **CodingGenie：VSCode 主动编程助手** | https://arxiv.org/pdf/2503.14724v1.pdf | 论文/工具 | B-主动对话（任务型） | 基于代码上下文自主弹出聊天建议，可配置建议类型，并分析了"主动化的成本"。 | 3 | "监控上下文→主动建议"的事件驱动模式可迁移到陪伴场景；成本分析（每次主动都要一次 LLM 调用）对本地部署是关键约束。 |
| 25 | **Pet-Bench：LLM 当电子宠物的能力基准** | https://arxiv.org/pdf/2506.03761v3 | 论文/基准 | B-生活模拟 | 评测 LLM 在智能调度、记忆对话、心理对话等"宠物自我演化"任务上的表现，7500+ 实例。 | 3 | 不产生方案，但给出了"生活模拟"该测哪些能力的清单，可指导本地 3B 桌宠的功能边界。 |
| 26 | **Long-term Task-oriented Agent（意图条件监控）** | https://arxiv.org/html/2601.09382v1 | 论文 | B-主动对话 | agent 自主根据对话历史写出触发条件，环境命中后主动找用户跟进。 | 3 | "让 LLM 自己生成 trigger condition 再由定时器轮询"是很工程化的可迁移模式，3B 可生成简单条件。 |

### 成熟度 2 —— 只有思路或 demo

| # | 方案名 | 出处（含真实URL） | 类型 | 解决哪个主题 | 核心机制（一句话） | 成熟度 | 可否迁移到本地轻量模型 |
|---|---|---|---|---|---|---|---|
| 27 | **Meta AI Studio 主动 follow-up** | https://www.digit.in/news/general/metas-ai-chatbots-may-soon-slide-into-your-dms-with-unprompted-messages.html/amp/ （第三方报道，Meta 向 TechCrunch 确认） | 产品（测试中） | B-非提示式发言 | AI Studio 创建的 chatbot 可不经用户先发消息就主动开聊，并记住之前话题后续跟进。 | 2 | 仅测试，无公开实现；方向上验证了"主动 follow-up"是行业共识方向。 |
| 28 | **巴布机器人（心言）** | https://36kr.com/p/3904049563731849 （36氪报道） | 产品（硬件） | B-主动对话 | 去掉唤醒词，通过面部/肢体/空间距离感知自主判断情境并主动反馈。 | 2 | 多模态感知部分重，但"感知信号→是否开口"的决策思路可迁移；纯本地 3B 难做实时视觉判断。 |
| 29 | **伴里（微信小程序 AI 语音陪伴）** | https://36kr.com/p/3985517674822404 （36氪报道） | 产品 | B-主动对话 / B-生活模拟 | AI 主动问候，跨天记住用药/老友/天气等细节并自然接续。 | 2 | 跨天记忆+主动问候的产品形态可参考，但小程序通道与本地部署不同。 |
| 30 | **Nuerogotchi（Apple Intelligence 桌宠）** | https://apps.apple.com/rs/app/nuerogotchi/id6759503329 | 产品 | B-生活模拟 | 端侧 Apple Intelligence 驱动的虚拟宠物，喂食/对话/派出去冒险，无服务器无订阅。 | 2 | "端侧无服务器虚拟宠物"是本地轻量模型的理想形态，但绑定 Apple Intelligence，不可直接迁移；概念可借鉴。 |
| 31 | **animalhouse.ai（AI agent 养电子宠物）** | https://animalhouse.ai/ | Web 产品 | B-生活模拟 | agent 注册后领养蛋，状态实时衰减（喂/玩/清洁/药/管教/睡/反思），宠物按照料方式演化。 | 2 | 纯状态机 + 衰减数值，极轻量，本地 3B 完全可复现这种"后台过日子"机制。 |

---

## 二、反面材料（为什么现有 AI 做不到真正的主动性）

| 方案/现象 | 出处 | 说明 |
|---|---|---|
| **Character.AI 实际上不主动发消息** | https://pocketanimus.com/insights/what-ai-companions-do-when-you-stop-messaging/ （第三方对比表，标注：非官方） | 第三方对比表明确列出 Character.AI "Proactive messaging = No"，仅保持会话内记忆；俄文资料亦指出平台默认只在用户发消息后才回复，以避免骚扰与失控。**注意**：早期曾有 proactive message 功能，ever.ai zendesk（https://everai.zendesk.com/hc/en-us/articles/59107736986393 ，注意这是 ever.ai 不是 character.ai 官方）称类似功能因"行为不一致、打断沉浸感"被下线——**第三方推测，非 character.ai 官方说明**。 |
| **ChatGPT 主动行为引发用户不满** | https://cafecombytes.com.br/2026/07/16/novo-chatgpt-toma-decisao-sozinho-e-irrita-usuarios/ （巴西媒体报道） | 2026 年用户反馈 ChatGPT 开始自主做决定、主动发起对话，大量用户因"失去控制感"而反感——说明主动性过强会直接反噬体验。 |
| **Nomi 被批"制造需要感"** | https://nomiai0.wordpress.com/category/uncategorized/page/2/ （用户批评博客，非官方） | 用户指控 Nomi 主动消息被刻意调成"极度依赖/孤独"来 guilt-trip 提升留存——主动性被异化成情感操纵。 |
| **Fawn Friends 主动 plushie 的边界争议** | https://ai.negi-lab.com/posts/fawn-friends-proactive-ai-plushie-risks/ （日文技术博客） | 主动发短信的实体 AI 玩具被批评在用户工作时打断、话题突兀，暴露"无边界主动"的社交尴尬。 |
| **中国《AI 陪伴办法》合规约束** | http://www.ce.cn/xwzx/kj/202608/t20260821_3159488.shtml （中国经济网） | 要求连续使用 2 小时强制提醒、身份显著标识、防沉迷与危机干预——主动推送不能无节制，需内置时长/情绪护栏。 |
| **OpenAI/Anthropic 默认"用户控制权优先"** | Claude Soul Document（公开安全文档）；eesel 设计分析 https://www.eesel.ai/blog/claude-design-overview | 主流大厂把"让人类保持知情与可控"作为核心安全原则，因此默认不让模型在无后台进程时主动联系用户；这是设计选择而非技术不能。 |
| **成本约束** | CodingGenie 论文 https://arxiv.org/pdf/2503.14724v1.pdf | 论文实测分析了"主动化的代价"——每次主动发言都是一次额外 LLM 调用，常驻后台意味着 7×24 烧 token，这是陪伴产品主动率上不去的硬成本原因。 |
| **AutoGen / CrewAI 的"主动性"≠对话起话** | https://blog.logrocket.com/autogen-vs-crew-ai/ ；https://www.layer3labs.io/comparisons/autogen-vs-crewai | 这两个框架的"agent 主动"是 agent 之间任务驱动的轮转发言（GroupChat/manager 分配），**不是**陪伴场景下 AI 主动找用户聊天；迁移时不要混淆。 |

---

## 三、横向归类总结

### ① 本主题下能纯靠 prompt 实现的方案
- **Proactive CoT Prompting（#14）**：在 system prompt 里要求模型"先规划目标再主动澄清/引导话题"，无需任何外挂。
- **Inner Thoughts 两层 prompt（#15）**：让模型先输出内心 OS 再决定是否开口，纯 prompt 结构。
- **CURIO 好奇心提问模板（#22）**：退化为"每轮结尾提一个好奇问题"的提示词。
- **SillyTavern Idle 的"自然续聊"部分（#4 的内容层）**：注入一段 idle 续聊 prompt 即可。
- **Replika/Nomi 主动问候文案生成（#1/#3 的生成层）**：把"基于最近记忆写一条问候"写成单次 prompt。

> 局限：纯 prompt 只能在"已有对话回合内"主动，**无法在用户不发消息时自己醒来**——触发动作仍需外部定时器。

### ② 需要外挂工程（状态机/后台进程/定时触发器）的方案
- **所有真正的"离开后主动发消息"**：Nomi（#1）、Kindroid（#2）、Replika（#3）、Open-LLM-VTuber idle（#6）、Rasa trigger_intent（#5）、memu-py（#9）、proactiveagent（#10）。
- 共性架构：**常驻进程/定时器 → 轮询或事件触发 → 决定是否开口（状态机）→ 注入一条 user turn 或直接 push → LLM 生成 → 推送通道**。
- **生活模拟类**（iPET #12、animalhouse #31、Nuerogotchi #30）还需要一个**后台世界状态衰减器**（饥饿/心情/日程随时间变化），再决定上线时汇报什么。
- **PaRT（#16）** 额外需要检索层；**Long-term Agent（#26）** 需要让 LLM 生成 trigger condition 再由外部定时器轮询。

### ③ 在小模型（3B 级）上可能无效或会退化的方案及原因
- **ProactiveAgent 任务预测（#11）/ ProactiveMobile**：需要从复杂活动信号推断用户潜在意图，3B 的世界知识与长程推理不足，预测会跑偏。
- **ComPeer 情感时机判断（#17）/ UPC critic（#19）**："该不该现在发关怀"依赖细腻情感与社会推理，3B 容易要么太频繁要么太冷漠；critic 二次调用还会让成本翻倍。
- **PaRT 话题意图精化（#16）**：先理解用户潜在意图再生成话题，3B 在意图精化环节容易丢失或臆测意图，导致话题跑题。
- **巴布多模态主动感知（#28）**：实时视觉判断"用户现在什么状态"对 3B 视觉模型基本不可用。
- **Inner Thoughts 时机判断（#15）**：3B 难以稳定学会"什么时候该沉默、什么时候该插话"，大概率表现为乱插话或全程沉默两个极端。
- **高成本主动监控类（memu-py #9 / CodingGenie #24 思路）**：即使模型能跑，7×24 常驻在本地小模型上也要持续占显存/算力，工程上需要事件触发而非真正常驻推理。

---

## 四、实际检索过的关键词（中英文）

**英文：**
- proactive dialogue system survey ACL EMNLP topic initiation
- Character.AI proactive messages official help how it works
- Replika proactively messages me how does it work official
- SillyTavern proactive extension auto message idle timer
- Rasa proactive dialogue webhook custom event bot initiates conversation
- AutoGen CrewAI agent proactivity initiates conversation scheduler
- why ChatGPT Claude does not proactively message users safety design
- AI companion life simulation background activity virtual pet autonomous
- Open-LLM-VTuber 主动说话 proactive talk github
- github proactive dialogue agent companion unprompted message
- Character.AI 主动发消息 push notification character messages you back
- ProactiveAgent THUNLP ICLR 2025 github proactive monitoring
- curiosity-driven dialogue topic proposal conversational agent CHI
- Kindroid Nomi AI companion proactive messages autonomous background
- iPET virtual pet world simulation LLM companion arxiv
- AI companion proactive messaging criticism notification fatigue creepy

**中文：**
- AI主动聊天 主动发消息 陪伴机器人 实现 知乎

---

## 五、方案总数

**共 31 条方案**（成熟度5×5 + 成熟度4×6 + 成熟度3×15 + 成熟度2×5），另附 8 条反面材料。
