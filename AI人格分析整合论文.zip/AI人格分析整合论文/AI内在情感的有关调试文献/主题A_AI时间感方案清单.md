# 主题A：AI 的时间感 / 时序感知 —— 方案侦察清单

> 子任务执行者：AI 主动性方案侦察员
> 整理日期：2026-09-27
> 范围：对话系统的 turn timing / agent 生活时间线 / time-aware 对话生成 / 延迟回复模拟
> 说明：本清单只收录检索中真实见到出处的方案；标注「第三方推测」者为社区解读而非官方机制。成熟度宁可低估。

## 子方向编号
- **A1**：对话系统如何感知与利用时间（turn timing, conversation clock, response latency）
- **A2**：LLM 如何维持自己的"生活时间线"（agent timeline, autobiographical memory）
- **A3**：时间敏感的对话生成（time-aware dialogue, temporal grounding）
- **A4**：延迟回复模拟（typing indicator, response delay modeling, read receipts）

---

## 一、方案清单（按成熟度降序）

### 成熟度 5 = 已产品化、有稳定复现

#### 1. OpenAI ChatGPT Memory + Dreaming（后台记忆综合）
- **出处**：https://help.openai.com/zh-hans-cn/articles/8590148 ；Dreaming 官方公告（2026-06-04，多语言版）；第三方拆解 https://dev.to/akaranjkar08/chatgpt-dreaming-v3-how-openai-rebuilt-memory-from-the-ground-up-june-2026-1jb3 、https://www.c114pro.com/ai/169757.html
- **类型**：产品（官方说明 + 第三方拆解）
- **解决主题**：A2（生活时间线 / 自传式记忆）
- **核心机制**：用户不说话时，后台异步进程跨多条对话综合出"记忆状态"，并随时间自动改写——官方示例是记忆从"你七月要去新加坡"在行程结束后自动变为"你2026年七月去过新加坡"，即记忆自带时态演进。
- **成熟度**：5
- **可否迁移到本地轻量模型**：机制可迁移（需要后台 cron + 一次额外的"记忆整理"LLM 调用），但本地无 OpenAI 那种跨会话用户数据层；3B 模型做跨对话摘要质量存疑。

#### 2. Anthropic Claude Memory Tool（memory_20250818）
- **出处**：https://docs.anthropic.com/en/docs/agents-and-tools/tool-use/memory-tool ；API https://platform.claude.com/docs/en/api/beta/memory_stores/memories.md
- **类型**：产品（官方 API/文档）
- **解决主题**：A2
- **核心机制**：把记忆当作一个持久化文件目录（如 `/projects/foo/notes.md`），Claude 自己 create/read/update/delete，做 just-in-time 检索；本身不带时钟，但路径/文件可由宿主写入时间戳。
- **成熟度**：5
- **可否迁移**：思路完全可迁移——本地用一个 memory 文件夹 + 每次会话开头注入"今天日期"即可，3B 也能模仿"写 md / 读 md"的工具调用。

#### 3. Google Gemini Memories / Memory Bank
- **出处**：https://9to5google.com/2024/11/19/gemini-remember-saved-info/ ；企业版 Memory Bank https://docs.cloud.google.com/gemini-enterprise-agent-platform/scale/memory-bank/generate-memories ；官方博客 https://blog.google/innovation-and-ai/products/gemini-app/switch-to-gemini-app/
- **类型**：产品（官方文档 + 媒体）
- **解决主题**：A2
- **核心机制**：用户可显式说"记住…"存入 saved memory；企业版 Memory Bank 做 extraction → consolidation（去重/更新矛盾记忆）；另有记忆导入功能从其他 AI 拷贝偏好。
- **成熟度**：5
- **可否迁移**：可迁移（抽取-合并两阶段），但本地需自建向量库与去重逻辑；纯 prompt 只能做显式记忆。

#### 4. Replika 分层记忆（Memory Tab + 深层模式）
- **出处**：官方帮助 https://help.replika.com/hc/en-us/articles/37208679176077-How-does-Replika-s-memory-work ；第三方实测 https://bae.ppl.studio/guides/how-to-make-an-ai-remember-you 、https://pocketanimus.com/guides/can-ai-companions-remember-everything/
- **类型**：产品（官方说明 + 第三方实测）
- **解决主题**：A2
- **核心机制**：可见 Memory Tab 存结构化事实，另有更深层从全部对话历史抽模式；被描述为长期"日记"可被检索， weeks 后召回细节。
- **成熟度**：5
- **可否迁移**：部分——"记忆盒子 + 向量检索"可在本地复刻；"深层模式"是黑盒，无法迁移。

#### 5. Character.AI Pinned Memories + Chat Memories
- **出处**：第三方实测 https://pocketanimus.com/guides/character-ai-memory/ 、https://www.aiangels.io/blog/replika-vs-character-ai-2000-messages-sister-dog-name-memory （非官方，属第三方推测/实测）
- **类型**：产品（第三方说明，官方未给机制细节）
- **解决主题**：A2
- **核心机制**：可手动 pin 最多 15 条消息常驻上下文（早期仅 5 条）；其余靠滚动上下文窗口 + 对话摘要；默认每个新对话独立，不跨会话累积。
- **成熟度**：4（功能上线但机制黑盒，第三方口径）
- **可否迁移**：完全可迁移——"置顶 N 条关键消息常驻 system prompt"是本地最容易复刻的一招，3B 即可。

---

### 成熟度 4 = 有开源实现、可直接跑

#### 6. SillyTavern 时间宏 + World Info Timed Effects
- **出处**：官方宏文档 https://docs.sillytavern.app/usage/core-concepts/macros/ ；World Info https://docs.sillytavern.app/usage/core-concepts/worldinfo/ ；代码级分析 https://neoneye.github.io/agent-memory-atlas/systems/sillytavern/
- **类型**：开源产品（官方文档）
- **解决主题**：A1 / A3
- **核心机制**：prompt 里写 `{{time}}` `{{date}}` `{{weekday}}` `{{isodate}}` `{{datetimeformat::...}}` 由前端在生成时替换为系统当前时间；World Info 条目支持 sticky/cooldown/delay（按"消息条数"计时，不是真实时钟）。
- **成熟度**：4
- **可否迁移**：这是本地轻量模型最直接可用的方案——前端/启动脚本拼系统时间戳进 prompt 即可，无需训练。注意：timed effects 按消息数算，不是墙钟时间。

#### 7. MemoryBank（艾宾浩斯遗忘曲线记忆）
- **出处**：论文 https://arxiv.org/pdf/2305.10250.pdf ；官方 repo https://github.com/zhongwanjun/MemoryBank-SiliconFriend ；代码批判 https://neoneye.github.io/agent-memory-atlas/systems/memorybank/
- **类型**：论文 + 开源（AAAI 2024）
- **解决主题**：A2
- **核心机制**：每条记忆带 strength，按艾宾浩斯遗忘曲线 `R(t)=e^{-t/S}` 随真实时间衰减，被检索到时强化；相似度 + 时间衰减共同决定注入哪些记忆。
- **成熟度**：4（有完整 repo）
- **可否迁移**：可迁移——本质是一个打分公式（时间衰减 + 访问强化），3B 只负责生成自然语言，衰减逻辑在宿主 Python 里算。注意第三方代码审查指出其开源实现强度/衰减方向可能与论文相反，二次开发需自测。

#### 8. CrewAI `inject_date: true` + 记忆事件时间戳
- **出处**：官方 Agents 文档 https://docs.crewai.com/concepts/agents ；Memory 文档 https://docs.crewai.com/concepts/memory
- **类型**：开源框架（官方文档）
- **解决主题**：A1 / A3
- **核心机制**：Agent 开 `inject_date: true` 即在 prompt 注入当前日期（可用 `date_format` 自定义）；记忆事件带 `save_time_ms` / `retrieval_time_ms`。
- **成熟度**：4
- **可否迁移**：可迁移——一行配置级别的时间注入，本地任何框架照抄即可。

#### 9. AG2 / AutoGen 系：按天落盘的时间戳记忆摘要
- **出处**：https://docs.ag2.ai/latest/docs/blog/2026/03/16/AG2-Beta/ （`memory/user_id/YYYY-MM-DD.md`）；https://docs.ag2.ai/latest/docs/beta/advanced/aggregation/ （ConversationSummaryAggregate + EpisodicMemoryPolicy）
- **类型**：开源框架（官方文档）
- **解决主题**：A2
- **核心机制**：把每天对话写成 `YYYY-MM-DD.md` 文件；ConversationSummaryAggregate 写带时间戳摘要到 `/memory/conversations/`，EpisodicMemoryPolicy 再读回。
- **成熟度**：4
- **可否迁移**：可迁移——按日期分文件 + 摘要就是本地轻量方案的范本；3B 可做摘要。

#### 10. Rasa：Duckling 时间实体抽取 + current_datetime 注入
- **出处**：https://rasa.com/docs/reference/config/components/llm-command-generators/ （模板注入 Current date/time/day）；https://rasa.com/docs/rasa/2.x/domain/ （`time` 实体）；牙科诊所示例 https://rasa.com/blog/building-an-ai-agent-for-a-dental-clinic-with-rasa
- **类型**：开源框架（官方文档）
- **解决主题**：A1 / A3
- **核心机制**：用 Duckling 从用户话里抽"明天/下周三"等相对时间实体成 slot；同时把 `current_datetime` 格式化后注入 LLM 命令生成模板，让模型知道"现在是几点几号"。
- **成熟度**：4
- **可否迁移**：可迁移——Duckling（或本地正则/小模型）抽时间实体 + 系统时间注入是标准工程件。

#### 11. OpenClaw：Heartbeat 心跳 + cron + 按日记笔记
- **出处**：官网 https://open-claw.org/ ；拆解 https://enricopiovano.com/blog/openclaw-open-source-ai-assistant-overview/ 、https://smartstackdev.com/master-ai-agents-with-openclaw/
- **类型**：开源项目（MIT）
- **解决主题**：A2 / A4（主动/异步）
- **核心机制**：默认每 30 分钟触发一次后台"心跳"，agent 读 `HEARTBEAT.md` 决定是否主动发消息；`memory/YYYY-MM-DD.md` 记当天，`MEMORY.md` 存提炼后的偏好；支持 cron 定时主动推送。
- **成熟度**：4
- **可否迁移**：可迁移但重——需要常驻后台进程（Python `schedule` + 线程），不是纯 prompt；3B 模型可当大脑，但心跳调度必须外挂。

#### 12. CortexGraph fastMCP：MCP 服务化的时间衰减记忆
- **出处**：https://pypi.org/project/cortexgraph-fastmcp/
- **类型**：开源（PyPI 包，MCP server）
- **解决主题**：A2
- **核心机制**：把记忆做成 MCP server，内置类艾宾浩斯衰减——不被使用就随时间淡化（示例表：7 天后 score 0.210 "Decaying"）。
- **成熟度**：4
- **可否迁移**：可迁移——直接装包接 MCP，本地模型无需自己实现衰减公式。

#### 13. Tavus 实测：2.3s 延迟 + typing indicator ≈ 秒回满意度
- **出处**：https://www.tavus.io/post/latency-of-response-in-conversational-ai
- **类型**：工程博客（引用 209 人对照实验）
- **解决主题**：A4
- **核心机制**：有 typing indicator 时 2.3 秒延迟的满意度（5.62/7）与秒回（5.67/7）统计上无差异；同延迟无 indicator 掉到 4.40。
- **成熟度**：4（结论有对照实验支撑，可直接当产品参数）
- **可否迁移**：可迁移——前端显示"正在输入…"+ 人为等待 1–2.5 秒再出字即可，与模型大小无关。

---

### 成熟度 3 = 论文级、有代码但不完整

#### 14. Chronos：双日历时间感知长期记忆
- **出处**：https://arxiv.org/html/2603.16862v1
- **类型**：论文
- **解决主题**：A2 / A3
- **核心机制**：维护两份日历——事件日历（抽出来的带结构化 datetime 区间的事件）+ 轮次日历（原始对话），配合 turn 级稠密检索和按查询动态 prompt，回答"过去某时聊过什么"。
- **成熟度**：3
- **可否迁移**：思路可迁移（事件打时间戳 + 双层索引），但多分辨率时间抽取依赖强模型；3B 做事件抽取易漏。

#### 15. GapChat：跨会话时间间隔感知
- **出处**：https://arxiv.org/pdf/2310.15415v1
- **类型**：论文 + 数据集
- **解决主题**：A3
- **核心机制**：构建多轮次对话数据集，相邻 session 之间的时间间隔随机变化，让模型学会根据"隔了多久"决定哪些话题还有效、该问什么。
- **成熟度**：3
- **可否迁移**：数据/训练思路难直接迁移；但"在 prompt 里写上'距离上次对话已过去 X 天'"这一招可纯外挂实现。

#### 16. Theanine：关系链记忆 + 时间线增强生成
- **出处**：https://arxiv.org/html/2406.10996v2/
- **类型**：论文（含 TeaFarm 评测）
- **解决主题**：A2
- **核心机制**：不删记忆，而是按时间与因果关系把记忆串成链；生成时把"相关记忆的时间线"作为上下文注入，呈现事件演化/因果。
- **成熟度**：3
- **可否迁移**：部分——"按时间排序取最近 K 条 + 事件间因果标注"可外挂，但自动建因果图对小模型偏难。

#### 17. Echo：带时间情景记忆的 LLM
- **出处**：https://arxiv.org/html/2502.16090v1/
- **类型**：论文（含合成数据 EM-Train）
- **解决主题**：A2
- **核心机制**：训练时给每段对话注入时间背景，专门增强情景记忆能力；用角色-剧情-环境三要素合成训练数据。
- **成熟度**：3
- **可否迁移**：这是训练侧方案，本地 3B 若不重训则无法获得；可借鉴的是"每条记忆带时间戳"的数据格式。

#### 18. TIMER：从"回什么"到"何时回"
- **出处**：https://arxiv.org/pdf/2506.14285v1
- **类型**：论文
- **解决主题**：A4
- **核心机制**：训练模型预测合适的回复时机（用 user-simulator 生成"agent 在 X 分钟后回复"的事件驱动对话数据），而不只是预测回复内容。
- **成熟度**：3
- **可否迁移**：训练侧；但"根据上下文决定该不该立刻回 / 等一会回"的决策可用规则（如：情感强就快回，事实查询就快回，闲聊就延迟）外挂近似。

#### 19. Time-R1：3B 量级时序推理 RL
- **出处**：https://arxiv.org/html/2505.13508v2
- **类型**：论文
- **解决主题**：A3
- **核心机制**：用三阶段 RL（规则奖励曲线）把一个 3B 模型练出时间理解、未来预测、时间创意生成能力。
- **成熟度**：3
- **可否迁移**：是少数明确在 3B 上做的时序工作，但需 RL 训练管线，普通本地用户复现门槛高；不训练的话 3B 原生时序推理仍弱（见反面材料）。

#### 20. 超长对话记忆评测（事件图 + 日期）
- **出处**：https://ar5iv.labs.arxiv.org/html/2402.17753
- **类型**：论文（评测基准）
- **解决主题**：A2
- **核心机制**：把用户生活建成带发生日期 t_i 的事件图，事件间有因果边，跨度 6–12 个月、最多 25 个事件，评测 agent 能否按时间线回忆。
- **成熟度**：3
- **可否迁移**：提供了"自传式记忆该长什么样"的 schema（事件+日期+因果边），可直接当本地记忆数据结构。

#### 21. Tap-to-Adapt：语音 agent 回复时机在线学习
- **出处**：https://arxiv.org/pdf/2603.14449
- **类型**：论文
- **解决主题**：A1（语音 turn-taking）
- **核心机制**：用用户点按/打断作为在线标签，训练 Dilated TCN 时序模型让语音 agent 的开口时机贴合用户节奏。
- **成熟度**：3
- **可否迁移**：语音向，文本陪伴场景参考价值有限；核心启示是"回复时机是可学习的时序信号"。

#### 22. MRTM：客服多轮"该不该现在回"触发模型
- **出处**：https://dl.acm.org/doi/pdf/10.1145/3394486.3403390 （SIGIR/CIKM 系）
- **类型**：论文
- **解决主题**：A4
- **核心机制**：从大规模人-人客服对话自监督学习"何时该触发回复"，避免每句都回导致打断。
- **成熟度**：3
- **可否迁移**：可借鉴规则化——只在用户问句/情感句后回复，陈述性自言自语不打扰。

#### 23. FADEMEM / Oblivion：生物启发的记忆衰减
- **出处**：https://arxiv.org/pdf/2601.18642 ；https://arxiv.org/html/2604.00131
- **类型**：论文
- **解决主题**：A2
- **核心机制**：用可变指数函数 `v_i(t)=v_i(0)·exp(-λ_i(t-τ_i)^β_i)` 按记忆重要性差异化衰减，呈锯齿状（衰减+被召回时回弹）。
- **成熟度**：3
- **可否迁移**：衰减公式可在宿主侧实现，比 MemoryBank 更细；但评测/实现不完整。

---

### 成熟度 2 = 只有思路或 demo

#### 24. 按"上下文条目"打时间戳 + 过期衰减补丁
- **出处**：https://donbard.com/the-llm-time-blindness-patch/ ；https://koutian.is-a.dev/posts/2026/04/time-position-encoding-agent-state/
- **类型**：工程博客（思路）
- **解决主题**：A1 / A2
- **核心机制**：不要只在会话开头给一次冻结时间戳；给每条检索回来的记忆/事实标注它的"录入时间"，并按事实类型加衰减权重，避免把旧价格/旧身份当当前。
- **成熟度**：2
- **可否迁移**：完全可迁移，纯外挂（检索结果拼 `[记录于 2026-03-12]`），3B 也能用。

#### 25. ProactiveAgent：wake→decide→respond→sleep 主动循环
- **出处**：https://leomariga.github.io/ProactiveAgent/getting-started/ ；https://pypi.org/project/proactiveagent/0.1.1/
- **类型**：开源 demo（PyPI 0.1.1，早期）
- **解决主题**：A4（主动/异步）
- **核心机制**：agent 按调度周期醒来，评估对话状态决定是否主动发消息，再算下次唤醒时间休眠。
- **成熟度**：2（包很早期，demo 级）
- **可否迁移**：思路可迁移，但需常驻进程；与 OpenClaw 心跳同思路。

#### 26. 掘金：从碎片记忆到"时间线 chapters + 第一人称叙事"
- **出处**：https://juejin.cn/post/7672695131032354868 ；角色一致性篇 https://juejin.cn/post/7660702273779449891
- **类型**：中文工程博客
- **解决主题**：A2
- **核心机制**：提出记忆分三轨道——碎片（事实）+ 时间线 chapters（让"上次/上上次/今天"成立）+ 第一人称叙事；记忆要有合并/衰减/重要性而非无脑 append。
- **成熟度**：2（经验总结，非完整实现）
- **可否迁移**：时间线分章可用 markdown 文件按日期分章实现；3B 做叙事化总结可行。

#### 27. Mudguy：NPC 昼夜作息 / 自然入睡节律
- **出处**：GitHub 项目介绍页（Mudguy: AI NPC Agent System，2026-04，搜索摘要）
- **类型**：开源 demo（文字世界 NPC 系统）
- **解决主题**：A2 / A4
- **核心机制**：NPC 按活跃度在不同时间"睡觉"（上下文耗尽），最后一个 NPC 睡后开新一天，全员带昨日摘要醒来；形成世界自然入夜节律。
- **成熟度**：2
- **可否迁移**：机制简单（模拟一天循环 + 摘要），本地可复刻，但属游戏 NPC 范式。

---

## 二、反面材料：为什么现有 AI 做不到自然时间感

> 这部分是"限制在哪"的证据，不是方案，但对判断迁移边界很关键。

| 现象 | 出处 | 要点 |
|---|---|---|
| 多轮 agent 时间盲 | https://aclanthology.org/2026.findings-acl.1848.pdf （arXiv 2510.23853） | LLM agent 默认在静止上下文里运行，不感知两条消息间真实流逝时间；**即使显式注入时间信息，仍与人类时间感知不对齐**。导致工具调用要么重复要么漏调。 |
| 真实时限下策略崩溃 | https://arxiv.org/html/2601.13206v1 | 限时谈判中，time-aware 条件成交率 32% vs 对照组 4%（GPT-5.1）；但在"按轮次计数"限制下成交率≥95%——**失败在计时而非策略推理**。 |
| 模型能否感知时间 | https://arxiv.org/pdf/2604.00010v1 | GPT-5/GPT-4o/Qwen3/OLMo3 在"上下文隐含时间"判断上接近随机（C-I 任务 18%–80%，机会基线 50%）。 |
| 冻结时刻问题 | https://enpulsed.com/the-stunning-reason-ai-cant-read-a-clock/ ；https://www.scien.cx/2026/06/28/the-stale-context-problem-why-your-ai-doesnt-know-what-time-it-is/ | 模型只在会话开始拿到一次时间戳，之后不更新、不跨会话；所有上下文被当作"现在"。 |
| Transformer 无时长感知 | https://habr.com/en/articles/1033578/ | 推理：模型只有 token 序列与步序计数，没有持续时长感知；"知道几点"完全靠 prompt 里塞时间戳现场算。 |
| 无内置时钟 / 知识截止 | https://www.dailyliving.ai/p/ai-doesn-t-know-what-day-it-is-it-won-t-say-so ；https://aiinsightsnews.net/chatgpt-claude-cant-tell-the-time/ | 模型本身不读设备时钟、不跟踪位置；训练数据有截止日；相对时间（"六周前"）尤其难。 |
| 36氪评 GPT-5 "时间感" | https://36kr.com/p/3556778391075717 | OpenAI 高管称 GPT-5 的突破是让模型判断问题难度、分配自己的"思考时间"——但这是**推理算力调度**，不是对墙钟时间的体验。 |
| 抖音科普 | https://www.iesdouyin.com/share/video/7680172793878564130 | 口语化佐证：AI 能答"距上次多久"是因为程序把两个时间戳一起发给它现场相减，不是它真的经历了间隔。 |

---

## 三、按落地方式分类（结尾要求）

### ① 纯靠 prompt 就能实现的（无需额外工程）
- 在 system prompt 注入 `{{date}} {{time}} {{weekday}}`（SillyTavern/CrewAI/Rasa 都这么做）——让模型会说"早上好/深夜了"。
- 告诉模型"现在距上次对话已过去 N 天"，让它调整寒暄与话题接续（GapChat 的外挂版）。
- 显式要求模型区分时态、把"明天/下周"等相对时间与当前日期做换算。
- 置顶 N 条关键记忆常驻 prompt（Character.AI pinned 思路）。
- 规则化"何时该回"：问句/情感句才主动回，陈述句不打扰（MRTM 的 prompt 近似）。

### ② 需要外挂工程的（注入时间戳 / 状态机 / 后台进程）
- **每条记忆/事实打录入时间戳**并做检索期过滤与衰减（donbard/koutian 补丁、Chronos 双日历）。
- **记忆衰减调度**：艾宾浩斯曲线打分（MemoryBank、CortexGraph fastMCP、FADEMEM）——需宿主数据库 + 时间字段。
- **按天落盘 / 摘要**：`memory/YYYY-MM-DD.md` + 会话摘要（AG2、OpenClaw）。
- **后台心跳 / cron 主动发消息**：OpenClaw Heartbeat、ProactiveAgent——必须常驻进程。
- **后台"做梦"整理记忆**：OpenAI Dreaming 式的跨会话异步综合，需离线 job。
- **typing indicator + 人为 1–2.5s 延迟**（Tavus 结论）——前端层。
- **相对时间实体抽取**：Duckling/正则把"下周三"解析成绝对日期（Rasa）。

### ③ 在 3B 级小模型上可能无效的方案及原因
- **自动建因果记忆图 / 事件因果链**（Theanine、超长记忆事件图）：3B 抽不准事件、判不准因果，会产生错误时序关系。
- **跨多会话后台记忆综合**（Dreaming、Chronos 的事件抽取）：长文档摘要 + 时间区间抽取对小模型质量不足。
- **原生时序推理 / 真实限时决策**：反面论文证明连 GPT-5 在"上下文隐含时间"判断上都近随机，3B 更弱；Time-R1 虽在 3B 上做，但需要整套 RL 管线，不是开箱即用。
- **nuanced 的 elapsed-time 体感**（"隔了多久该用什么情绪口吻"）：3B 容易要么全当刚发生、要么时间概念混乱。
- **在线学习回复时机**（Tap-to-Adapt 的时序模型）：需要专门的时序模型训练，不是换个 prompt 能解决。
- 注：3B 能做好的是"被工程喂对时间戳后，按指令套用格式/时态"——即它是**时间的执行者，不是时间的感知者**。

---

## 四、实际检索过的关键词（中英文）

**中文：**
- AI 时间感 聊天机器人 延迟回复 生活时间线 知乎
- 掘金 角色扮演 AI 时间流逝 设定 时间线 记忆 实现

**英文：**
- time-aware dialogue generation LLM temporal grounding arxiv
- conversation response latency timing turn-taking chatbot typing indicator
- agent autobiographical memory timeline LLM long-term memory personalization
- OpenAI ChatGPT memory feature official documentation how it works
- Anthropic Claude persistent memory API official docs
- SillyTavern time aware extension world info timestamp
- Google Gemini memory feature how it works saved info
- Character.AI persona memory how remembers across chats Replika
- AutoGen CrewAI agent memory timestamp conversation history time
- AI companion has no sense of time no background clock limitations why
- Rasa dialogue system time entity slot datetime extraction
- LLM agents no temporal awareness timing order pacing study
- GitHub AI companion scheduled messages proactive outreach async chat memory timestamp open source
- ChatGPT dreaming background memory process OpenAI 2026
- MemoryBank Ebbinghaus forgetting curve time decay episodic memory LLM
- "when to respond" social timing conversation delay model chatbot human-like pacing

**检索说明：**
- 知乎/少数派具体文章多在登录墙后，本次未取得全文，仅以掘金公开文、36氪、抖音公开视频作为中文社区侧证据；知乎侧标注为"未获取全文"。
- Character.AI 官方未公开记忆机制文档，本清单中其机制均来自第三方实测/推测，已在条目内标注。
- 未找到 OpenDialog（开源对话框架）专门的时间感机制页面，故未列入。
