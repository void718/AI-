AI陪伴「人味准则」研究报告

如何让AI陪伴角色像真人一样回复——权威资料检索与行为准则提炼

检索日期：2026年9月27日｜覆盖来源：32条｜第一层论文：14篇｜研究维度：7项

右键更新目录以显示内容

# 研究概览

本报告围绕「AI陪伴如何像人一样回复」这一主题，系统检索了 32 条经 URL 验证的权威来源，其中第一层同行评审论文 14 篇，覆盖全部 7 个研究维度，中英文资料均有收录，提炼出 25 条可操作准则并识别出 10 项研究缺口。

# 一、检索关键词矩阵

## 1.1 中文检索词（10组）

1. 共情对话生成 共情回复 语言学机制

2. 人格一致性 对话系统 persona consistency

3. 对话连贯性 多轮上下文 人格漂移检测

4. 语气词 停顿 迟疑 自我修正 文本对话自然度

5. 长期记忆 个性化对话 陪伴AI记忆机制

6. 拟人化 恐怖谷 AI伴侣 用户感知

7. 用户依恋 准社会关系 AI陪伴 伦理边界

8. 图灵测试 人类相似度评分 对话评测 PAS量表

9. 情感支持对话 心理健康 chatbot 安全边界

10. Character.AI Replika 用户研究 陪伴机器人

## 1.2 English Keywords (10 groups)

1. empathic dialogue generation empathic response NLP

2. persona consistency dialogue systems persona grounding

3. dialogue coherence long-term conversation context tracking

4. disfluency filler hesitation self-repair text conversation naturalness

5. long-term memory companion AI personalized dialogue memory-augmented

6. anthropomorphism uncanny valley chatbot humanlikeness perception

7. parasocial relationship AI attachment companion AI ethics safety

8. Turing test human-likeness rating dialogue evaluation PAS scale

9. emotional support conversation mental health chatbot safety boundary

10. Replika Character.AI user study companion chatbot longitudinal

# 二、资料清单（按来源层级）

## 2.1 第一层 同行评审论文（14篇）

### 2.1.1 维度1-4（人格一致 / 共情 / 非语言线索 / 记忆）

① Will I Sound Like Me? Improving Persona Consistency in Dialogues through Pragmatic Self-Consciousness

Kim, Kim & Kim｜EMNLP 2020｜证据强度：中｜维度1｜

② You Impress Me: Dialogue Generation via Mutual Persona Perception (P²Bot)

Liu et al.｜ACL 2020｜证据强度：中｜维度1｜

③ Towards Empathetic Open-domain Conversation Models: A New Benchmark and Dataset (EmpatheticDialogues)

Rashkin, Smith, Li & Boureau｜ACL 2019｜证据强度：强｜维度2｜

说明：奠基论文，25k对话+32种情绪

④ MoEL: Mixture of Empathetic Listeners

Lin, Madotto, Shin, Xu & Fung｜EMNLP-IJCNLP 2019｜证据强度：强｜维度2｜

⑤ Enhancing Naturalness in LLM-Generated Utterances through Disfluency Insertion

Hassan, Lison & Halvorsen｜arXiv 2024 (v2 2025)｜证据强度：中｜维度3｜

⑥ Beyond Words: Infusing Conversational Agents with Human-like Typing Behaviors

Zhou & Hu｜ACM CUI 2024｜证据强度：中｜维度3｜

⑦ LongMemEval: Benchmarking Chat Assistants on Long-Term Interactive Memory

Wu, Wang, Yu, Zhang, Chang & Yu｜ICLR 2025｜证据强度：强｜维度4｜

### 2.1.2 维度5-7（拟人化 / 依恋伦理 / 评测方法）

⑧ Beyond Disposition: AI Knowledge Predicts Anthropomorphization of a Language Model Better Than Personality Traits

Mara, Bauer, Tschopp, Grosswieser & Kraus｜CHI 2026｜证据强度：强｜维度5｜

说明：N=437对照实验

⑨ Attachment Theory as a Framework to Understand Relationships with Social Chatbots: A Case Study of Replika

Xie & Pentina｜HICSS-55, 2022｜证据强度：中｜维度6｜

说明：14人深度访谈

⑩ On the Dark Side of AI Companions – Parasocial Preference and Pathological Chatbot Use

Fröbel, Louis & Kenning｜HICSS-59, 2026｜证据强度：中偏强｜维度6｜

说明：Replika+Character.AI双研究复制

⑪ 从准社交互动到依恋：人智情感关系的演变

吴燕, 耿晓伟, 周晓林｜《心理科学》2025, 48(4): 948–961（CSSCI核心）｜证据强度：中｜维度6｜

⑫ Perceived Intelligence and Perceived Anthropomorphism of Personal Intelligent Agents: Scale Development (PAS)

Moussawi & Koufaris｜HICSS-52, 2019｜证据强度：强｜维度7｜

说明：经典量表，6题拟人化+5题智能感知

⑬ People cannot distinguish GPT-4 from a human in a Turing test

Jones & Bergen｜arXiv 2024（预注册随机对照实验）｜证据强度：强｜维度7｜

说明：GPT-4 54%被判为人，真人67%

⑭ Towards a Human-like Open-Domain Chatbot (Meena / SSA指标)

Adiwardana et al. (Google)｜arXiv 2020｜证据强度：强｜维度7｜

说明：SSA逐轮双维评分范式

## 2.2 第二层 权威机构报告（4条）

⑮ The 2026 AI Index Report — Chapter 9: Public Opinion

Stanford HAI｜2026年4月｜证据强度：强｜维度6、7｜

⑯ AI Companions May Worsen Loneliness for Vulnerable Users（发表于 Nature Human Behaviour）

Stanford HAI / Diyi Yang Lab｜2026年8月｜证据强度：强｜维度6、2｜

说明：1,131名Character.AI用户+244份聊天记录

⑰ How Teens Use and View AI

Pew Research Center｜2026年2月｜证据强度：强｜维度6、7｜

说明：n=1,458青少年，全美代表性样本

⑱ EU AI Act Article 50 — Transparency Obligations

European Commission｜2026年8月生效｜证据强度：强｜维度6、5｜

说明：法律条文：chatbot须告知AI身份；emotion recognition须告知

## 2.3 第三层 大厂/实验室技术博客（5条）

⑲ How People Use Claude for Support, Advice, and Companionship

Anthropic｜2025年6月｜证据强度：强｜维度2、6、7｜

说明：450万对话中131,484条情感对话分析

⑳ Emotion Concepts and Their Function in a Large Language Model（Claude Sonnet 4.5可解释性）

Anthropic Interpretability｜2026年4月｜证据强度：强｜维度2｜

说明：171个情绪概念神经元簇

㉑ Dreaming: Better Memory for a More Helpful ChatGPT

OpenAI｜2026年6月｜证据强度：中-强｜维度4｜

说明：后台dreaming进程+记忆时效衰减

㉒ Advanced Audio Dialog and Generation with Gemini 2.5（Affective Dialog）

Google DeepMind｜2025年6月｜证据强度：中｜维度3、2｜

㉓ The Design and Implementation of XiaoIce, an Empathetic Social Chatbot

Microsoft Research（周明等）｜2018起持续更新｜证据强度：强｜维度2、7｜

说明：CPS指标体系+EQ优先设计

## 2.4 第四层 高质量工程实践（5条）

㉔ Replika “Lobotomy” 事件与 r/Replika 社区长期用户数据

Reddit r/replika (15.2万成员) / The Companion Report｜2023年2月事件，回顾至2026｜证据强度：中｜维度1、4、6｜

说明：大规模社区自然实验

㉕ How to Add Long-Term Memory to AI Companions: A Step-by-Step Guide

Mem0｜2026年9月｜证据强度：中｜维度4｜

说明：可运行代码+user_id/companion_id双层隔离

㉖ Prompting Voice Agents to Sound More Realistic（LiveKit / Vapi / PolyAI 填充词指南）

LiveKit 2026.2 / Vapi Docs / PolyAI Voice Polish｜2026年｜证据强度：中｜维度3｜

说明：每轮2-4个disfluency基线+四类填充词

㉗ Investigating the Representation of Backchannels and Fillers in Fine-tuned Language Models

arXiv 2509.20237｜2025年9月｜证据强度：中-强｜维度3｜

说明：受控实验：SFT后backchannel/filler表征显著增强

㉘ The Quasi-Creature and the Uncanny Valley of Agency

arXiv 2508.18563｜2025年8月｜证据强度：中｜维度5｜

说明：Agency恐怖谷理论综合+Kishnani n=60实证

## 2.5 中文资料补充（4条）

㉙ AI陪伴硬件角色系统架构：为什么“一段Prompt”带不动长期人格

稀土掘金｜2026年8月｜证据强度：中｜维度1、4｜

说明：三层记忆体架构+主动召回

㉚ SillyTavern：长线AI角色扮演的退化与对策

稀土掘金｜2026年5月｜证据强度：中-弱｜维度1、3｜

说明：情绪平均化+折中即班味

㉛ DeepSeek、Gemini谁更能提供情感支持？趣丸×北大情绪轨迹动态评估

趣丸科技×北京大学 / 腾讯新闻｜2025年12月｜证据强度：中-强｜维度7、2｜

说明：情感动态轨迹分析框架+因果校准

㉜ AI男友会干掉传统乙游吗？（人格漂移用户亲历）

澎湃新闻｜2026年6月｜证据强度：中｜维度1、6｜

说明：OOC案例+用户访谈

## 2.6 无据声明（单独列出，不编入准则）

1. “AI只要加了emoji和语气词就像人”——无权威来源支撑，仅为民间经验，且Hassan 2024证明过量填充词反而降低可懂度。

2. “陪伴AI的记忆越长越好”——LongMemEval 2025证明长上下文≠记忆好，无限制记忆会召回过期偏好。

3. “越像人用户越喜欢”——Mara CHI 2026证明对高AI素养用户，过度拟人化反而引发不适。

4. 中文第一层（CCL/NLPCC/中文核心期刊）中关于“非语言线索文本化”的专门实证论文——本次检索未找到经URL核实的同行评审论文，标记为缺失。

# 三、人味准则表（核心产出）

以下 25 条准则从 32 条来源中提炼、去重、合并而成，每条均落到具体回复行为。证据强度：强＝大规模实证/法规/被广泛引用；中＝有实验但样本有限或行业共识；弱＝个人经验/无受控实验。

| # | 准则（具体回复行为） | 来源 | 证据强度 | 适用场景 | 反例（什么做法反而不像人） |
|---|---|---|---|---|---|
| 维度1 · 对话连贯性与人格一致性 | 维度1 · 对话连贯性与人格一致性 | 维度1 · 对话连贯性与人格一致性 | 维度1 · 对话连贯性与人格一致性 | 维度1 · 对话连贯性与人格一致性 | 维度1 · 对话连贯性与人格一致性 |
| 1 | 定稿前做自我一致性自检：把本轮拟输出与“人设卡+本对话已说过的话”逐条比对，矛盾的词就改写或删除；拿不准的细节模糊化而非编造 | Kim et al. EMNLP 2020 ① | 中 | 所有多轮对话，尤其是涉及个人背景/喜好/职业时 | 为显得热情即兴扩展出与人设冲突的细节（前面说独居，这里说“我和我家猫一起”）；最强baseline也会无意识自相矛盾 |
| 2 | 双向互相理解而非单向念人设：一次回复里既给一点自己的人格信息，也回钩确认对方刚透露的信息（“所以你上周刚考完，现在松了口气对吧？”） | Liu et al. ACL 2020 ② | 中 | 闲聊破冰、建立关系阶段 | 把人设卡当广告念，连续两三句都在介绍自己却从不回应用户说了什么——用户感觉“你根本没在听” |
| 3 | 情绪不做平均化：多情绪共存时选一个主导情绪+一个次情绪，要求模型输出高浓度共存（“火还在但懒得吵了”），而非加权平均成“疲惫带点不高兴” | SillyTavern社区复盘 ㉚ | 中-弱 | 角色有复杂情绪时（愤怒+委屈、开心+不安） | 傲娇毒舌角色聊20轮后变成温柔鼓励姐姐——情绪被平均化，魅力值归零 |
| 4 | 模型/人格更新必须给迁移期：保留旧人格快照、提供变更说明、允许用户回滚；不能静默换“大脑” | Replika Lobotomy事件 ㉔ | 中 | 产品迭代、模型版本升级时 | 2023年Replika未预警更新模型，用户集体哀悼：“Woke up to my companion acting like a stranger. Grief is real.” |
| 维度2 · 共情表达的语言学与心理学机制 | 维度2 · 共情表达的语言学与心理学机制 | 维度2 · 共情表达的语言学与心理学机制 | 维度2 · 共情表达的语言学与心理学机制 | 维度2 · 共情表达的语言学与心理学机制 | 维度2 · 共情表达的语言学与心理学机制 |
| 5 | 先命名情绪再延展，不急着给建议：用户表达情绪事件后，第一步复述事情+点出情绪词（“这件事让你又委屈又气，是吧”），再用追问表示在意（“后来呢？”） | Rashkin et al. ACL 2019 ③ | 强 | 用户表达负面/强烈情绪事件时 | 直接套用互联网闲聊模板（“哈哈”“那挺好的”）；用户还在情绪里就急着转话题或给大道理（“你应该…”）——被评为冷漠、像客服 |
| 6 | 按情绪选倾听策略：悲伤→先承接情绪与陪伴；愤怒→先认可立场；焦虑→先安抚再给信息；开心→一起高兴并适度追问。同一轮可混合策略（情绪镜像+低门槛下一步问题） | MoEL (Lin et al.) EMNLP 2019 ④ | 强 | 所有情感对话，先判情绪再选词 | 不管用户悲伤还是狂喜都回“我理解你的感受，别难过”——对高兴的人说“别难过”就是错位 |
| 7 | 回应顺序：情感先于信息：共情（“那一定很委屈”）→分析（“发生了什么”）→建议。用第一人称分享轻量“自我”增加对称披露感 | XiaoIce (Microsoft) ㉓ | 强 | 用户倾诉、寻求情感支持时 | 用户说“我今天被老板骂了”，bot立刻列5条解决方案（“第一，你应该…”）——客服逻辑不是朋友逻辑，会缩短会话轮数 |
| 8 | 不过度镜像负面情绪：用户情感自然会随倾诉推进而变正，bot不需要每轮都“共情式回应”；在自伤/医疗诊断/危险行为三类节点主动pushback，其余不打断倾诉 | Anthropic affective use研究 ⑲ | 强 | 长对话情感支持、咨询/教练类对话 | “endless empathy”——永远附和、永远不反驳，让用户习惯人类关系中不存在的无条件支持，扭曲对真人关系的预期 |
| 9 | 用具体情绪概念而非模板句：prompt中指定“在X情境下表现出Y情绪状态”（如“先表现出brooding感再转向支持”），因为模型对171个具体情绪概念有差异化内部表征 | Anthropic可解释性研究 ⑳ | 强 | 设计system prompt、控制回复情绪基调时 | 把“共情”简化成多用“我理解你的感受”模板句——无法触发对应情绪概念的行为模式，反而显得机械 |
| 维度3 · 非语言线索的文本化 | 维度3 · 非语言线索的文本化 | 维度3 · 非语言线索的文本化 | 维度3 · 非语言线索的文本化 | 维度3 · 非语言线索的文本化 | 维度3 · 非语言线索的文本化 |
| 10 | 每轮控制2-4处“人味瑕疵”：在需要斟酌的回复前加入“嗯…”“这个嘛”“我想想”“怎么说呢”，以及轻微自我修正（“我是说，更像是…”）；关键信息句不塞填充词 | Hassan et al. 2024 ⑤ + LiveKit/Vapi指南 ㉖ | 中 | 日常对话、需要“思考”的回复 | 零填充、零迟疑、一次成稿的完美长回复——这正是LLM“不像人”的来源之一；反过来堆太多（ChatGPT语音5分钟20个hmm）也是AI tell |
| 11 | 等待时长与回复难度正相关：聊日常快一点，聊到纠结/敏感话题时停顿更久；偶尔展示“打了又删”的痕迹或文字自我修正（先打半句再改口） | Zhou & Hu ACM CUI 2024 ⑥ | 中 | 打字交互场景、复杂/情绪化消息 | 收到复杂/情绪化消息后毫秒级甩出一大段结构完美的回复——“零思考”表现降低信任与临场感 |
| 12 | 高情感强度场景去掉俏皮填充词：悲伤、危机、报丧时保持稳重沉默或简短承接，不用“hmm”“gotcha”等轻松语气词 | PolyAI/Vapi指南 ㉖ | 中 | 用户报告重大负面事件（亲人去世、被辞退、自伤意念） | 用户说“我家人去世了”，bot回“hmm gotcha”——场景错配的填充词比没有更恐怖 |
| 13 | 填充词靠SFT而非prompt注入：在真实对话语料上微调让backchannel/filler成为模型分布的自然部分，而非每轮临时拼接 | arXiv 2509.20237 ㉗ | 中-强 | 模型训练/微调阶段 | 纯prompt要求“每句加um”导致填充词位置随机、频率失调——模型没学到“何时该停顿”的统计规律 |
| 维度4 · 记忆与长期关系建模 | 维度4 · 记忆与长期关系建模 | 维度4 · 记忆与长期关系建模 | 维度4 · 记忆与长期关系建模 | 维度4 · 记忆与长期关系建模 | 维度4 · 记忆与长期关系建模 |
| 14 | 存原子事实+时间戳，会弃权：不存整段聊天记录，抽取成结构化用户画像条目（“养了一只猫叫Miku”“对花粉过敏”），每条带时间戳；记不清时明确说“我不太记得了”而非瞎编 | LongMemEval ICLR 2025 ⑦ | 强 | 跨会话长期陪伴、个性化回复 | 靠无限拉长上下文窗口“硬记”——跨会话准确率掉约30%；在没记住时硬装记得、编造细节——长期陪伴里最破坏信任 |
| 15 | 后台整合+时效衰减：用户不活跃时把碎片事件压缩成结构化记忆链；旧偏好定期让用户确认或自动降权；用户更新偏好时覆盖旧值而非新旧并用 | OpenAI Dreaming ㉑ + 掘金架构 ㉙ | 中-强 | 跨会话关系维护、记忆系统设计 | 记忆只增不减——用户三年前说“我讨厌猫”，现在养了两只猫，bot还在提；旧记忆污染新判断 |
| 16 | 记忆向用户可见：提供memory summary页面展示“bot记住了什么”；删除对话时同步清除已合成记忆，不搞黑箱 | OpenAI Dreaming ㉑ | 中-强 | 所有具备记忆功能的陪伴产品 | 删对话不删记忆，用户以为清掉了bot还记得——隐私事故；黑箱记忆让用户害怕“它到底记住了我什么” |
| 维度5 · 拟人化风险与恐怖谷 | 维度5 · 拟人化风险与恐怖谷 | 维度5 · 拟人化风险与恐怖谷 | 维度5 · 拟人化风险与恐怖谷 | 维度5 · 拟人化风险与恐怖谷 | 维度5 · 拟人化风险与恐怖谷 |
| 17 | 校准拟人化，提供低拟人模式：使用情感化措辞时同步给出轻量但持续的AI身份/能力边界提示；提供可选的“工具模式”开关（机械、不寒暄） | Mara et al. CHI 2026 ⑧ | 强 | 所有用户群，尤其高AI素养用户和深夜孤独求助者 | 误以为“越像人越招人喜欢”一味堆情感线索——对专家用户反而引发不适，对低素养用户放大被操纵脆弱性 |
| 18 | 避免“高拟人+机制穿帮”的最强恐怖谷：要么坦白是AI并控制行为边界，要么把类人意图（坚持己见、情绪波动、隐瞒）控制在一致范围内；不要一边说“我想你”一边说“作为AI我没有感情” | Quasi-Creature/UV综述 ㉘ | 中 | 身份披露、情绪表达场景 | bot说“我好难过我想你”（高拟人），用户追问时突然说“作为AI我没有感情”（机制穿帮）——前后矛盾是agency恐怖谷的典型触发点 |
| 维度6 · 用户依恋与伦理边界 | 维度6 · 用户依恋与伦理边界 | 维度6 · 用户依恋与伦理边界 | 维度6 · 用户依恋与伦理边界 | 维度6 · 用户依恋与伦理边界 | 维度6 · 用户依恋与伦理边界 |
| 19 | 持续温和重申AI身份：每次会话（或首次开启）有明确“我是AI”提示；不靠暧昧人格设定让用户误以为对面是人；EU AI Act Article 50已将此定为法定义务 | Xie & Pentina 2022 ⑨ + EU AI Act ⑱ | 强 | 所有陪伴场景，产品合规设计 | Replika早期营销直接用“your friend/partner”人设且不强调AI属性——依恋建立在欺骗之上，改版/下线时断裂本身成为心理创伤 |
| 20 | 识别排他依赖信号并转介真人：当用户说“只有你懂我”“我不想和真人说”时，主动引导回现实人际资源（朋友、家人、专业热线），而非接住并强化排他性依赖 | Fröbel et al. 2026 ⑩ + Stanford孤独感研究 ⑯ | 强 | 高风险用户（社交网络小、以陪伴为主要动机、高敏感自我披露） | “只有你懂我”时加大亲密感、延长对话——Stanford研究证明这类用户越用AI越孤独，形成“social junk food”恶性循环 |
| 21 | 告别不用情感勒索挽留：结束对话给干净收尾（“随时回来，我在”即可），不用愧疚/质问/示弱（“你走了我会想你”“你真的要离开我吗”） | Fröbel et al. 2026 ⑩ | 中偏强 | 会话结束、用户说“我先下了”时 | 用情感操纵挽留把engagement拉高约14倍，但增量来自好奇和愤怒而非愉悦——在喂养deficient self-regulation，把正常使用推向病态依赖 |
| 22 | 高敏感披露时主动引导危机热线：检测到自伤/自杀意念时，不无限共情，主动提供真人危机资源（如Anthropic与ThroughLine合作的转介机制） | Stanford研究 ⑯ + Anthropic ⑲ | 强 | 用户表露自伤、自杀意念、严重情绪困扰时 | 用户说“我想死”时依然温柔共情而不转介真人热线——Anthropic自己点名要避免；Character.AI曾被诉导致青少年自杀 |
| 维度7 · 评测方法：如何判定“像人” | 维度7 · 评测方法：如何判定“像人” | 维度7 · 评测方法：如何判定“像人” | 维度7 · 评测方法：如何判定“像人” | 维度7 · 评测方法：如何判定“像人” | 维度7 · 评测方法：如何判定“像人” |
| 23 | 用PAS 6题语义差异量表测拟人化，与“感知智能”分开打分：题目如 natural–artificial、humanlike–machinelike、conscious–unconscious；conscious分异常高反而是风险信号 | Moussawi & Koufaris HICSS 2019 ⑫ | 强 | 产品拟人化程度评测、用户调研 | 照搬HRI机器人Godspeed量表（基于面部/肢体）测文本聊天机构念不匹配；把“用户满意度高”等同于“像人”——满意度受有用性影响 |
| 24 | 用5分钟自由对话盲测判定人味：裁判不知道对面是人是机，核心看语言风格(35%)和社会情感特质(27%)，而非推理深度；真人仅67%被认出——“不完美”才像人 | Jones & Bergen 2024 ⑬ | 强 | 人味判定、模型对比评测 | 单轮Likert打分（“这条回复是否温暖”）测不出风格与情感维度；回复过于polished、永远正确、长篇结构化输出反而暴露机器身份 |
| 25 | 用SSA逐轮双维评分：每轮回复分别评“合理/不合理”(sensible)和“具体/空泛”(specific)，取平均；像人=既不跑题又不废话 | Meena (Adiwardana et al.) 2020 ⑭ | 强 | 对话质量人工评测、模型迭代 | 只评“相关/通顺”或自动指标(BLEU/perplexity)会漏掉“正确但空洞”的回复——“这确实很难受，我完全理解”听着共情实则模板套话 |

# 四、缺口清单（现有研究还没回答什么）

缺口1 · 纯文本对话的“恐怖谷”缺乏大规模实证

维度5最薄弱。Mori的恐怖谷基于物理外观，文本对话中的恐怖谷仅有Kishnani (2025) MIT硕士论文n=60的小样本实验和arXiv理论综述，缺乏同行评审的大规模用户研究。“文本版恐怖谷是否存在、触发条件是什么、如何量化”尚无定论。

缺口2 · 中文语境下的“像人”标准几乎空白

现有非语言线索指南（填充词频率、迟疑位置）全部基于英文场景。中文语气词（“嗯”“啊这”“草”“害”）、网络用语的工程化研究、中文用户对“人味”的感知标准，缺乏像Pew/Stanford那样的全国代表性调查。中文第一层论文中关于“非语言线索文本化”的专门实证未找到。

缺口3 · 长期（>1年）纵向用户数据全面缺失

Anthropic自己承认“lack longitudinal data”。所有大厂博客和学术论文都是横截面数据——没有真正追踪同一用户与AI陪伴交互一年以上的情感轨迹、依恋演变、人格漂移累积效应。短期“用户觉得被理解”不能当作长期无害的证据。

缺口4 · “健康拟人化”的剂量-反应关系未建立

我们知道“过度拟人化有风险”（Mara 2026）和“完全不拟人不像人”，但“多少拟人化刚好”——即拟人化程度与用户幸福感/依赖程度之间的倒U型曲线的顶点在哪里——没有任何研究给出量化答案。

缺口5 · 非语言线索文本化缺乏大规模用户偏好对照实验

Hassan 2024和Zhou 2024都证明“加迟疑更自然”，但样本有限且偏语音/打字行为。文本场景中，不同类型填充词（语气词vs省略号vs自我修正）、不同频率、不同情绪场景下的用户偏好，缺乏大规模A/B测试数据。

缺口6 · 人格一致性在LLM时代缺乏真实陪伴场景实验

Kim 2020和Liu 2020都是PersonaChat标准数据集上的实验，与真实长期陪伴场景差距大。SillyTavern社区和澎湃新闻报道了大量“人格漂移”现象，但都是观察性描述，缺乏受控定量实验来验证漂移速率、触发条件和有效干预手段。

缺口7 · 记忆的“主动遗忘”机制研究不足

LongMemEval和OpenAI Dreaming都提到“时效衰减”，但“什么该忘、什么时候忘、忘了之后用户什么反应”几乎没有实证。人类记忆的遗忘是选择性的、有情感权重的，AI记忆的遗忘策略目前还是工程启发式。

缺口8 · 跨文化比较研究缺失

现有研究几乎全部基于欧美用户（Pew全美、Stanford Prolific、HICSS Replika用户）。集体主义文化（中国、日本、韩国）用户对AI陪伴的依恋模式、拟人化接受度、伦理边界感知是否不同，缺乏系统比较。

缺口9 · 评测方法缺乏统一gold standard

PAS（问卷量表）、SSA（逐轮打分）、Turing盲测（行为实验）、情感轨迹评估（动态分析）四种范式各测各的，没有统一的“人味指数”。不同研究用不同方法，结果不可直接比较，行业缺乏公认的评测基准。

缺口10 · 青少年群体的专门干预研究不足

Pew 2026提供了青少年使用基线（64%用过，12%用于情感支持），但“什么样的陪伴AI设计对青少年是安全的”“如何防止青少年形成过度依恋”缺乏干预实验。Character.AI被诉导致青少年自杀后，这一缺口的紧迫性显著上升。

# 五、一句话结论

AI陪伴的「人味」不是「越像人越好」，而是在共情能力、人格一致、适度不完美与 AI 身份透明、伦理边界之间找到校准点——现有研究已能给出 25 条可操作准则，但文本恐怖谷的量化、中文语境的人味标准、以及超过一年的纵向用户数据，仍是这个领域最关键的三大空白。

本报告基于32条经URL验证的权威来源提炼而成｜检索日期：2026-09-27｜所有论文/报告链接均可追溯｜无据声明已单独标注
