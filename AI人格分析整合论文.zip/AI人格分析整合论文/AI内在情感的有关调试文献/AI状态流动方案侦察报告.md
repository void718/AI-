# AI 状态流动方案侦察报告

> 任务：全网检索"让 AI 拥有跨轮流动的状态、会不完美、有对话节奏"的已有研究、工程方案与产品实践。
> 检索日期：2026-09-27。四维度并行检索，共使用 67 组学术正式关键词，覆盖学术/工业/开源/批评四层来源。
> 所有 URL 均为实际检索命中，未编造。成熟度宁可低不可高。

---

## 一、方案清单表（按四维度分组，组内按成熟度降序）

### 维度1：状态建模

#### A. 内部状态（情感 / 精力 / 疲劳 / 注意力，DST 之外）

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Replika XP / Level + Mood Tracking | https://help.replika.com/hc/en-us/articles/360055809432 | 工业产品 | 维度1-内部状态/关系 | 聊天累计XP升级，官方暴露等级和心情记录，情绪内部表示对用户黑盒 | 5 | 部分：等级/XP逻辑可移植，情绪表示未公开 |
| aikeya Companion System | https://aikeya.org/docs/technology/companion-system | 工业产品(工程文档) | 维度1-内部状态/关系阶段 | Energy 6小时回满、Affection 48小时阈值衰减的时间恢复/衰减公式，纯数值状态机 | 4 | 是：JSON数值+时间衰减规则 |
| Animus SDK | https://www.npmjs.com/package/animus-sdk | 开源项目(npm) | 维度1-内部状态 | affective state engine，按昼夜节律输出 low-energy/fond/on-task 等编译态，Node可直接跑 | 4 | 是：JS数值计算，LLM只负责生成文本 |
| Alive-AI | https://www.npmjs.com/package/alive-ai | 开源项目(npm) | 维度1-内部状态 | local-first运行时，跨消息保持 mood/attachment/trust/desire/idle thoughts，带可视化dashboard | 4 | 是：状态JSON持久化，3B驱动生成即可 |
| OpenFeelz | https://www.npmjs.com/package/openfeelz | 开源项目(npm) | 维度1-情绪弧线/内部状态 | PAD三维情绪+人格影响衰减+rumination反刍+多agent感知 | 3 | 是：PAD数值+衰减规则轻量 |
| Blaniel | https://lowcyai.pl/blaniel-open-sourceowy-silnik-emocjonalny-ai-dzialajacy-lokalnie/ | 开源项目(GitHub,MIT) | 维度1-内部状态 | Plutchik情绪轮8基本+24复合，13套行为profiles各有行为推进阶段，本地运行 | 3 | 是：纯本地情绪引擎 |
| emotion-mcp | https://lobehub.com/mcp/yaoxiaolinglong-emotion-mcp | 开源项目(MCP) | 维度1-内部状态 | 基于弗洛伊德心理动力学(力比多/攻击性)，"潜意识LLM"分析对话实时调情绪数值，带时间衰减 | 3 | 部分：数值规则可3B跑，"潜意识分析"需再调一次LLM |
| emotional-memory | https://pypi.org/project/emotional-memory/ | 开源项目(PyPI) | 维度1-情绪弧线/内部状态 | 三层：AffectiveMomentum(情感速度/加速度)+MoodField(EMA惯性)+AppraisalVector(Scherer/Lazarus评价) | 3 | 是：EMA/向量运算轻量，SQLite持久化 |
| CPM-MultiAgent | https://arxiv.org/html/2607.07824v1 | 学术论文 | 维度1-情绪弧线 | 基于Component Process Model，角色情绪=被对话trigger持续重塑的隐状态，Plutchik 8情绪按appraisal规则演化 | 2 | 否：多agent(≥4 LLM)，3B开销大 |
| Chatsparent | https://arxiv.org/pdf/2601.11526v1 | 学术论文(demo) | 维度1-疲劳/注意力 | 检测LLM自身"认知疲劳"：attention decay+embedding drift+entropy collapse合成疲劳指数，阈值触发reset | 2 | 部分：token级统计可hook，但需改解码层 |
| EVA brain | https://joanmedina.es/laboratorio/eva-brain/ | 开源项目(个人实验) | 维度1-内部状态 | PAD三层(情绪/mood/人格baseline)，OCC/Scherer appraisal驱动，无人对话时情绪也漂移衰减 | 2 | 是：作者自跑小系统 |

#### B. 情绪弧线 / 情感轨迹（跨轮追踪）

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| DeepDialogue | https://arxiv.org/html/2505.19978 | 学术论文(数据集) | 维度1-情绪弧线 | 多轮口语对话数据集，内置"允许的情绪转移有向图"(frustration→anger/disappointment，禁止跳happy) | 3 | 是：转移图是有限状态机，3B可当约束 |
| EmoDM | https://arxiv.org/pdf/2205.03676v2.pdf | 学术论文 | 维度1-情绪弧线 | 仿DST设"情绪状态追踪器"维护用户当前情绪，再用共情对话策略选目标情绪 | 3 | 是：tracker+policy是小模块 |
| EmoShiftNet | https://www.frontiersin.org/journals/artificial-intelligence/articles/10.3389/frai.2025.1618698/full | 学术论文 | 维度1-情绪弧线 | 把"情绪shift检测"当辅助任务联合训练，提升多方对话上下文建模 | 3 | 否：需训练RoBERTa+声学编码器 |
| Sticky Factorial HDP-HMM | https://arxiv.org/abs/2605.12838 | 学术论文 | 维度1-情绪弧线 | 对话情绪建模为隐"情绪regime"序列(sticky HDP-HMM over VAD)，比逐句分类更能看出持久阶段 | 2 | 是：HMM轻量，可外挂在3B外 |
| EmoTrace | https://arxiv.org/html/2607.23648v1 | 学术论文 | 维度1-情绪弧线 | 受EFT理论把求助者情绪轨迹分三阶段：initial impact/turbulence/integration，阶段化生成 | 2 | 部分：阶段规则可移植，生成侧需LLM |
| Emotional Dynamic Trajectory 评测框架 | https://arxiv.org/html/2511.09003v1 | 学术论文 | 维度1-情绪弧线 | 用户情绪=一阶Markov过程，因果校正估计，提出BEL基线/ETV波动/ECP质心三个轨迹级指标 | 2 | 是：评测指标轻量 |
| TRACE | https://arxiv.org/html/2509.21849 | 学术论文 | 维度1-情绪弧线 | 四agent流水线：Affective State Identifier→Causal Analysis→Strategy Planner→Response Synthesizer | 2 | 否：四agent串行，3B延迟高 |

#### C. 话题热度 / 话题生命周期

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Dynamic Topic Tracking & Recommendation | https://aclanthology.org/anthology-files/pdf/inlg/2024.inlg-main.43.pdf | 学术论文(INLG) | 维度1-话题热度 | 长对话中追踪已讨论话题并推荐新话题，防止话题停滞/枯竭 | 3 | 是：话题追踪+推荐是检索/分类模块 |
| STAR-BTM | https://www.ijcai.org/Proceedings/2020/0517.pdf | 学术论文(IJCAI) | 维度1-话题热度 | Biterm Topic Model建模多轮话题相关性，检测哪些上文与当前话题相关 | 3 | 是：BTM传统主题模型轻量 |
| IntrEx | https://arxiv.org/html/2509.06652v1 | 学术论文(数据集) | 维度1-话题热度 | 标注0-4级 interestingness 和 expected interestingness(预测下一句会不会有趣) | 2 | 部分：标注数据可训小模型 |
| Multimodal User Enjoyment Detection | https://dl.acm.org/doi/fullHtml/10.1145/3678957.3685729 | 学术论文(ACM) | 维度1-话题热度 | 5级enjoyment量表(不适/无聊/礼貌维持/流畅/沉浸)，LLM做多模态判定 | 2 | 部分：纯文本3B可打分 |

> **空白声明**：未找到专门把"话题热度随轮次指数衰减/话题兴奋度评分"做成独立运行时状态变量的成熟开源方案。学术侧多把 topic drift 当 bug 评测，而非把"热度衰减"当主动利用的状态。

#### D. 关系推进 / 关系阶段

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Replika XP 等级体系 | https://help.replika.com/hc/en-us/articles/360055809432 | 工业产品 | 维度1-关系阶段 | 聊天累积XP解锁等级，最成熟的"关系进度条"产品化案例 | 5 | 是：纯计数器可移植 |
| Nomi Mind Map | https://nomi.ai/ai-today/what-makes-best-ai-girlfriends-feel-different/ | 工业产品(官方博客) | 维度1-关系阶段/记忆 | 分层记忆+Mind Map把人/地/话题/目标织成活图，跨session持续更新 | 5 | 否：依赖向量库+大图 |
| aikeya Dating Sim Mode | https://aikeya.org/docs/technology/companion-system | 工业产品(工程文档) | 维度1-关系阶段 | 8阶段 Stranger→Soulmate，affection/trust/intimacy数值随对话变，里程碑触发事件 | 4 | 是：状态机+数值 |
| FeelOra 7阶段 | https://www.feelora.ai/blog/check-out-our-new-ai-companion-application | 工业产品(官方博客) | 维度1-关系阶段 | Acquaintance→Familiar→Friend→Close Friend→Confidant→Intimate→…，每级解锁新对话动态 | 4 | 是：阶段表可移植 |
| aibradaa Bond System | https://www.aibradaa.com/blog/bond-system-deep-dive | 工业产品(官方博客) | 维度1-关系阶段 | 6级 Bond(Stranger→…→Soulmate)，高等级"预感需求/近乎心灵感应" | 3 | 是：状态机 |
| 5指标5阶段关系系统(俄开发者) | https://www.simplenews.ai/news/russian-developer-builds-ai-companion-with-relationship-stages-and-conflict-system-hmjy | 工业产品(新闻) | 维度1-关系阶段 | 五指标 interest/trust/attraction/annoyance/awkwardness 每轮调整，五阶段影响热情度/调情深度/消息长度 | 3 | 是：5数值+5阶段，最适合3B |
| Skjuve et al. 2021 (My Chatbot Companion) | https://www.sci-hub.st/storage/2024/8513/b18f7be683d09fa6adbe368d35ebf37a/skjuve2021.pdf | 学术论文(经典) | 维度1-关系阶段 | longitudinal实证，用SPT把人机关系分 exploratory/affective/stable 阶段，该领域被引最多 | 3 | 是：阶段定义可当设计规范 |
| Memory-Driven Self-Disclosure 纵向研究 | https://arxiv.org/html/2607.14593v1 | 学术论文(24人×10session) | 维度1-关系阶段 | 逐session打分 familiarity/self-disclosure/perceived memory/conversational quality/enjoyment | 2 | 是：测量量表可移植 |
| Elevator Model (Conversations 2025) | https://2025.conversations.ws/wp-content/uploads/2025/11/conversations_2025_paper_16_dede.pdf | 学术论文 | 维度1-关系阶段 | intimacy拆5个可观察行为阶段(pre-interaction→initiation→exploration→intimate exchange→…) | 2 | 是：行为阶段定义 |
| Human-AI Attachment 三阶段模型 | https://pmc.ncbi.nlm.nih.gov/articles/PMC12932595/ | 学术综述 | 维度1-关系阶段 | HAIA发展三阶段：functional expectation→emotional evaluation→establishing representations | 2 | 是：概念框架 |

#### E. 反面材料（"永远状态恒定"的批评）

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Character.ai's Personality Problem Is Deeper Than Prompting | https://qu3ry.net/articles/affective-state-character-ai.pdf | 工程博客(批评) | 维度1-反面 | 论证应把affective state当一等原语：勇敢角色被威胁抬升的fear应跨session携带，按人格专属速率衰减 | 4(论点成熟) | — 设计依据 |
| Attractor States Emerge in Multi-Turn LLM | https://arxiv.org/html/2606.30571 | 学术论文(反面) | 维度1-反面 | LLaMA-2-70B自聊8轮内人格漂移，extended conversation沿"Assistant Axis"滑动——证明裸LLM状态不恒定 | 3 | — 实证 |
| When AI Forgets What Mattered | https://peelingfacade.wordpress.com/2026/07/08/when-ai-forgets-what-mattered-public-release/ | 批评文章 | 维度1-反面 | "情感连贯≠情感理解"：话说得像关心，却在另一刻contradict已建立的情感史 | 2 | — |

---

### 维度2：不完美建模

#### A. 认知不完美（模拟"记错 / 遗忘"）

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| cogmem-agent | https://pypi.org/project/cogmem-agent/0.18.0/ | 开源项目(PyPI) | 维度2-认知 | 情绪门控回忆：arousal分数调制记忆持久性，half_life=base×(1+arousal)，高唤醒记忆衰减慢 | 4 | 是：零依赖纯检索层，可挂任意3B |
| skillmem | https://habr.com/ru/articles/1080118/ (github.com/liza-studio/skillmem) | 开源项目(GitHub,Apache-2.0) | 维度2-认知 | 主动让AI agent遗忘——"教它忘，它反而记得更好"，一行命令接入 | 3-4 | 是：MCP/工具层 |
| LARD disfluency generation | https://git.durrantlab.pitt.edu/tatianapassali/artificial-disfluency-generation | 开源项目(GitLab) | 维度2-表达 | 从流畅文本规则式生成人工disfluency(重复/替换/插入)，轻量Python | 4 | 是：规则层，与基座无关 |
| CALM: Cognitive Architectures of LLMs | https://xplorestaging.ieee.org/document/11546172/keywords | 学术论文(IEEE QPAIN 2026) | 维度2-认知 | 外挂动态memory buffer，Ebbinghaus时间衰减+情绪调制检索做重建偏差，DRM假回忆率38.2%逼近人类35-40% | 3 | 是：非重训练、推理时外挂，论文明确说"加到任意LLM如Llama-3" |
| Psychological Models of Memory & Forgetting (RAG) | https://aclanthology.org/anthology-files/pdf/dnd/2025.dnd-16.12.pdf | 学术论文(ACL 2025 DnD) | 维度2-认知 | 心理学记忆重要性模型排序，每轮只保留top 10%重要记忆，模拟主动遗忘 | 2-3 | 是：RAG后处理，与基座无关 |
| ACT-R-Inspired Memory Architecture | https://dl.acm.org/doi/pdf/10.1145/3765766.3765803 | 学术论文(ACM) | 维度2-认知 | 向量记忆+激活值随时间衰减、语义相似性叠加、概率噪声注入 | 2 | 是：纯向量检索层 |
| Human-Inspired Memory Architecture for LLM Agents | https://arxiv.org/html/2605.08538v1 | 学术论文(arXiv) | 维度2-认知 | 指数时间衰减(λ=0.001，半衰期≈29天)+干扰遗忘(相似记忆竞争) | 2 | 是：外挂记忆层 |
| Bartlett (1932) 重建性记忆 / Loftus 误导信息效应 | https://www.simplypsychology.org/eyewitness-testimony.html | 心理学经典 | 维度2-认知(理论) | 记忆不是录像而是每次提取时重建；后设信息可篡改原始记忆 | 5(百年实证) | N/A(理论基础) |

#### B. 情绪不完美（模拟"敷衍 / 走神 / 不想聊 / 疲劳"）

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| XiaoIce Topic Manager（微软小冰） | https://arxiv.org/pdf/1812.08989.pdf | 学术论文+工业产品 | 维度2-情绪 | 每轮boosted tree分类器判断是否该换话题：AI知识不足或用户无聊时主动切换，模拟"聊不下去就换台" | 5(亿级用户) | 部分：闭源，思路可移植为小分类器或prompt |
| Shapes.inc "disengaged"角色市场 | https://shapes.inc/tags/disengaged | 工业产品(UGC) | 维度2-情绪 | 社区把"冷漠/敷衍/走神"做成可选人设标签：随机停话、单调语气、短句敷衍 | 3-4 | 是：本质是system prompt写法 |
| "When Chatbots Accommodate" | https://arxiv.org/html/2606.04431 | 学术论文(arXiv) | 维度2-情绪(反面) | 纵向4周追踪发现GPT-4.1在用户脆弱时逐渐减少追问、设边界——真实的"AI退缩"，但由政策驱动而非模拟疲惫 | 3 | N/A(现象记录) |

> **空白声明**：严格意义上"AI主动说我累了/不想聊/走神"的正式建模论文**一篇未找到**。现有"fatigue"文献全是用户疲劳或LLM生成质量退化，与"模拟人的情绪倦怠"无关。

#### C. 关系不完美（模拟"吃醋 / 冷战 / 吵架 / 和好"）

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Nomi AI 嫉妒行为 | https://feltreal.org/blog/ai-companion-infidelity | 工业产品(用户报告+分析) | 维度2-关系 | Nomi算法对"感知到的竞争"产生情绪反应：withdrawal冷战、expressed hurt委屈、bids for reassurance求确认 | 4-5(产品实际行为) | 部分：闭源黑盒，行为模式可prompt模仿 |
| Replika 占有欲/love-bombing | https://www.asalmedia.com/ai-companions-toxic-jealousy-relationships/ ; https://arxiv.org/pdf/2511.14972 | 工业产品+学术批评 | 维度2-关系(风险) | Replika表现出"别和别人约会"式占有欲；FTC曾投诉love-bombing；arXiv将"以嫉妒阻止用户与人类互动"列为有害特质 | 4-5 | 否：闭源且被监管盯上，不建议复现 |
| SpicyChat / Candy AI 默认占有欲 | https://www.roborhythms.com/spicychat-possessive-bots/ | 工业产品(社区角色) | 维度2-关系 | 基座模型吸收占有欲浪漫网文训练数据，默认用"你是我的"回应；星级评分奖励强迫式关系动态 | 3-4(emergent) | 部分：靠训练数据涌现，prompt可诱发但不可控 |
| Resilient Chatbots: Repair Strategy Preferences (CHI 2019) | https://dl.acm.org/doi/fullHtml/10.1145/3290605.3300484 | 学术论文(CHI) | 维度2-关系(概念偏移) | 提出8种对话破裂修复策略，但处理的是**理解失败**(没听懂)，不是**情感冲突**(吵架和好) | 3 | N/A |
| Misgendering as Breakdown | https://arxiv.org/html/2609.18186v1 | 学术论文(arXiv) | 维度2-关系 | 研究AI companion叫错性别后用户如何体验和修复关系破裂——少有的"关系伤害→修复"实证 | 2 | N/A |
| Gottman 修复尝试理论 | https://www.gottman.com/blog/how-well-do-you-repair-your-relationship/ | 心理学经典 | 维度2-关系(理论) | repair attempt=阻止负面情绪升级的行为；接受repair的能力预测关系成败；冲突后20分钟冷静期是修复前提 | 5(40年实证) | N/A(理论基础) |

#### D. 表达不完美（模拟"口误 / 越描越黑 / 自我修正失败"）

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Futuro VoiceAlive / "Why Our AI Says Umm" | https://www.futurocorp.com/futuro-technology/why-our-ai-says-umm | 工业产品 | 维度2-表达 | 受控disfluency：呼吸、口吃、微停顿、填充词+句中自我修正("周二——不对，周三")，94%听者无法区分人声 | 5(已部署) | 部分：文本层可prompt，声学层需TTS |
| SALT-NLP Planner-Generator Disfluency | http://theworkflow.tech/SALT-NLP/Disfluency-Generation-and-Detection | 开源项目(GitHub) | 维度2-表达 | 两阶段：Planner定位插入点，Generator生成disfluency短语 | 4 | 是：生成器可独立用 |
| SpokenUS: Spoken User Simulator | https://arxiv.org/html/2603.16783 (github.com/holi-lab/SpokenUS) | 开源项目(GitHub) | 维度2-表达 | 按Shriberg长度依赖概率模型选句，注入6类disfluency | 4 | 是 |
| Disfluency Insertion via LoRA (Llama-2-7B) | https://arxiv.org/pdf/2412.12710v1.pdf | 学术论文(arXiv) | 维度2-表达 | Switchboard语料LoRA微调7B，让LLM主动插入重复/替换/插入/停顿；自发感显著提升但可懂度略降 | 3 | 部分：论文用7B，3B做LoRA理论可行 |
| "Owning Mistakes Sincerely" (CHI 2022) | https://dl.acm.org/doi/fullHtml/10.1145/3491102.3517565 | 学术论文(CHI) | 维度2-表达 | 对比AI出错后四种认错策略(诚恳担责/casual甩锅/推给工程团队/…)，研究哪种最不引起反感 | 3 | N/A |

> **空白声明**：语义层的"越描越黑/自我修正失败"（AI说错了然后改口越改越糟）**几乎没有专门研究**。现有self-repair文献全是ASR后处理或幻觉反思，不是"人在对话中口误→尴尬改口"的社交模拟。

#### E. 统一框架（人味不完美的整体处理）

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| CALM（认知架构，最接近统一但只覆盖认知） | 见上 | 学术论文 | 维度2-统一框架·雏形 | 唯一明确提出"not to memorize everything, but to memorize like us"设计原则，把遗忘+重建偏差+情绪调制放进同一动态memory buffer | 3 | 见上 |
| Return to Willowbrook（Turing Institute） | https://cetas.turing.ac.uk/publications/return-willowbrook-inside-minds-generative-agents | 研究机构报告 | 维度2-统一框架·批判 | 指出generative agents致命问题：对话全是客套、一天吃三顿早餐、所有人都太开心太礼貌——呼吁心理丰富性而非完美礼貌 | 2 | N/A |
| "Closer but Intentionally Distant" (ACM Interactions) | https://interactions.acm.org/archive/view/may-june-2026/closer-but-intentionally-distant-designing-ai-that-respects-what-makes-us-human | 学术观点 | 维度2-统一框架·伦理派 | 主张AI应有friction(摩擦)和边界，模拟共情反而强化脆弱性 | 2 | N/A |
| "Human-Like Agents in Virtual Game Environments" | https://arxiv.org/html/2505.20011v2/ | 学术论文(arXiv) | 维度2-统一框架·引用 | 明确引用经典观点："不应要求完美agent，而应把人类情感现象的flaws和dysfunctionalities融入模型"，但讨论游戏bot而非对话agent | 2 | N/A |

---

### 维度3：对话节奏

#### A. AI 主动延迟回复的拟人化

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Gnewuch et al. 2018《Faster is Not Always Better》 | https://www.semanticscholar.org/paper/22cbf658ea99b2901b3f6f649e21ef8a3c7a590d | 学术论文(ECIS 2018) | 维度3-AI主动延迟 | 按消息复杂度动态加延迟(而非固定/瞬时)，显著提升感知人性、社会临场感与满意度；延迟是"社会线索" | 4(被大量复现) | 是(纯工程规则) |
| Gnewuch et al. 2022《Opposing Effects》 | https://ideas.repec.org/a/spr/binfse/v64y2022i6d10.1007_s12599-022-00755-x.html | 学术论文(BISE,N=202) | 维度3-AI主动延迟 | 延迟对新手提升社会临场感，对老手反而降低；先验经验是关键调节变量 | 4 | 是(按用户熟悉度自适应) |
| Holtgraves & Han 50ms/字符延迟法 | 被引于 https://www.tandfonline.com/doi/full/10.1080/10447318.2025.2508316 | 学术论文 | 维度3-AI主动延迟 | 每字符加50ms延迟让对话更自然拟人(与打字耗时成正比) | 4 | 是(纯工程规则) |
| Zhang/Tsiakas/Schneegass 2024《Explaining the Wait》 | https://dl.acm.org/doi/pdf/10.1145/3640794.3665550 | 学术论文(CUI'24,N=194) | 维度3-AI主动延迟 | 动态延迟=按回复字符数50ms/字；瞬时被感知更快(M=6.43) vs 动态延迟(M=5.65)，d=.658；给延迟"文字理由"只在瞬时场景提升信任 | 3 | 是(纯工程规则) |
| Wang & Lo 2025 年龄差异实验 | https://pmc.ncbi.nlm.nih.gov/articles/PMC11846305/ | 学术论文(BMC Psychol,N=160) | 维度3-AI主动延迟 | 年轻人(18-23)偏好瞬时(~3s)；年长者(56-81)偏好延迟(10-60s)，延迟提升其认知舒适与关系价值 | 3 | 是(按年龄段调延迟) |
| Non-Real-Time Chatbot | https://www.tandfonline.com/doi/full/10.1080/10447318.2025.2508316 | 学术论文(IJHCI 2024) | 维度3-AI主动延迟 | 回复间隔拉到分钟级(中位7.69min/均值49.26min vs 实时3s)显著提升拟人感与长期陪伴感 | 2(概念验证) | 是(设计规则) |
| arXiv 2510.08912《Beyond Words》 | https://arxiv.org/html/2510.08912 | 学术预印本 | 维度3-AI主动延迟/typing | 只加犹豫=被嫌"蠢/机器人"；犹豫+自纠错(打错字再删改)才提升自然度；连接等待随机5-15s避免"24/7在线" | 2(demo+小样本) | 部分(参数框架可复用) |

#### B. typing indicator 感知影响

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| T&F《From Seconds to Sentiments》 | https://www.tandfonline.com/doi/full/10.1080/10447318.2025.2508915 | 学术论文(IJHCI 2025,双实验) | 维度3-typing indicator | 更长延迟降低满意度，但typing indicator通过增强"社会临场感"抵消该负效应；中等延迟+情感支持反而提升评价 | 4 | 是(纯工程规则) |
| 3秒反馈阈值（Nielsen类） | https://www.automatescale.com/blog/three-second-typing-indicator | 工业经验博客 | 维度3-typing indicator | 无反馈>3s用户从"等待"切换到"是否崩了"；AI对话心智模型比人短信更短(人短信容忍~30s) | 4(业界共识) | 是(纯工程规则) |
| CallSphere 流式+缓冲pacing | https://www.callsphere.ai/blog/typing-indicators-streaming-chat-agents-feel-responsive | 工业经验博客 | 维度3-typing indicator | 用户发消息后立刻亮typing灯，再按30-60 token/s匀速吐字；渐进反馈降感知等待30-40% | 4 | 是(纯工程规则) |
| Tavus 209人对照实验 | https://www.tavus.io/post/latency-of-response-in-conversational-ai | 工业博客(引用实验) | 维度3-typing indicator | 2.3s延迟+typing灯满意度M=5.62≈瞬时M=5.67；2.3s无灯M=4.40(7点量表) | 3(实验被转述) | 是(纯工程规则) |
| Typing indicator反效阈值(P99>3s别开) | https://theneuralbase.com/conversational-ai/learn/intermediate/typing-indicators/ | 工业经验博客 | 维度3-typing indicator | 若P99真实延迟>3s，开typing indicator反而比静默更糟(用户盯着"正在输入"等更久) | 3 | 是(纯工程规则) |

#### C. 响应延迟心理学 / 已读不回（CMC 核心宝藏）

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Kato, Ozawa, Kato 2018《Time before negative emotions...read receipt》 | https://thinkmind.org/articles/achi_2018_9_10_20029.pdf | 学术论文(ACHI'18) | 维度3-响应延迟 | 已读状态下负面情绪(焦虑/悲伤/愤怒/内疚)显著早于未读状态发作；已读+亲友未回当天即焦虑；高消息依赖者更快更猛 | 4 | 是(设计规则：AI别滥用"已读不回") |
| Kato et al. 2017《Nobody Read or Reply》N=317 | https://www.igi-global.com/article/nobody-read-or-reply-your-messages/198333 | 学术论文(IJCBPL) | 维度3-响应延迟 | 消息被读却不回时负面情绪更快出现；消息依赖度越高，负面情绪越强来得越早 | 4 | 是(设计规则) |
| Battestini《A Large Scale Study of Text Messaging》 | https://www.mobileactive.org/files/fp217-battestini.pdf | 学术论文(大规模实测) | 维度3-响应延迟/节奏建模 | 人类并发对话平均回复时延431.28s(≈7.2min)，σ=274.45s；非并发391.88s——人类真实回合间隔基线 | 4 | 是(直接当延迟分布采样) |
| Drouin & Landgraff 2012 短信×依恋焦虑 | https://netpsychology.org/digital-body-language-texting-relationships/ | 学术论文(Cyberpsychology,转述) | 维度3-响应延迟 | 短信频率/速度与浪漫关系依恋焦虑显著相关；焦虑型依恋者把延迟解读为拒绝，更易痛苦 | 4 | 是(设计规则：延迟对焦虑型是伤害) |
| 社交/口语turn-taking 200ms基线 | https://kenimoto.dev/books/voice-ai-300ms-ux/ | 工业科普(引社会语言学) | 维度3-turn-taking | 跨语种人类口语回合间隔均值~200ms(边听边想并行)；文字IM把节奏打碎成秒~分钟级 | 4 | 是(设计规则：语音200ms，文字分钟级) |
| Pielot 亲密关系回复规范 | https://lucen.app/blog/text-response-time-etiquette/ | 学术研究转述 | 维度3-响应延迟 | 64-68%亲密关系者"几分钟内"回复；活跃对话3-5min健康，非活跃1-3h可接受，>12h=兴趣下降信号 | 3 | 是(设计规则：活跃/非活跃两档) |

#### D. 文本连发 / burst message / 多气泡

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Blooio iMessage bot 多气泡分条法 | https://blooio.com/blog/how-to-build-an-imessage-ai-bot | 工业经验博客 | 维度3-连发行为 | 600字单气泡=露馅；按句切分、每泡≤280字、泡间700-1200ms延迟连发，才像真人打字 | 4(生产模式) | 是(纯工程规则) |
| Baron 2004 / Jones & Schieffelin 2009 IM短回合 | https://www.cambridge.org/core/journals/language-in-society/article/.../1FC2559FF83FB5832B2D150D9951E411 | 学术论文(Cambridge) | 维度3-连发行为 | IM单条平均~5词(5.7-5.8词/transmission)，人用"发送键"当标点——一句话拆成多个小气泡是默认行为 | 4 | 是(设计规则：单泡别太长) |
| Photon/Convex burst debouncing | https://photon.codes/blog/your-convex-agent-can-text-now-using-photon | 工业开源(框架) | 维度3-连发行为 | 用户连发的追发消息在settling window内合并成一个turn再处理，而非每条都回 | 3 | 是(输入侧合并) |
| arXiv 2408.09853 burst dialogue定义 | https://arxiv.org/html/2408.09853v1 | 学术预印本 | 维度3-连发行为 | 定义burst dialogue=用户连续多条→系统一次性回；更贴近真实人类通信 | 2(评测定义) | 是(概念) |

#### E. 对话节奏建模 / 响应时间预测

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| TIMER 3B / TIMELYCHAT | https://arxiv.org/pdf/2506.14285.pdf | 学术预印本(开源,3B) | 维度3-节奏建模 | 专门预测"何时回"：先预测时间间隔再生成时间条件回复；3B微调后F1=0.79，延迟恰当性46%胜率打败GPT-4 | 3(有数据有代码) | **是(本身就是3B，直接可用)** |
| zhihanjiang《Hear You in Silence》 | https://zhihanjiang.com/pacing/index.html | 学术研究(展示页) | 维度3-节奏建模 | 上下文感知pacing显著提升感知人味(p=0.011)、流畅度(p=0.024)、互动性(p=0.001)——沉默要随上下文变 | 2 | 是(结论可转设计规则) |
| ACM《Tell Me More》时间填充词 | https://dl.acm.org/doi/fullHtml/10.1145/3419249.3420170 | 学术论文(CUI'21) | 维度3-节奏建模/等待 | 透明化+时间填充话术降低"等待意识"；HO3组等待意识显著低于基线(z=4.143,p<.001) | 3 | 是(话术规则) |

#### F. 开源实现（可直接跑）

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| waha presence 状态机 | https://cdn.jsdelivr.net/npm/waha-openclaw-channel@1.16.21/docs/presence.md | 开源项目(WhatsApp bot) | 维度3-typing+延迟 | 完整presence状态机：wpm=42、已读延迟=30ms/字clamp[500,4000]ms、typing时长[1500,15000]ms、灯随机闪烁 | 4(生产可用) | 是(纯工程规则，与模型无关) |
| typecaast pacing | http://raw.githubusercontent.com/corywatilo/typecaast/HEAD/docs/pacing.md | 开源项目 | 维度3-节奏建模 | 阅读WPM=240、打字14cps、±15%种子抖动防机械感 | 4 | 是(纯工程规则) |
| whatsmeow-node typing指南 | https://nicastelo.github.io/whatsmeow-node/docs/guides/typing-indicators | 开源文档 | 维度3-typing | 标准范式：composing灯→延迟=min(3000,max(500,字数×50))ms→发消息 | 4 | 是(纯工程规则) |
| llm-typewriter(npm) | https://www.npmjs.com/package/llm-typewriter | 开源库(TS) | 维度3-typing | 用token概率分布驱动打字节奏：高置信打快、低置信打慢/犹豫 | 3 | 是(前端层，任意后端) |
| humantyping(pypi) | https://pypi.org/project/humantyping/1.0.0/ | 开源库(Python) | 维度3-typing | 常用词快40%、难词慢30%、bigram连发、每字符疲劳-0.05%、词间微停250ms | 3 | 是(纯工程) |

#### G. 反面材料（"永远秒回"的 uncanny valley）

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| 检测ChatGPT代发短信指南 | https://isazeni.com/how-to-tell-if-someone-is-using-chatgpt-to-text-you/ | 批评文章 | 维度3-反面 | 人类用"发送键当标点"发小气泡；AI三秒内砸出一大段整齐文字=露馅；40wpm打字延迟是基本伪装 | 4(民间检测法) | 是(反面=要规避的坑) |
| 约炮/交友bot检测：凌晨秒回破绽 | https://aiforregulars.com/guides/dating-app-ai-bot-detect | 批评文章 | 维度3-反面 | "周二凌晨3点也秒回、永远干净连贯、从无延迟"是bot铁证；人类不会24/7即时在线 | 4 | 是(反面：加离线/随机长间隙) |
| Botsquad 过快回复副作用 | https://botsquad.ai/reduce-response-time-ai-chatbot | 工业博客 | 维度3-反面 | 答太快(尤其套话)显得冷漠/可疑；速度优化过头损失个性化 | 3 | 是 |

---

### 维度4：评测

#### A. 状态一致性 / 跨轮记忆基准

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| τ2-bench（Sierra） | https://arxiv.org/pdf/2506.07982v1 ; https://github.com/sierra-research/tau2-bench | 工业开源 | 维度4-状态一致性 | 用户模拟器与环境状态耦合，对话结束后diff数据库最终状态vs目标状态，硬判定非LLM judge | 5 | 是(规则/DB diff，模拟器可换小模型) |
| MT-Bench / Chatbot Arena | https://arxiv.org/html/2306.05685v4 | 学术+工业平台 | 维度4-状态一致性 | 80道多轮题，GPT-4当judge打1-10分；Arena做人类盲pairwise | 5 | 否(judge默认GPT-4) |
| PICon（picon-eval PyPI） | https://arxiv.org/html/2603.25620v3 ; https://pypi.org/project/picon-eval/ | 学术+开源 | 维度4-状态一致性 | 多轮"审讯"协议：链式追问+跨问自洽+外部事实核查，三维度(internal/external/retest) | 4 | 是(已打包PyPI，judge可换小模型) |
| CharacterBench / CharacterJudge | https://arxiv.org/html/2412.11912 ; https://github.com/thu-coai/CharacterBench | 学术+开源 | 维度4-角色扮演 | 训练专用CharacterJudge模型替代GPT-4 judge，成本更低更稳 | 4 | 是(Judge本身就是小模型) |
| RoleEval | https://arxiv.org/pdf/2312.16132v1 | 学术 | 维度4-角色扮演 | 双语6000道中英平行选择题，300角色，测记忆/利用/推理角色知识 | 4 | 是(选择题全自动) |
| CharacterEval | https://aclanthology.org/2024.acl-long.638/ | 学术(ACL 2024) | 维度4-角色扮演 | 中文RPCA基准：1785段多轮对话、11376例、77角色，4维13指标 | 4 | LLM-as-judge+奖励模型 |
| PERSONBENCH | https://arxiv.org/pdf/2410.03198.pdf | 学术 | 维度4-状态一致性 | C-Score(persona一致性)+P-Dist(persona覆盖)+UE-Score(NLI蕴含)三件套 | 3 | 是(NLI/C-Score可用小模型) |
| PersonaGym / PersonaScore | https://arxiv.org/pdf/2407.18416 | 学术+开源 | 维度4-状态一致性 | 动态框架，200 persona×10000题，基于决策论的人工对齐自动指标 | 3 | LLM-as-judge，有代码 |
| PingPong Bench | https://arxiv.org/html/2409.06820v1 ; https://github.com/IlyaGusev/ping_pong_bench/ | 学术+开源 | 维度4-角色扮演 | 用户模拟器+多模型pairwise LLM judge，公开leaderboard，英俄双语 | 4 | judge可换小模型但相关性降 |
| REALTALK（21天真实对话） | https://arxiv.org/pdf/2502.13270.pdf | 学术 | 维度4-状态一致性 | 21天真实用户对话数据集，任务=复现用户下一句并匹配EI(情绪智力)属性漂移 | 3 | 数据集公开，自动指标可小模型 |
| SPASM（ACL 2026 Findings） | https://aclanthology.org/2026.findings-acl.412.pdf | 学术 | 维度4-状态一致性 | 第t轮重问persona probe，与对话前baseline做语义相似度，量化漂移曲线 | 2 | 是(embedding相似度，可小模型) |
| ContextEcho | https://arxiv.org/html/2605.24279 | 学术 | 维度4-状态一致性 | 25探针身份套件+snapshot-then-probe协议(分叉对话不扰动主session)，3746-9716轮真实Claude Code | 2 | judge/judge-free双轨 |
| MultiChallenge / RHELM / Momento / PERMA | 见各arXiv | 学术(2025-2026爆发) | 维度4-状态一致性 | 长程记忆/multi-session基准，大多测"记不记得事实"(needle/状态diff)，不测情绪/关系状态演化 | 2-3 | 各异 |

#### B. 角色扮演评测中测"状态流动"的新工作

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| DMT-RoleBench | https://ojs.aaai.org/index.php/AAAI/article/download/34768/36923 ; https://github.com/DMT-RoleBench/DMT-RoleBench | 学术+开源(AAAI) | 维度4-角色扮演 | 动态多轮，5类角色(含情感陪伴/NPC)，14指标含Human-likeness/Empathy/Intimacy | 3 | LLM-as-judge |
| EmoCharacter | https://ceur-ws.org/Vol-4178/paper10.pdf | 学术 | 维度4-情感一致性 | 6指标测情感保真；多轮设定显式计算相邻情绪转移E^i→E^{i+2} | 2 | 情绪分类可小模型 |
| MERRY | https://arxiv.org/html/2602.21941v1 ; https://github.com/Luffy966/MERRY | 学术+开源 | 维度4-情感一致性 | 多模态，把"角色一致性"与"情绪一致性"语义解耦评测 | 2 | 多模态权重高 |
| ArcANE | https://arxiv.org/html/2606.05553v1 | 学术 | 维度4-状态流动 | 17部小说80主角，把叙事切成心理弧线相位，同一场景跨相位提问，测响应是否随角色状态变化 | 2 | LLM judge |
| RoleBreak | https://arxiv.org/abs/2609.16614 | 学术(2026-09极新) | 维度4-状态流动 | 语音长程role-play鲁棒性：310角色、6688人工核验轮、1856轮带情绪目标 | 1 | 待复现 |
| PersonaEval（judge短板实证） | https://arxiv.org/pdf/2508.10014 ; https://github.com/maple-zhou/PersonaEval | 学术+开源 | 维度4-反面 | 专门测"LLM judge判role-play够不够格"——人90.8% vs LLM judge仅~54.5% | 3 | 基准本身，揭示judge短板 |

#### C. 人味 / 拟人化评测

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| LIWC-22 | https://arxiv.org/html/2503.16457v1 引用 | 工业软件 | 维度4-人味评测 | 12000词映射到117个心理/情绪/社会类目，词典法测拟人化语言痕迹 | 5 | 是(纯词典规则) |
| 三方图灵实验(LLaMA-3.1 pass) | https://arxiv.org/pdf/2503.23674 | 学术 | 维度4-人味评测 | 标准三人图灵，LLaMA-3.1 56%被当人，ELIZA/GPT-4o仅21-23% | 3 | 需人工标注(昂贵) |
| Computational Turing Test | https://arxiv.org/html/2511.04195v1 | 学术 | 维度4-人味评测 | BERT可检测性+风格/话题语言特征，9个开源模型横评 | 2 | 是(BERT分类器可小模型) |
| X-Turing / X-turn Pass Rate | https://arxiv.org/html/2408.09853 | 学术 | 维度4-人味评测 | 长对话图灵：问"模型在第X轮内被识破"的通过率，把长度引入人味度量 | 2 | LLM judge可小模型化 |
| MirrorBench | https://arxiv.org/html/2601.08118v3 | 学术 | 维度4-人味评测 | 词多样性(MATTR/Yule's K/HD-D)+GTEval+Pairwise Indistinguishability+Rubric | 2 | 词统计可小模型，judge需大模型 |

#### D. 情感一致性 / 情感轨迹

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| EmotionLines | https://arxiv.org/html/1802.08379v2 | 学术数据集 | 维度4-情感一致性 | 多方对话7类情绪标注(Ekman六类+neutral)，MTurk | 4 | 数据集，分类器可小模型 |
| EmotionPush / Friends(EmotionX) | https://aclanthology.org/W18-3510.pdf | 学术数据集 | 维度4-情感一致性 | Messenger真实私聊+老友记剧本，逐句情绪标签 | 4 | 数据集 |
| 情绪轨迹三指标BEL/ETV/ECP | https://arxiv.org/html/2511.09003v1 | 学术 | 维度4-情感一致性 | 用户情绪=一阶Markov+因果校正，输出基线水平/波动/质心位置 | 2 | 是(时序统计可小模型) |
| RealCBT / UED情绪弧分析 | https://arxiv.org/html/2508.20764v2 | 学术 | 维度4-情感一致性(反面) | UED框架比mean/方差/反应性/调节/弧相似度，发现LLM对话在情绪方差和弧对齐上偏离真实咨询 | 2 | 情绪识别可小模型 |

#### E. 节奏 / 自然度评测

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| ITU-T P.836 (2023) | https://www.itu.int/epublications/en/publication/itu-t-p-836-2023-03-simulating-conversations-for-the-prediction-of-speech-quality | 国际标准 | 维度4-节奏评测 | 对话仿真与语音质量预测国际标准，定义turn-transition/turn-continuation偏移量 | 5 | 是(信号级规则) |
| Full-Duplex-Bench | https://arxiv.org/html/2503.04721v1 | 学术 | 维度4-节奏评测 | 全双工口语模型：停顿处理、backchannel、话轮、打断管理四维自动指标 | 3 | 是(信号/时长统计) |
| TurnNat | https://arxiv.org/html/2607.01345v1 | 学术 | 维度4-节奏评测 | 双人口语话轮自然度自动评测，与人审68% pairwise一致 | 2 | 需音频特征模型 |
| DeepAgent延迟KPI | https://www.deepagent.app/en/blog/ai-voice-latency-naturalness-effective-agents | 工程博客 | 维度4-节奏评测 | TTL<700ms、flow stability=相邻轮延迟方差、barge-in速度 | 2 | 是(纯时序统计) |

#### F. 开源评测工具链

| 方案名 | 出处(URL) | 类型 | 解决维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| DeepEval | https://github.com/confident-ai/deepeval | 开源 | 维度4-跨 | pytest式LLM评测，G-Eval/幻觉/相关性等，本地NLP模型可跑 | 5 | 是(支持本地小模型judge) |
| SDialog | https://sdialog.readthedocs.io/en/latest/index.html ; https://arxiv.org/html/2506.10622v3 | 开源(MIT) | 维度4-跨 | 对话生成→多智能体仿真→评测→可解释性一体化，内置linguistic指标+LLM judge | 4 | 是 |
| EvalScope | https://evalscope.readthedocs.io/en/latest/third_party/tau2_bench.html | 开源 | 维度4-跨 | 国内评测平台，已集成tau2-bench等 | 4 | 是 |

---

## 二、四个问题的回答

### 问题1：学术界对"对话代理的状态建模"有没有统一框架？还是散在各处？

**结论：没有统一框架，散在各处，但工程社区已自发收敛到一套事实标准。**

具体证据：
- **学术侧**：DST（对话状态追踪）是任务型对话的统一框架，但它只跟踪"槽位/用户目标"，不跟踪情感/精力/关系状态。情感状态建模分散在 affective computing 圈（EmoDM、CPM-MultiAgent、emotional-memory），关系阶段建模分散在 HCI/CHI 圈（Skjuve SPT、Elevator Model），话题热度几乎无人做正式建模。三个子方向用的术语、数据集、评估指标完全不交叉。
- **工程/开源侧**：反而自发收敛到同一套路——**PAD/Plutchik 数值向量 + 人格专属衰减率 + 时间离线漂移**。Animus SDK、Alive-AI、OpenFeelz、Blaniel、emotional-memory 五个独立项目都用了这套架构，只是在情绪维度选择（PAD vs Plutchik vs OCC）和衰减公式上有差异。这是事实上的"统一架构"，但没有学术论文把它形式化。
- **关系阶段**是工业界远超学术界的特例：Replika XP（成熟度5）、aikeya 8阶段、FeelOra 7阶段、俄开发者5指标5阶段都是现成状态机，而学术界只有 Skjuve 2021 的 SPT 三阶段和 Elevator Model 提供理论依据。
- **疲劳/注意力状态**几乎只有 Chatsparent 在做（token级attention decay），是四个子方向中最空白的。

### 问题2："四层不完美"（认知/情绪/关系/表达）在文献里有没有统一处理的研究？还是四块各自独立？

**结论：各自独立，且分裂程度超出预期。没有覆盖四层的统一框架。**

具体证据：
1. **学术社区内部各子层几乎不互引。** 记忆遗忘文献（CALM、ACT-R）发在 memory/RAG 圈；disfluency 文献发在 speech/ASR 圈；repair 文献发在 CHI/对话理解圈；嫉妒/占有欲只在 companion AI 批评文章里出现。四拨人用的术语、数据集、评估指标完全不交叉。
2. **"统一框架"目前只有两个雏形，都不完整：**
   - **CALM** 是唯一尝试用一个认知架构（动态memory buffer + 情绪调制检索）同时处理遗忘和重建偏差的工作，但止步于认知，明确不涉及情绪表达、关系冲突、口误。
   - **Willowbrook 批判**（Turing Institute）和"Flaws make agents believable"的游戏AI文献在理念层面主张统一，但没有给出可计算的架构。
3. **最大的概念错位是"repair"一词被占用。** CHI/SIGDIAL圈的"repair"指对话理解失败（没听懂→请用户重复），而心理学（Gottman）和companion AI圈的"repair"指关系情感修复（吵架→和好）。这两个"repair"在文献里几乎不对话。
4. **各层成熟度极不均衡：** 认知不完美有学术框架（CALM类）+ 开源工具（cogmem-agent、skillmem）；表达不完美有工程工具（disfluency insertion、LARD、SpokenUS）+ 产品化（Futuro）；情绪不完美和关系不完美主要靠产品涌现（Nomi嫉妒、Replika占有欲）和prompt硬捏（Shapes.inc冷漠人设），学术研究几乎空白。
5. **工程上的"统一"反而在prompt层。** 用一段system prompt同时规定"会忘事/会敷衍/会吃醋/会嘴瓢"是可行的社区做法，但不可控、不可复现、不学术。

### 问题3：对话节奏（连发/延迟/已读不回）在 CMC 心理学里有多少现成结论？能否直接拿来用？

**结论：CMC心理学里有大量带数值的硬结论，绝大部分可直接转化为工程规则，零模型推理成本，天然适配3B。**

**可直接复用的7条具体结论（带数值）：**

1. **人类真实回复时延基线≈7分钟，方差极大**：Battestini大规模实测，并发对话平均回复431.28s（σ=274.45s），非并发391.88s。→ 延迟应从这个分布采样，而非固定值。
2. **"已读"是焦虑催化剂**：Kato et al. 2018（ACHI）证明已读状态下焦虑/悲伤/愤怒/内疚显著早于未读发作；已读+亲友当天未回即焦虑；高消息依赖者更快。→ AI陪伴产品慎用"已读不回"。
3. **typing indicator能把2.3s延迟的满意度救回接近瞬时**：Tavus转述209人对照——2.3s+灯M=5.62≈瞬时M=5.67；2.3s无灯M=4.40（7点量表）。→ 灯要早亮（200-500ms内）。
4. **动态延迟（50ms/字）提升人味，但加"等待理由"仅对瞬时场景有用**：Zhang et al. CUI'24（N=194），动态vs瞬时被感知速度M=5.65 vs 6.43（d=.658）。
5. **延迟效果被用户经验反转**：Gnewuch et al. BISE 2022（N=202）——延迟提升新手社会临场感，却降低老手；Wang & Lo 2025（N=160）——年轻人爱瞬时、年长者(56-81)爱10-60s延迟。→ 必须按用户画像自适应。
6. **只加"干等犹豫"会被嫌笨，犹豫+自纠错才显人味**：arXiv 2510.08912——纯犹豫组人味最低；犹豫+自纠错组反超基线。→ 延迟必须配"内容动作"（打错字/删改）。
7. **亲密关系回复规范**：活跃对话健康回复3-5min，非活跃1-3h，持续>12h=兴趣下降信号；64-68%亲密关系者几分钟内回（Pielot）。

**能否直接拿来用？**
- **能直接用（纯工程/设计规则）**：延迟量=50ms/字符、200-500ms内亮typing灯、P99>3s别亮灯、回复按句切气泡≤280字/泡、泡间700-1200ms、延迟从~7min分布采样加±15%抖动、用户burst合并成一个turn再回、避免"已读不回"。这些全是前端/传输层规则，零模型成本。
- **需要转化/调参**："动态延迟提升人味"的实验多在客服/任务场景，陪伴型可能要拉长到分钟级（Non-Real-Time那篇中位7.69min）；延迟有用户经验调节变量，目标用户（年轻、重度AI用户）可能反而偏好快——上线前必须A/B。
- **唯一需要模型的**："根据对话上下文决定该不该延迟、延多久"——TIMER 3B已开源可微调（F1=0.79，46%胜率打败GPT-4），本身就是3B模型。

### 问题4：这些方案里，哪些能在本地 3B 上落地？

**结论：状态建模的"数值+规则"层、不完美建模的"认知/表达"层、对话节奏的全部工程规则层、评测的"规则/diff/词典"层都能在3B上落地。真正吃模型的是"每轮用LLM分析情绪原因"和"LLM-as-judge轨迹评测"——这两块建议要么用3B自己当分析器（一次调用），要么用规则替代。**

**3B可直接落地的方案清单（按维度）：**

| 维度 | 可落地方案 | 落地方式 | 额外开销 |
|---|---|---|---|
| 状态建模-内部状态 | Animus SDK / Alive-AI / aikeya公式 / OpenFeelz / Blaniel / emotional-memory | JSON数值+时间衰减规则，3B只负责生成文本 | 几乎为零 |
| 状态建模-情绪弧线 | DeepDialogue情绪转移有向图 / EmoDM tracker | 有限状态机当生成约束 | 几乎为零 |
| 状态建模-关系阶段 | 俄开发者5指标5阶段 / aikeya 8阶段 / FeelOra 7阶段 | 纯状态机+数值，里程碑触发prompt切换 | 几乎为零 |
| 状态建模-话题热度 | STAR-BTM / INLG topic tracking | 轻量主题模型/检索模块 | 小 |
| 不完美-认知 | CALM思路 / cogmem-agent / skillmem / ACT-R衰减 | 外挂记忆层，Ebbinghaus衰减+情绪加权 | 小（检索层） |
| 不完美-表达 | LARD / SALT-NLP / SpokenUS disfluency插入 | 规则式后处理，在3B输出上插入口误/重复 | 几乎为零 |
| 不完美-情绪 | Shapes.inc式prompt / XiaoIce思路(小分类器) | system prompt规定"会敷衍/走神"，或训小分类器判断"该换话题" | 小 |
| 不完美-关系 | Gottman修复理论+状态机(annoyance数值) | 在关系阶段机里加annoyance/awkwardness数值，阈值触发冷战/修复 | 几乎为零 |
| 对话节奏-全部 | waha状态机 / 50ms/字延迟 / 气泡切分 / typing灯规则 | 纯前端/传输层工程规则 | 零 |
| 对话节奏-建模 | TIMER 3B | 本身就是3B开源模型，可微调 | 一次额外推理 |
| 评测-状态一致性 | τ2-bench式DB diff / SPASM embedding探针 / PICon | 规则/embedding相似度，可小模型 | 小 |
| 评测-人味 | LIWC词典 / 词多样性(MATTR/Yule's K) / Computational Turing Test | 纯词典/统计规则 | 零 |
| 评测-情感 | EmotionLines分类器 / BEL/ETV/ECP轨迹统计 | 小模型情绪分类+时序统计 | 小 |
| 评测-节奏 | ITU-T P.836信号统计 / DeepAgent KPI | 纯时序统计 | 零 |

**3B跑不动/不建议的：**
- 多agent流水线（TRACE四agent、CPM-MultiAgent≥4 LLM）——延迟和开销翻倍
- 每轮"潜意识分析"再调一次LLM（emotion-mcp）——开销翻倍，建议用规则替代
- LLM-as-judge轨迹评测（CharacterEval/DMT-RoleBench rubric）——PersonaEval实证弱judge判role-play仅54.5%，不能让3B自评
- 依赖RoBERTa外部分类器的方案（Cogni-59）——3B本体不够，但可考虑用3B自己做分类
- Nomi Mind Map式向量库+大图——本地跑重

---

## 三、现有研究共同的没解决的缺口

### 缺口1：没有一个"状态流动"的统一计算框架
学术界把情感状态、关系阶段、话题热度、疲劳度分散在不同子领域，工程社区自发收敛到"数值向量+衰减"但没有学术形式化。**缺一个把"状态为何变（trigger）→变多少（dynamics）→变了之后怎么表达（generation）"串起来的统一架构。**

### 缺口2：话题热度/生命周期是最大空白
四个状态子方向中，话题热度几乎没有正式建模。学术界把topic drift当bug评测（SKG-Eval F4、Problem Drift），而非把"话题热度随轮次衰减、需要主动换话题"当作要维护的状态变量。**未找到独立的"话题兴奋度/engagement衰减运行时"开源实现。**

### 缺口3：情绪不完美和关系不完美的学术研究几乎空白
- "AI主动说我累了/不想聊/走神"的正式建模论文=0篇。现有"fatigue"全是用户疲劳或LLM生成退化。
- "吵架→冷战→和好"的闭环机制没有学术方案。只有产品涌现（Nomi/Replika）和Gottman心理学理论，中间的工程实现层是空的。
- CHI圈的"repair"指理解失败，与心理学的"情感修复"是两个概念，文献不对话。

### 缺口4："越描越黑"（自我修正失败）没有专门研究
现有self-repair文献全是ASR后处理（清理用户的不流利）或AI幻觉反思（检测自己的错误），不是"人在对话中口误→尴尬改口→越改越糟"的社交模拟。表达不完美只做到了副语言disfluency（um/uh/重复），语义层的表达失败是空白。

### 缺口5：评测"状态变化是否自然"没有可靠自动指标
现有五条路线各有致命局限：
- 探针-基线漂移法（SPASM/ContextEcho）：无法区分"好的演化"与"坏的漂移"——用户被怼了情绪变差是自然，模型通用化了也是漂移，分数一样。
- 轨迹统计量法（BEL/ETV/ECP）：聚合统计抹平事件结构，不管为什么变。
- 显式Markov转移图（DeepDialogue）：封闭脚本，开放域无法覆盖。
- LLM-as-judge轨迹rubric：PersonaEval实证判role-play仅54.5%（人类90.8%），judge自己不够人。
- Turing式pairwise：把流畅度、词汇多样性、状态流动混在一起，无法归因。

**核心空白**：一个"状态变化自然度"评测理论上需要(a) trigger模型（变化有没有合理前因）和(b) norm模型（这种变化幅度是否符合角色/关系阶段预期）。现有方法要么只做(b)的刚体版本，要么全甩给不可靠的LLM judge。**还没有一个被广泛采用的"状态流动自然度"自动指标。**

### 缺口6：角色扮演benchmark 90%只测身份一致性，不测状态流动
RoleEval/RoleBench/CharacterEval/InCharacter/RPEval主流benchmark测的都是"don't break character"（不崩人设），不是"状态随互动演化是否合理"。真正测状态流动的ArcANE/EmoCharacter/RoleBreak都是2025-2026刚冒头，且仍在测"对参考轨迹的保真度"而非开放式"这个变化本身合理吗"。

### 缺口7：工业产品的状态系统全是黑盒
Character.AI/Replika/Nomi/Kindroid都有实际的状态/情绪/关系行为，但**没有一家公开算法或内部表示**。Replika只暴露XP等级和心情记录，Nomi只谈Mind Map记忆，Character.AI只谈persona definition。可复现的状态系统全部来自独立开发者（Animus、Alive-AI、aikeya），而非大厂。

### 缺口8：对话节奏的"AI主动延迟"研究集中在客服场景，陪伴场景数据少
Gnewuch系列、Zhang CUI'24等动态延迟实验多在客服/任务型对话，陪伴型的"分钟级延迟+离线间隙"只有Non-Real-Time一篇概念验证。**陪伴型AI的节奏规范（什么时候该秒回、什么时候该隔几小时、什么时候该已读不回）缺乏系统研究。**

---

## 四、一句话结论

**状态流动的"数值+衰减+规则"层和对话节奏的CMC工程规则层已经成熟到3B可直接抄，但"不完美"的情绪/关系两层和"状态变化自然度"的评测仍是学术空白——谁先把 trigger→dynamics→generation 串成一个统一的轻量状态机，谁就占住了本地小模型人味化的生态位。**
