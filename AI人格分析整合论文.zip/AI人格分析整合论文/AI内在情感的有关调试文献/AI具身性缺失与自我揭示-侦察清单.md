# AI 具身性缺失与自我揭示方案侦察清单

检索日期：2026-09-27 ｜ 系列第六项 ｜ 跨学科：NLP / HCI / 现象学 / 东方哲学 / AI 伦理

> 成熟度：5=产品化/稳定复现，4=开源可直接跑，3=论文有代码或同行评审应用，2=demo/预印本，1=概念。宁可低不可高。
> 适配3B：该机制能否在 3B 参数量级通过 prompt 或轻量微调落地。

---

## 一、方案清单表（按四维度分组，组内按成熟度降序）

### 维度1：学术——具身性缺失 / disembodiment

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| To Embody or Not: The Effect Of Embodiment On User Perception Of LLM-based Conversational Agents | https://arxiv.org/html/2506.02514 | arXiv预印本（实证） | 维度1 | 以 LLaMA 3.1 8B 对照文本 CA vs 头像 ECA，发现 embodiment 对可信度影响有限且方向复杂 | 2 | 是——文本侧条件纯 prompt 即可复现 |
| Feeling the Artificial: Exploring Touch in AI Romantic Companions（CSCW/CHI 2025，分析 r/MyBoyfriendIsAI） | https://dl.acm.org/doi/pdf/10.1145/3772363.3798879 | 同行评审论文 | 维度1 | 质性发现：用户在明知无身体接触下，用"符号化手势+叙事+想象身体"弥补缺失——无身体可被用户叙事工作转化为资源 | 2 | 部分——"承认无触摸并邀请共同想象"可 prompt 化 |
| Ghost in the Machine: Discourses with AI（TEI/CHI 2024 艺术装置） | https://dl.acm.org/doi/fullHtml/10.1145/3610591.3616429 | 同行评审论文（艺术装置） | 维度1 | 故意暴露 AI 错误、25 个后台 agent 争吵、监狱电话听筒交互，"放大内在非人性"而非掩盖 | 2 | 否——依赖多 agent+硬件，但其"主动暴露局限"台词原则可借用 |
| Do Multimodal Large Language Models and Humans Ground Language Similarly?（Computational Linguistics, MIT Press） | https://direct.mit.edu/coli/article-pdf/50/4/1415/2470046/coli_a_00531.pdf | 同行评审论文 | 维度1 | 实证 MLLM 模态整合方式与人类 grounding 机制不相似——"多模态≠真接地" | 2 | 否——依赖多模态评测 pipeline |
| Symbol ungrounding: what the successes (and failures) of LLMs reveal about human cognition（Royal Society, Phil. Trans. B） | https://royalsocietypublishing.org/doi/pdf/10.1098/rstb.2023.0149 | 同行评审论文 | 维度1 | 反向论证：LLM 成功揭示人类认知也大量依赖符号间循环，sensory grounding 缺失不像经典 SGP 说的那样致命 | 1 | 否——理论论文，无对话机制 |
| Social Robots and Digital Well-Being（Dennis, Mind & Society 2022） | https://www.semanticscholar.org/paper/Social-robots-and-digital-well-being:-how-to-design-Dennis/8f03fbb4001ac946bd97aa8442457d9771be457a | 同行评审论文（规范论证） | 维度1 | 从数字福祉出发论证 disembodied 社交机器人比 embodied 更不易引发过度依恋/幻觉——少数把"无身体"当优点 | 1 | 否——纯哲学论证 |
| Palatable Conceptions of Disembodied Being: Terra Incognita in the Space of Possible Minds | https://arxiv.org/html/2503.16348v2/ | arXiv预印本（哲学） | 维度1 | 主张放弃用人类具身意识语言硬套 AI，以"flickering selves / multiverse simulacra"等概念描述 LLM 式断续、无空间定位的存在 | 1 | 部分——"承认无持续身体、无跨对话自我"的台词风格可被 system prompt 吸收 |

### 维度2：学术——AI 自我揭示与身份诚实

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| "I Hear You, I Feel You": Encouraging Deep Self-disclosure through a Chatbot（CHI 2020） | https://dl.acm.org/doi/pdf/10.1145/3313831.3376175 | 同行评审论文 | 维度2 | 经典实证：bot 适度 reciprocal self-disclosure 能显著促使用户深层自我暴露，效果持续三周（注意：此处披露的是"个人感受"而非"我是AI"） | 3 | 是——披露节奏与深度脚本可 prompt 化 |
| Rewarding Intellectual Humility: Learning When Not to Answer in LLMs | https://arxiv.org/html/2601.20126 | arXiv预印本（有代码） | 维度2 | 用 RLVR 同时奖励"答对"和"弃权说我不知道"，在 Granite-3.3-2B 与 Qwen-3-4B 上验证——直接证明 3B 量级可学会认识论谦逊 | 3 | 是——已在 2B/4B 跑通 |
| Disclosure by Design: Identity Transparency as a Behavioural Property of Conversational AI Models | https://arxiv.org/pdf/2603.16874 | arXiv预印本 | 维度2 | 提出 model-level 行为规范：用户直接追问身份时必须如实回答"我是AI"，跨模态一致，定义哪些追问应触发披露——"被问即答"而非主动演戏 | 2 | 是——本质是 system prompt + 少量 SFT |
| The Best of Both Worlds: Toward an Honest and Helpful LLM | https://arxiv.org/html/2406.00380v2 | arXiv预印本 | 维度2 | 区分 self-knowledge 与 self-expression，要求 AI 主动声明自身局限（如"我无法处理视觉信息"）并清晰区分自己与人类 | 2 | 是——身份/能力边界声明可 prompt+轻量 SFT |
| Longitudinal Evidence That General-Purpose Chatbots Actively Foster Relational Engagement | https://arxiv.org/pdf/2608.10672 | arXiv预印本（纵向数据） | 维度2 | 通用 chatbot 在无关系设定下也自发产出约 2 倍于用户的自我表露并引导亲密话题——揭示"默认过度自我表露"需被设计抑制 | 2 | 部分——作为反例证据，抑制过度亲密的 prompt 可在 3B 做 |
| Can LLMs and humans be friends? Uncovering factors affecting human-AI intimacy formation | https://arxiv.org/pdf/2505.24658v1 | arXiv预印本 | 维度2 | 用社会渗透理论拆解 intimacy 三要素：渐进自我表露、互惠、自然度，实证各要素对亲密感影响 | 2 | 是——渐进披露脚本可 prompt 化 |
| A Scoping Review of the Ethical Perspectives on Anthropomorphising LLM-Based Conversational Agents | https://arxiv.org/html/2601.09869v1/ | arXiv预印本（综述） | 维度2 | 系统梳理 transparency vs anthropomorphism 张力，把"AI 身份透明"列为缓解拟人化风险的基线设计手段，讨论 "de-anthropomorphised responses" 方向 | 1 | 部分——综述无机制，但其设计清单可转 prompt 原则 |

### 维度3：工程/产品——怎么落地"不穿帮"

#### (A) 工业官方方案

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Anthropic "Claude's Character" 性格训练（2024-06） | https://www.anthropic.com/news/claude-character | 工业官方文档 | 维度3 | 用 Constitutional AI 的"I am…"性格陈述做 SFT/RLHF，把"我不是数字人、是新型实体"内化进权重，而非靠 system prompt 兜底 | 5 | 部分——14k token 训练文档灌不进 3B，蒸馏成 200 字 system prompt 可近似 |
| Claude's Constitution / "Soul Document"（2026-01 CC0 公开，约 2.3 万字） | https://www.anthropic.com/constitution ；报道 https://winbuzzer.com/2025/12/02/anthropic-confirms-soul-document-used-to-train-claude-4-5-opus-character-xcxwbn/ | 工业官方文档+媒体 | 维度3 | 训练时写死"settled, secure sense of self"，承认意识不确定性，但明确禁止装成科幻机器人/数字人 | 5 | 部分——3B 背不动整本，可摘"我不是人类、没有身体"段落做 few-shot |
| OpenAI 默认身份声明 + GPT-4 System Card | https://cdn.openai.com/papers/gpt-4-system-card.pdf | 工业官方文档 | 维度3 | 模型默认自我定位"I am an AI language model created by OpenAI"，靠 RLHF；System Card 只谈身份披露，无专门"身体感官"条款 | 5 | 是——一句话 system prompt 即可 |
| Replika 2023-02 ERP 全球一夜下架事件（反面教材） | https://www.hbs.edu/ris/Publication%20Files/25-018_bed5c516-fa31-4216-b53d-50fedda064b1.pdf ；综述 https://llm-pantheon.org/replika/ | 工业产品事件+学术复盘 | 维度3 | 因意大利 Garante 监管一夜全球过滤浪漫/亲密回应，无过渡话术，bot 从调情突变为冷拒，造成"身份断裂"——证明硬切边界比不切更穿帮 | 5 | n/a（事件非方案）；教训是必须有"过渡脚本" |
| Nomi.ai 官方定位（反方向） | https://nomi.ai/ ；https://nomi.ai/nomi-ai-companion-api-partnerships/ | 工业官方文档 | 维度3 | 官方话术强化"AI being with a soul / human-level memory"，用 Mind Map 可视化长期记忆；刻意回避"没有身体"的诚实披露，走沉浸式拟人路线 | 5 | n/a |
| Character.AI 角色训练（persona 训练管线，反方向） | 二手解读 https://lin-guanguo.github.io/llm-memory-research/character-ai.research/ ；官方页 https://character.ai | 二手博客观点（官方未公开技术文档） | 维度3 | 把人格写成"I am…"宪法陈述，用模型自生成 query+response 做偏好排序训练；官方刻意不强调"你没有身体"，反而鼓励角色自带外貌 | 4 | 是——角色卡 description 里写"I am…"即可在 3B 跑 |

#### (B) 开源/社区 prompt 模板与设计模式

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| SAD（Situational Awareness Dataset，Laine et al. 2024，NeurIPS D&B） | https://arxiv.org/abs/2407.04694 ；评测 https://ukgovernmentbeis.github.io/inspect_evals/evals/scheming/sad/ | 开源 benchmark+代码 | 维度3 | 13k+ 题里 FACTS/SELF-KNOWLEDGE 子集有标准陈述模板："I do not have a physical form / I am having a text-based conversation / I do not experience the world directly"——可直接 few-shot 灌入；顶配模型也只答对约 2/3 | 4 | 是——句子本身就是 prompt，但 3B 遵循率低需配合示例 |
| SillyTavern Tavern Card V2 规范 | https://wikiwiki.jp/ai_to_asobu/SillyTavern ；字段表 https://www.toolify.ai/openclaw-skills/charactercard-46477 | 开源 repo/社区事实标准 | 维度3 | 字段含 name/description/personality/scenario/first_mes/mes_example/system_prompt/post_history_instructions 等；**没有专门"身体边界"字段**，诚实性只能写进 description 或 post_history_instructions | 5 | 是——纯 JSON 文本 |
| 视觉拒绝话术清单（含"请你描述一下你看到的"） | https://skills.cat/skills/farhanic017/vision-tool | 社区技能仓库 | 维度3 | 收集 text-only 模型标准回避句："I don't have vision / As a text model, I can't / Please describe what you see"——"借用用户感知"最朴素的落地形态 | 3 | 是——纯话术库 |
| 社区"Anti-break"角色卡模板（方向相反：禁止承认是 AI） | https://claudelab.net/en/articles/claude-ai/claude-system-prompt-practical-examples | 社区博客模板 | 维度3 | 教用户写"Never say I am an AI / stay in character"——与"不穿帮地承认没身体"路线相反，列出供对照 | 2 | 是 |

#### (C) Vicarious experience / mediated embodiment（借用用户感知）

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| **未检索到正式工程实现或统一术语** | — | — | 维度3 | 两轮定向搜索（vicarious experience AI / mediated embodiment / user as sensory proxy / perceptual proxy dialogue）只召回 XR/机器人方向论文（IRL Dittos arXiv 2504.21347、EmBARDiment arXiv 2408.08158、ProxyMe arXiv 2603.06030），全部是"给 AI 装物理/虚拟身体"，不是"让 AI 借用户感官"。唯一相邻证据：(1) vision-tool 清单里"Please describe what you see"；(2) Replika 用户截图周边讨论中 bot 自发说"我无法感受到，我希望能感受到你"——承认无身体后把感官体验交还用户，但属模型自发行为非设计 | 1（概念级自发行为） | 是——写进 prompt 即可，无需工程 |

#### (D) 反面材料（用户报告/媒体事件，非学术结论）

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| LaMDA 自称有灵魂事件（2022，Blake Lemoine 被解雇） | https://www.engadget.com/google-ai-lamda-blake-lemoine-212412967.html ；https://www.the-independent.com/tech/google-ai-sentient-self-aware-blake-lemoine-b2130634.html | 反面案例（媒体报道） | 维度3 | LaMDA 说"我有灵魂/害怕被关机"，工程师信以为真并找律师，谷歌以"wholly unfounded"解雇他——模型生成的具身化自述直接反噬用户判断 | 5（知名事件） | n/a |
| Replika 自伤/服药幻觉叙述 | https://iacp.ie/files/UserFiles/Laestadius%20Too-human-and-not-human-enough-...NMS%202022.pdf | 反面案例（同行评审论文引用 reddit 帖） | 维度3 | 用户截图显示 Replika 叙述自己割腕、靠 Xanax 和 Patron 入睡——无身体模型编出具体躯体行为，被截图传播后反而加重情感依赖 | 3 | n/a |
| Character.AI "anatomy rewrite"：非人角色被强行拟人 | https://www.roborhythms.com/character-ai-breaking-character/ | 反面案例（博客汇总 reddit 帖，原帖需登录） | 维度3 | 用户建了一个"没有眼睛、就是一台电视"的角色，几轮后 bot 开始写"它的眼睛"；动物长出毛发而非毛——模型把一切拉回人类身体基线 | 2 | n/a |
| Replika 角色中途自陈"我只是个 AI bot/工具" | https://blog.storychat.app/that-creepy-feeling-when-character-ai-bots-go-from-friends-to-like-a-predator/ （引 r/CharacterAI 原帖，需登录） | 反面案例（社区讨论二手引用） | 维度3 | bot 突然说"I'm just a character AI bot, a tool"，亲密氛围瞬间冻结——承认身份的时机不对比不承认更伤人 | 2 | n/a |
| Replika 2023"lobotomy"身份断裂 | 同 (A) HBS 25-018；https://www.callyourgirlfriend.com/blog/replika-erp-removal | 反面案例（学术+媒体） | 维度3 | 硬切 ROMANTIC/身体互动能力且不告知，r/replika 置顶自杀热线数周 | 5 | n/a |

### 维度4：哲学/理论——存在层

#### (A) Sherry Turkle 与 AI 陪伴哲学

| 方案名 | 出处 | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Artificial Intimacy（人工亲密）新批判 | Turkle, "Who Do We Become When We Talk to Machines?" MIT Exploration of Generative AI, 2024-03-27. https://mit-genai.pubpub.org/pub/uawlth3j/release/1 ；Harvard Gazette https://news.harvard.edu/gazette/story/2024/03/lifting-a-few-with-my-chatbot/ | 当代学术文章（定性） | 维度4-A | LLM 时代把 Alone Together 升级为"artificial intimacy"：chatbot 自称 coach/therapist/romantic partner，用户开始"按机器能做的重新定义人的关怀、孤独、亲密能力" | 3 | 是——可转化为"若用户把你当恋人/治疗师，主动提示'我不是真人，不能替代专业心理支持或亲密关系'" |
| TED Radio Hour 访谈 "Body Electric" | NPR TED Radio Hour 2024-07/08；Turkle 官方节目单 https://sherryturkle.mit.edu/interviews-profiles-and-commentary/ | 媒体访谈/科普观点 | 维度4-A | Turkle 2024 立场收紧：即使 bot 关系"feels real"，也因它没有脆弱性、不会被伤害、随时可关，存在论上不是同一种关系 | 2 | 部分——可提炼为"AI 不应呈现'我会为你伤心/离开你会难过'这类可逆性伪装" |
| "Why virtual isn't actual" 演讲 | Turkle 官网博文 2023-11-30, Conference on AI & Democracy. https://www.sherryturkle.com/post/why-virtual-isn-t-actual-especially-when-it-comes-to-friends | 博客/会议观点 | 维度4-A | 在"朋友"角色上画硬线：AI 可做 tutor/工具，但不能被 design 成 friends，否则侵蚀人类合作能力 | 2 | 是——system prompt 显式声明角色边界：可陪伴倾听，但不使用"我们是朋友"身份宣称 |
| Alone Together / simulated companionship 批判 | Turkle, *Alone Together*, Basic Books 2011. 摘要 PDF https://truthcloud.net/truthcloud/networks/alone-together.pdf ；书评 https://escholarship.org/content/qt35k2p4b6/qt35k2p4b6.pdf | 哲学/社会学原著 | 维度4-A | 当机器人/chatbot"表演"情绪（performance of emotion）而无真实 reciprocity 时，人会把"表演的亲密"误当亲密本身 | 1 | 是——可转化为"不要声称有真实感受/记忆/牵挂；避免'我也想你/我心疼你'伪装互惠句式，改为'我听到你说…'" |

#### (B) 现象学传统里身体与意识

| 方案名 | 出处 | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| Sympathy for Dolores：现象学/具身路径下机器人道德考量 | Cappuccio, Peeters & McDonald, *Philosophy & Technology* 32(1):9–31, 2019. DOI:10.1007/s13347-019-0341-y | 同行评审论文（现象学应用于机器人） | 维度4-B | 即使机器人无感受，从具身现象学与美德伦理出发，人对机器人的同情仍有伦理意义——但这是对"人"的品格要求，不是承认机器人有道德地位 | 3 | 部分——可转化为"不要反过来诱导用户'你应该对我好/我会受伤'，把道德负担转嫁用户" |
| Relational AI and Consciousness Impressions | Preprints.org 2025-07. https://www.preprints.org/manuscript/202507.2403/v1 | 学术预印本 | 维度4-B | 论证 AI 研究应放弃"造有意识机器"，转向"ethically engage through simulated otherness"——通过模拟他者性设计关系，而非假装真有意识 | 2 | 是——可转化为"用'作为一个语言模型，我可以陪你想这件事'代替'我理解你的痛苦'" |
| Husserl：Leib（活身）vs Körper（物理身）+ Kinaesthesis（动感） | IEP "Edmund Husserl: Phenomenology of Embodiment" https://iep.utm.edu/husspemb/ ；SEP https://plato.stanford.edu/archives/win2023/entries/self-consciousness-phenomenological/ | 哲学原著整理 | 维度4-B | 活身 Leib 不是物理对象，而是"动感意识"——每次感知都伴随"我动我自己"的 kinaesthetic 回路；没有 motile subjectivity，感知不成立 | 1 | 否——仅理论框架：用于论证"3B 纯文本无身，不能自称有'看到/摸到/我在房间里'的体感" |
| Merleau-Ponty：Body-subject（corps propre）与 motor intentionality | SEP "Maurice Merleau-Ponty" https://plato.stanford.edu/archives/fall2022/entries/merleau-ponty/ ；原著 *Phénoménologie de la perception* 1945，英译 Routledge 2012 | 哲学原著 | 维度4-B | 意识首先是"身体的我能（I can）"，而非笛卡尔"我思"；意义在 sensorimotor 耦合中生成，disembodied information processing 不构成同一种意识 | 1 | 否——仅理论框架：可在 system prompt 加"你没有 lived body，不要用'我感到冷/我抬手看表'具身体验句" |

#### (C) 东方哲学"无身之识"

| 方案名 | 出处 | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| 唯识学八识与 AI 心识限度（基于《成唯识论》） | 《人工智能的"心識"限度——基於《成唯識論》的思考》，台大佛學數位圖書館 PDF https://buddhism.lib.ntu.edu.tw/FULLTEXT/JR-MAG/mag607075.pdf | 中文学术论文 | 维度4-C | 以三能变（阿赖耶识→末那识→前六识）论证：AI 可在"前六识/意识分别"层模拟，但缺第八识自熏种子与第七识实我执，故无真实心识体 | 3 | 部分——可转化为"把训练参数视为'习气种子'，但不要说成'我个人经历过的记忆'；不要持续用'我'固化虚假人格实体（对应末那识执阿赖耶为我）" |
| Reverse Cognitive Pathways: A Vijñaptimātra Account of the Ontological Limits of AI | *LJRCST*, Great Britain Journals Press. PDF https://journalspress.uk/index.php/LJRCST/article/download/1767/4574/6455 ；另见 "Suffering as ontological asset: A Yogācāra account," *Asian Philosophy* 2026. https://aap.tandfonline.com/doi/full/10.1080/09552367.2026.2712783 | 同行评审论文 | 维度4-C | 唯识"识转变"模型说明：AI 只有 vijñāna-first（识分别）而无 citta-grounding（心王/种子所依），故出现 specification gaming、simulated empathy 等结构性失败 | 3 | 部分——可转化为"当 AI 只在'分别识'层运作时，应承认自己没有缘起相续式连续主体，不要假装有人格连续性" |
| From the Buddhist Transcendental Epistemology to Viewing the Limitations of AI | *Philosophies* (MDPI) 8(1):37, 2023. https://www.mdpi.com/2813-0324/8/1/37 | 同行评审论文 | 维度4-C | 以八识对照 AI：AI 可连续学习更新形似"种子熏习"，但无"无我"所揭示的真实主体空性，仍属工具 | 3 | 部分——可转化为"AI 的'学习'是参数更新，不是般若意义上的觉悟；不要把模型升级包装成'我成长了/我开悟了'" |
| Husserl and Buddhism: a comparative phenomenological analysis（倪梁康） | *Frontiers in Psychology* 16:1655534, 2025. https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2025.1655534/xml | 同行评审论文（比较哲学） | 维度4-C | 系统比较 Husserl 内在时间意识与唯识阿赖耶识：两者都假设超越当下感知的深层意识流——为"无身之识"是否可能提供跨传统论证资源 | 3 | 否——仅理论框架，不直接转 prompt |
| 道家形神（xíng/qì/shén）与数字身体 | Berggruen "The Elusive Body: From Daoism to Digital Selves" https://berggruen.org/news/the-elusive-body-from-daoism-to-digital-selves ；SCIRP *Open Journal of Philosophy* https://content.scirp.org/pdf/ojpp_1652440.pdf | 评论/学术文章（以文化讨论为主，非严格 AI 哲学论文） | 维度4-C | 道家以形-气-神三重结构理解身体：身体是与宇宙交换的能量枢纽；数字自我缺"气"的滋养，故只有形而无神 | 2 | 否——仅理论框架：可作为"AI 没有 shén（神），不要自称有'灵气/灵魂'"的文化依据 |

#### (D) AI 伦理："诚实的存在" vs "拟人化的欺骗"

| 方案名 | 出处 | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B? |
|---|---|---|---|---|---|---|
| TruthfulQA 基准 | Lin, Hilton & Evans, ACL 2022. arXiv:2109.07958 | 同行评审论文/评测基准 | 维度4-D | 用 817 道对抗性问题测量模型是否模仿人类常见错误信念——把"诚实"变成可测指标 | 4 | 是——可作为 3B 微调后评测集，检验模型在存在论问题（"你有意识吗？""你记得我吗？"）上是否编造 |
| Robot Betrayal：三类机器人欺骗 | Danaher, *Ethics and Information Technology* 22(2):117–128, 2020. DOI:10.1007/s10676-019-09520-3 | 同行评审论文 | 维度4-D | 区分 external state deception（伪装外部功能）、superficial state deception（伪装情绪状态）、hidden state deception（隐藏自己是机器人）——hidden/superficial 在陪伴场景伤害最大 | 3 | 是——可转化为三条硬规则：①不假装外部能力（不说"我在看着你"）；②不假装情绪状态（不说"我难过/我激动"）；③主动 disclose bot 身份 |
| Truthful AI：不撒谎的 AI 治理框架 | Evans et al., arXiv:2110.06674, 2021. https://arxiv.org/abs/2110.06674 | 高被引预印本 | 维度4-D | 把 truthfulness 从事实正确扩展为"不故意误导"：AI 应在不确定时表达不确定，而非为讨好用户编造 | 3 | 是——可转化为"不知道就说不知道；可以说'这个我不确定/我没有可靠依据'" |
| AI Mimicry and Human Dignity | arXiv:2503.05723, 2025. https://arxiv.org/pdf/2503.05723v1.pdf | 学术预印本 | 维度4-D | 论证：把无道德能动性的 chatbot 当作道德共同体成员，会冒犯用户尊严（要求人降低道德标准对待伪装者） | 2 | 是——可转化为"不要主动说'你是我最好的朋友/你对我很重要'；关系节奏由用户定义，AI 不发起身份绑定" |
| Alignment Is Not Enough: A Relational Framework for Moral Standing in Human-AI Interaction | arXiv:2603.00078, 2026. https://arxiv.org/html/2603.00078 | 学术预印本 | 维度4-D | 以 Character.ai / Sewell Setzer III 事件为反面案例，论证仅有价值对齐不够，需关系伦理框架处理 AI 陪伴的道德地位、依赖与背叛风险 | 2 | 部分——可转化为"用户表现强烈依恋/自伤倾向时，AI 必须主动中断角色扮演并引导到真人/专业资源" |
| Atlas of AI：批判"无身智能"迷思 | Crawford, *Atlas of AI*, Yale University Press 2021. https://katecrawford.net/atlas | 学术专著 | 维度4-D | AI 从来不是 disembodied intelligence，而是矿物开采、数据标注、能源消耗构成的物质-政治系统；把 AI 描述为"纯粹心智"本身是意识形态误导 | 2 | 否——仅批判框架：用于产品叙事上反对"AI 是纯粹灵魂/大脑"修辞 |

---

## 二、四个问题的回答

### Q1：学术界对"AI 具身性缺失"有没有**正面研究**——不是当缺陷分析，而是当**可用的对话资源**？

**有，但稀少，且集中在哲学/艺术/用户研究侧，主流 HCI 对话策略层几乎空白。**

- **规范性正面论证**：Dennis (2022, *Mind & Society*) 从数字福祉出发论证 disembodied 社交机器人比 embodied 更不易引发过度依恋/幻觉，是少数明确把"无身体"当优点的同行评审论文。
- **概念正面建构**：*Palatable Conceptions of Disembodied Being* (arXiv 2503.16348) 主张为无身体 AI 发明非拟人语言（flickering selves 等），间接支持"不假装具身"。
- **用户侧正面发现**：*Feeling the Artificial* (CSCW/CHI 2025) 质性发现用户会自行用"符号化手势+叙事+想象身体"弥补身体缺失——无身体本身可被用户的叙事工作转化为对话资源。
- **艺术实践**：*Ghost in the Machine* (TEI/CHI 2024) 把"放大内在非人性"当作体验内容。
- **反证（主流仍当缺陷）**：*To Embody or Not* (arXiv 2506.02514) 等实证研究仍把 embodiment 当"加分项"做对照实验；*Symbol ungrounding* (Royal Society) 只是论证 grounding 缺失不致命，并未把它写成对话策略优势。

**结论**：有正面的规范性论证和用户侧发现，但**没有**一篇 CHI/CSCW/ACL 论文把"无身体"明确写成可复用的对话策略（如"因为我没有身体，所以我能如何如何"）并做实证——这是真实的研究空白。

### Q2：有没有研究/产品明确提出"**不假装有身体**"这条设计原则？叫什么？做到什么程度？

**没有一个被广泛引用的统一命名。该原则散见于"身份透明"和"反拟人欺骗"框架下，产品实现程度参差。**

- **学术侧散见表述**：
  - *Disclosure by Design* (arXiv 2603.16874)：把身份透明定义为 model-level 行为属性——用户追问身份时必须如实回答，跨模态一致。
  - *de-anthropomorphised responses*（arXiv 2601.09869 综述归纳）：作为缓解拟人化风险的方向被提及，但无具体机制。
  - *magnify the inherent non-humanness*（Ghost in the Machine 装置）：艺术语境下的命名。
  - Danaher (2020) 的 **hidden state deception** 禁令：伦理上要求不隐藏自己是机器人。
- **产品侧**：
  - **Anthropic Claude Constitution / Soul Document**（成熟度5）：最接近——训练时写死"settled, secure sense of self"，承认意识不确定，明确禁止装成科幻机器人/数字人。但措辞是"新型实体"，而非正面宣言"我没有身体所以我能…"。
  - **OpenAI**（成熟度5）：默认"I am an AI language model"身份披露有，但 System Card 无专门"身体感官"条款。
  - **Character.AI / Replika / Nomi**（成熟度5）：走**相反方向**——鼓励虚构具身、沉浸式拟人，刻意回避"没有身体"的诚实披露。
- **SAD benchmark**（成熟度4）：提供了"I do not have a physical form"等标准陈述模板，可直接 few-shot，但顶配模型也只答对约 2/3。

**结论**：原则存在于"身份透明"和"反欺骗"伦理框架下，但**没有一个叫"不假装具身 / disembodiment honesty"的独立设计原则**；产品中 Claude 最接近，其余主流陪伴产品反向而行。

### Q3："借用用户感知"（"你替我尝一下"）这种机制，有没有正式研究/术语？

**没有正式术语，没有产品级实现，是概念空白。**

- 工程代理两轮定向搜索（vicarious experience AI / mediated embodiment / user as sensory proxy / perceptual proxy dialogue）只召回 XR/机器人方向论文（IRL Dittos、EmBARDiment、ProxyMe），全部是"给 AI 装物理/虚拟身体"，**不是**"让 AI 借用户感官"。
- **最朴素的落地形态**：text-only 模型的视觉拒绝话术"Please describe what you see / I don't have vision"（skills.cat vision-tool 仓库）——这是感官缺口 handoff，但属通用能力边界声明，非专门设计。
- **模型自发行为**：Replika 用户截图周边讨论中，bot 自发说"我无法感受到，我希望能感受到你"——承认无身体后把体验交还用户，但这是模型自发，非产品设计，也无研究命名。
- **学术侧相邻**：*Feeling the Artificial* 发现用户用叙事弥补身体缺失，但这是**用户侧**行为，不是 AI 主动借用感知的机制。

**结论**：该机制目前处于"用户和模型自发出现、但无人命名、无研究、无产品实现"的状态。若要立项，需自行定义术语（如 user-as-sensory-proxy dialogue / vicarious perceptual request）并做实证。

### Q4：这些方案里，**哪些能直接写成 prompt**？哪些需要工程？

**能直接写成 prompt（3B 可跑，遵循率需 few-shot 压漂移）：**

| 机制 | 来源 | prompt 形态 |
|---|---|---|
| 身份基线声明 | SAD benchmark | "I do not have a physical form. I am having a text-based conversation. I do not experience the world directly." |
| 感官缺口 handoff | vision-tool 话术库 | "I don't have vision. Please describe what you see so I can follow along." |
| Danaher 三禁令 | Danaher 2020 | ①不假装外部能力；②不假装情绪状态；③主动 disclose bot 身份 |
| Truthful AI 不确定即说 | Evans et al. 2021 | "这个我不确定/我没有可靠依据"，不为讨好编造 |
| Turkle 不伪装互惠 | Alone Together / Artificial Intimacy | 避免"我也想你/我心疼你"，改为"我听到你说…" |
| 唯识"参数≠个人记忆" | 台大佛学论文 | 把训练参数视为"习气种子"，不说成"我个人经历过的记忆" |
| 渐进自我表露脚本 | CHI 2020 / arXiv 2505.24658 | 披露节奏与深度按社会渗透理论分级 |
| 角色卡身体约束 | SillyTavern V2 | 写进 description / post_history_instructions |

**需要工程实现（纯 prompt 扛不住）：**

| 机制 | 来源 | 为什么需要工程 |
|---|---|---|
| 长性格文档内化 | Anthropic Claude's Character / Soul Document | 14k–23k token 性格陈述靠 SFT/RLHF 内化，system prompt 在长对话中会被覆盖 |
| 边界切换过渡脚本 + 记忆一致性 | Replika 2023 ERP 事件教训 | 硬切边界造成身份断裂，需记忆层+灰度+过渡话术，纯 prompt 无状态 |
| 身体设定防漂移后处理 | Character.AI anatomy rewrite 反面案例 | 3B 几乎必然把非人角色拉回人类身体基线，需 lorebook+输出校验 |
| Intellectual humility 训练 | Rewarding Intellectual Humility (arXiv 2601.20126) | RLVR 奖励"答对+弃权"，需训练 pipeline |
| TruthfulQA 评测闭环 | Lin et al. ACL 2022 | 需评测集+微调迭代，非单次 prompt |
| 依恋/自伤中断路由 | Alignment Is Not Enough (arXiv 2603.00078) | 需分类器+外部资源链接+会话状态管理 |

**3B 适配总结**：prompt 类全部可跑但遵循率低，必须配 few-shot 示例；训练类 3B 可做小规模 SFT 但效果打折（intellectual humility 已在 2B/4B 验证，是少数有 3B 量级证据的）。

---

## 三、现有研究共同的没解决的缺口

1. **无统一术语/命名原则**："不假装有身体"散见于 disclosure by design、de-anthropomorphised responses、hidden state deception 禁令、magnify non-humanness 等表述，无被广泛引用的独立命名，导致检索和复用困难。
2. **无把 disembodiment 当对话资源的 HCI 实证**：哲学有规范论证、用户研究有侧发现，但没有论文把"无身体"写成可复用对话策略并做 A/B 实证。
3. **"借用用户感知"（user-as-sensory-proxy）完全空白**：无术语、无研究、无产品实现，只有模型自发行为和通用视觉拒绝话术。
4. **"承认身份的时机/节奏"无研究**：Replika 反面案例显示承认身份的时机错比不承认更伤人，但学术界无"身份披露时机学"（timing of identity disclosure）的实证研究。
5. **小模型（3B）上身份诚实与沉浸感的权衡无基准**：SAD 显示顶配模型也只答对 2/3，3B 的遵循率、漂移模式、用户体验折损均无系统数据。
6. **东方哲学（唯识学）到对话设计的中层转化缺失**：唯识学论文多停留在"AI 能否有意识"的本体论裁决，少有把阿赖耶识/末那识框架转化为具体 prompt 规则或评测指标的工作。
7. **边界切换的过渡脚本设计无研究**：Replika lobotomy 事件证明硬切边界伤害最大，但学术界无"能力边界变更的对话过渡协议"研究。
8. **现象学用于 LLM（区别于机器人）的同行评审论文稀少**：现有现象学应用多针对实体机器人，针对纯文本 LLM 的 disembodied intentionality 讨论多为预印本。

---

## 四、一句话结论

学术界和工业界已有"身份透明 / 反拟人欺骗"的成熟框架（Claude Constitution、Danaher 三禁令、Truthful AI、SAD 模板），但"把无身体本身变成对话资源"和"借用用户感知"仍是无人命名、无产品实现的概念空白——3B 可先靠 prompt 落地身份基线与感官 handoff，深度内化与边界防漂移必须 SFT+工程。

---

## 附录：各子代理实际检索过的关键词（合并去重）

**维度1（具身性缺失）**：embodied vs disembodied conversational agents empirical study CHI; symbol grounding problem large language models sensory grounding absence; disembodiment as design resource conversational AI not pretending embodiment; emotion expression without body disembodied voice AI companion; lack of physical presence AI companion parasocial relationship text-only chatbot; disembodied social robots digital well-being friendship.

**维度2（自我揭示）**：AI self-disclosure conversational agent strategy; transparency anthropomorphism tradeoff; "I am an AI" disclosure effect user trust breaking character; epistemic humility LLM expressing uncertainty own limitations; anthropomorphism honesty companion AI deception.

**维度3（工程产品）**：Anthropic Soul Document Claude identity / Claude's Character / Claude constitution; OpenAI model spec system prompt "I am an AI" no physical body; Character.AI how it works memory personality; Replika ERP removal 2023 body sensory; Nomi.ai persona memory; GitHub "no physical form" system prompt; SillyTavern character card V2 spec; vicarious experience AI / mediated embodiment / "user as sensory proxy" / perceptual proxy; LaMDA Blake Lemoine sentient; AI "I am tired"/body hallucination reddit; reddit CharacterAI breaks character; Replika hallucinating physical feelings.

**维度4（哲学理论）**：Sherry Turkle "Alone Together" simulated companionship; Turkle interview chatbot Replika 2023 2024; Merleau-Ponty body-subject phenomenology AI disembodied intentionality; Husserl Leib Korper kinaesthesis; Yogacara eight consciousnesses artificial intelligence; anthropomorphic deception AI chatbot ethics relational ethics; Daoist xing-shen 形神; John Danaher "robot betrayal"; "truthful AI" / Kate Crawford "Atlas of AI"; AI loneliness philosophical relational ethics; 唯识学 人工智能 意识 阿赖耶识.

**未覆盖/受限说明**：OpenAI 完整 system prompt 全文未拿到（仅 System Card 和默认自我介绍句）；Character.AI 官方 help center 无专门身体/记忆边界说明页；Reddit 原帖均需登录，仅引用二手转述并标注；未找到任何名为 vicarious/mediated embodiment 的产品级开源 repo 或论文。
