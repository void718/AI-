# LLM 记忆冲突方案侦察总报告

> 侦察日期：2026-09-27
> 成熟度口径：5=产品化/稳定复现；4=开源可直接跑；3=论文有代码；2=demo/预印本；1=概念/现象记录。宁可低不可高。
> 3B适配：是=纯数据结构/语法约束可本地跑；部分=存储可本地但LLM推理步骤退化；否=托管或依赖强模型/专门微调。
> 来源分层：学术(ACL/EMNLP/ICLR/NeurIPS/arXiv)、工业(官方文档)、开源(GitHub)、反面(产品错乱案例)。

---

## 一、方案清单表（按六维度分组，组内成熟度降序）

### 维度1：为什么会记错——诊断类

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B |
|---|---|---|---|---|---|---|
| Lost in the Middle | https://arxiv.org/abs/2307.03172 | 学术(TACL'24) | 1 | 长上下文相关信息落中部时性能U型塌陷，记错源于位置/注意力偏差而非知识本身 | 4 | 是 |
| MemoryBank（艾宾浩斯遗忘曲线） | https://arxiv.org/abs/2305.10250 | 学术(AAAI'24)+代码 | 1/2 | 给每条记忆打强度分，按时间衰减、按访问强化，显式建模过时事实 | 4 | 是 |
| A-MEM（反思链自组织记忆） | https://arxiv.org/abs/2502.12110 | 学术+代码 | 1 | 模型用反思链把经验自组织成可检索记忆流，诊断写入/提取失败点 | 4 | 是 |
| Adaptive Chameleon or Stubborn Sloth | https://arxiv.org/abs/2305.13300 | 学术(ICLR'24) | 1 | 受控实验：LLM面对参数记忆与上下文冲突时易被"连贯可信"外部证据说服，部分一致时出现确认偏误 | 3 | 是 |
| When Not to Trust Language Models | https://arxiv.org/abs/2212.10511 | 学术(ACL'23) | 1 | 参数记忆在长尾事实上弱、热门事实上强，给出"何时该检索"的判别条件 | 3 | 是 |
| Knowledge Conflicts for LLMs: A Survey | https://arxiv.org/abs/2403.08319 | 综述(EMNLP'24) | 1/3 | 把冲突统一划为context-memory / inter-context / intra-memory三类，诊断分类标准框架 | 3 | 是 |
| Measuring and Controlling Persona Drift | https://arxiv.org/abs/2402.10962 | 学术 | 1 | LLaMA2-chat-70B仅8轮对话人设即显著漂移，归因于transformer对条件token注意力逐步衰减 | 3 | 是 |
| CoCoA（置信度自适应解码） | https://arxiv.org/html/2508.17670v1 | 学术 | 1/4 | token级用熵差/分布散度决定听参数知识还是听上下文 | 3 | 否(需logits) |
| In Praise of Stubbornness | https://arxiv.org/abs/2502.04390 | 学术实证 | 1/3 | 用矛盾事实做持续更新会灾难性污染最多80%无关知识，记忆corruption直接证据 | 2 | 否 |
| Deceptive Grounding（实体归因失败） | https://arxiv.org/abs/2607.09349 | 学术 | 1 | RAG引用真实文献却把实体X的临床证据安到实体Y上，忠实度/引用检查全过 | 2 | 是 |
| FACTUM（引用幻觉机理） | https://arxiv.org/abs/2601.05866 | 学术 | 1 | 长文RAG引用幻觉源于Attention(读)与FFN(写)通路间尺度相关协调失败 | 2 | 部分 |
| Does RAG Know When Retrieval Is Wrong? | https://arxiv.org/abs/2605.14473 | 学术 | 1/3 | 用belief-revision形式化诊断"上下文何时压过参数先验" | 2 | 是 |
| LLM as Discounted Bayesian Filters | https://arxiv.org/abs/2512.18489 | 学术实证 | 1/3 | 拟合出折扣因子γ≪1，证明LLM天生对旧证据打折、并不真"覆盖" | 2 | 否 |
| CoRect（参数抑制机制修正） | https://arxiv.org/html/2602.08221 | 学术 | 1/3 | 定位覆盖检索证据的深层FFN层做隐藏状态干预 | 2 | 否(需内部机制) |
| MACR（显式知识冲突解决） | https://arxiv.org/pdf/2606.20245v1.pdf | 学术 | 1/4 | 同时解决参数-上下文与多上下文之间冲突 | 2 | 部分 |
| Cross-source Conflation（跨源混淆） | https://www.k-ai.ai/en/news/cross-source-conflation-rag-wrong-source-attribution/ | 行业分析 | 1 | 事实正确却引用错文档，传统benchmark测不出的隐蔽归因错误 | 1 | 不适用 |

### 维度2：记忆架构——从结构上避免

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B |
|---|---|---|---|---|---|---|
| OpenAI ChatGPT Memory + Dreaming | https://openai.com/index/memory-and-new-controls-for-chatgpt/ | 工业产品 | 2 | 跨对话保存bullet记忆，2026上线后台Dreaming长期上下文合成，专门解决staleness/correctness/scalability | 5 | 否(托管) |
| Zep Context Lake（时序知识图谱） | https://help.getzep.com/v3/graph-overview | 工业产品 | 2/4 | bi-temporal事实：每条边带valid-from/valid-to，矛盾时旧边"关闭失效"而非删除 | 5 | 否(托管+抽图强模型) |
| Anthropic Claude Memory Tool | https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool | 工业产品 | 2/4 | 记忆即文件目录，just-in-time检索，Claude自己CRUD持久化文件 | 5 | 否(托管) |
| Letta（原MemGPT） | https://github.com/letta-ai/letta (~24k★) | 开源库 | 2/4 | 三层：Core Memory(persona+human命名块常驻上下文、agent自编辑)/Recall(可搜对话史)/Archival(向量库) | 4 | 部分(自编辑core强依赖tool-calling，3B偏弱) |
| Mem0 | https://github.com/mem0ai/mem0 (~60k★)；arXiv:2504.19413 | 开源库 | 2/4 | 混合存储(向量+KV+图谱)，旧版ADD/UPDATE/DELETE/NOOP四动作判冲突；2026-04 v3改ADD-only只追加不覆盖 | 4 | 部分(后端可插拔接本地3B，但抽取/实体链接质量下降) |
| Graphiti（Zep开源时序图谱） | https://github.com/getzep/graphiti (~31k★)；arXiv:2501.13956 | 开源库 | 2/4 | 实时时序知识图谱，bi-temporal事实+provenance，被supersede的旧事实打valid-to而非删除 | 4 | 部分(可自托管，但实体/边抽取LLM重，依赖Neo4j/FalkorDB) |
| Cognee | https://github.com/topoteretes/cognee (~30k★) | 开源库 | 2 | 三存储(关系型+向量+图谱)，ECL管线，会话热缓存+后台异步同步永久图谱，提供forget()/improve() | 4 | 部分(有嵌入式SQLite/LanceDB/Kuzu可本地起，但ECL抽图LLM密集) |
| LangGraph Stores / LangChain Memory | https://docs.langchain.com/oss/python/langgraph/memory | 开源库 | 2/4 | 跨线程长期记忆存JSON文档，按namespace/user_id+key分层；EntityMemory按实体攒事实 | 4 | 是(存储层纯KV/JSON，检索/总结才需LLM) |
| Microsoft Foundry Memory | https://learn.microsoft.com/azure/foundry/how-to/develop/langchain-memory | 工业产品 | 2 | 分user profile memory(稳定事实/偏好，跨会话身份锚)+chat summary memory(话题摘要)，user_id绑定scope | 4 | 否(Azure托管) |
| Google Gemini Saved Info | https://insiderllm.com/pdfs/ai-memory-wall-why-chatbot-forgets.pdf(二手) | 工业产品 | 2 | 保存稳定偏好(Saved Info)+跨会话召回(Personal Context)，仅付费开放；官方未单列冲突机制 | 4 | 否(托管) |
| Memary | https://github.com/kingjulio8238/Memary (~2.5k★) | 开源库 | 2 | MemoryStream短期流→EntityKnowledgeStore长期(聚合实体频次+最近时间戳)，自动生成/更新知识图谱 | 3 | 部分(小仓库，抽取靠LLM；图谱结构可本地) |
| PersonaAgent（episodic+semantic） | https://arxiv.org/pdf/2506.06254 | 学术+代码 | 2 | episodic存带时间个人经历，semantic把反复互动蒸馏成稳定用户画像，检索时合并 | 3 | 部分(蒸馏步骤吃LLM) |
| Bi-Mem（persona-level全局约束） | https://arxiv.org/html/2601.06490 | 学术+代码 | 2/4 | persona-level memory P(5维:basic-info/interests/…)作为全局约束保证记忆一致性，归纳-反思双向构建 | 3 | 否(研究原型，依赖较大模型) |
| LongMem（架构非基准） | https://arxiv.org/abs/2306.07174 | 学术架构 | 2 | 冻结LLM当记忆编码器、外挂可变decoder；注意这是架构不是评测集 | 3 | 否 |
| 结构化vs向量记忆对比（工程经验） | https://memnode.dev/articles/agent-memory-vs-vector-db 等 | 工程博客 | 2 | 向量库擅语义检索但丢实体/关系/时序；精确ID、身份字段、偏好更新应走结构化SQL/JSON/图谱；生产多为混合 | 2 | 是(结构化KV/SQL层可本地) |

### 维度3：冲突检测与裁决

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B |
|---|---|---|---|---|---|---|
| BELIEFMEM（对话式信念修正记忆） | https://cseweb.ucsd.edu/~jmcauley/reviews/emnlp26d.pdf | 学术(EMNLP) | 3 | 每条抽取claim分类为EXP/REV/DUP/CON，用AGM/Hansson修正算子替代append-or-replace | 3 | 部分(resolver可小模型化) |
| Astute RAG | https://arxiv.org/abs/2410.07176 | 学术(ACL'25) | 3 | 后检索阶段显式区分内部/外部知识来源，迭代合并后按信息可靠性裁决 | 3 | 否 |
| ConflictBank | https://arxiv.org/abs/2408.12076 | 基准 | 3/6 | 专测知识冲突下模型行为，统一定义冲突类型与"正确采信率" | 3 | 部分 |
| Graph-Native Cognitive Memory（属性图对齐AGM） | https://arxiv.org/pdf/2603.17244 | 学术预印本 | 3 | 证明属性图记忆操作语义满足AGM K*2–K*6及Core-Retainment | 2 | 部分 |
| Discounted Bayesian Filters | https://arxiv.org/abs/2512.18489 | 学术实证 | 3 | 拟合γ<1折扣因子，模型确实给旧证据打折但远非贝叶斯最优 | 2 | 是 |
| EvolveCast | https://arxiv.org/abs/2509.23936 | 学术+基准 | 3 | 用训练截止后新证据测模型是否按证据修正预测，对照人类修正幅度 | 2 | 是 |
| BeliefShift | https://arxiv.org/abs/2603.23848 | 基准 | 3/6 | 形式化区分"证据驱动理性belief revision"与"被话术带偏的opinion drift" | 2 | 部分 |
| TrustMargin | https://arxiv.org/abs/2606.08397 | 学术 | 3 | 免训练仲裁层：参数先验margin+证据绑定margin，在"直接回答"与"采信RAG"间选边 | 2 | 部分 |
| ConflictRAG | https://arxiv.org/abs/2605.17301 | 学术 | 3 | 多文档冲突分事实型/时序型/观点型，分别用熵-TOPSIS等策略解决 | 2 | 部分 |
| TOKI（双时态矛盾代数） | https://arxiv.org/html/2606.06240v1 | 学术预印本 | 3 | 矛盾解决建模为写时并发控制，给记忆库声明隔离级别 | 2 | 部分 |
| TEPA（撤销陈旧记忆） | https://arxiv.org/abs/2608.07429 | 学术/系统 | 3/4 | "有效性"做成记忆显式状态，同key新证据到来即撤销旧先例，旧记录留档审计 | 3 | 是(键值先例，轻量) |
| Illusion of Erasure in Knowledge Editing | https://arxiv.org/html/2606.23276v1 | 学术实证 | 3/4 | 知识编辑不是真擦除，而是"新事实提升+旧事实抑制"的方向叠加 | 2 | 否 |
| MemToC | https://arxiv.org/abs/2608.26295 | 基准 | 3/6 | 受控评测工具返回与参数记忆冲突时模型如何仲裁，区分source preference与source correctness | 1 | 部分 |

### 维度4：纠错与可撤销

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B |
|---|---|---|---|---|---|---|
| Anthropic Memory 文件CRUD | https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool | 工业产品 | 4 | 记忆即文件，用户/agent可直接read/update/delete任意记忆文件，天然可撤销 | 5 | 否(托管) |
| OpenAI 记忆删除/"忘记" | https://openai.com/index/memory-and-new-controls-for-chatgpt/ | 工业产品 | 4 | 自然语言说"忘掉X"，或设置里查看/删除单条或全清；删对话不自动删记忆 | 5 | 否(托管) |
| Mem0 update/delete API | https://docs.mem0.ai/getting-started/quickstart | 开源库 | 4 | client.update(memory_id,data)原地改写；delete(memory_id)删单条、delete_all(user_id)清用户 | 4 | 部分(API本地可跑，改写判断本地模型弱) |
| Zep/Graphiti 事实失效(bi-temporal) | https://help.getzep.com/v2/concepts | 工业/开源 | 4/2 | 纠错不是删旧记忆而是给旧边写valid-to时间窗，新事实开窗；错误事实被关闭后不再被检索命中 | 4 | 部分(机制本地可跑，抽图LLM是瓶颈) |
| EasyEdit（统一ROME/MEMIT/KN） | https://github.com/zjunlp/EasyEdit | 开源库 | 4 | 统一封装模型层知识编辑：ROME(MLP单步)、MEMIT(跨层批量)、KN(定位神经元)、SERAC/GRACE(memory-based遗忘) | 3 | 部分(3B可跑编辑，但改的是参数化知识而非用户记忆) |
| ROME | https://arxiv.org/abs/2202.05262 | 学术+代码 | 4 | 因果追踪定位事实存储的MLP层，直接修改权重矩阵完成"改一条记忆" | 3 | 部分(需预计算因果定位) |
| MEMIT | https://arxiv.org/abs/2305.13172 | 学术+代码 | 4 | ROME扩展到跨多层批量编辑上千条事实，减少互相干扰 | 3 | 部分 |
| GRACE/SERAC（unlearning） | 经EasyEdit收录 | 学术+代码 | 4 | memory-based反学习：不改原权重，用外部记忆/超网络推理时屏蔽旧事实，可撤销 | 3 | 部分 |
| "编辑并未真正擦除知识"警告 | https://en.papernotes.org/ACL2026/one-mask-to-rule-them-all... | 学术结论(ACL26) | 4 | ROME/MEMIT类编辑只是用overattention压制旧事实，旧事实仍留在MLP/残差路径，小mask即可复活 | 3 | —(依据) |
| 错误扩散阻断（工程经验） | https://www.getzep.com/ai-agents/persistent-memory-for-ai-agents/ | 工程博客 | 4/2 | 靠"追加不覆盖+bi-temporal失效+provenance溯源"让错误记忆不再被下游命中，而非指望一次性改对 | 2 | 是(溯源/时间窗逻辑可本地) |

### 维度5：输出前自检

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B |
|---|---|---|---|---|---|---|
| RAGAS Response Groundedness/Faithfulness | https://docs.ragas.io ；https://github.com/explodinggradients/ragas | 开源库 | 5 | 自动判断回答中每条claim能否在检索上下文找到支撑(0/1/2分)，生成后做groundedness校验 | 4 | 部分(评测器再调一个LLM打分，3B当裁判偏弱) |
| 受限解码/JSON Schema约束身份字段 | llama.cpp GBNF、outlines https://github.com/dottxt-ai/outlines | 开源库/工程实践 | 5/2 | 用JSON schema/function calling/语法约束解码，强制身份字段(姓名/偏好/ID)输出为固定枚举，从生成端杜绝身份漂移 | 4 | 是(语法约束解码在小模型上稳定，不依赖大模型推理) |
| Self-RAG（反思token） | https://selfrag.github.io/ ；arXiv:2310.11511 | 学术+代码 | 5 | 模型自带ISREL/ISSUP/ISUSE反思token：生成前判断要不要检索、生成后判断检索段是否支撑，不支撑就重生成 | 3 | 否(需专门微调权重，小模型版弱) |
| Self-Consistency（多路径投票） | arXiv:2203.11171 | 学术+代码 | 5 | 对同一问题采样多条CoT路径，取多数一致答案，降低单条错误推理被当成记忆事实的概率 | 3 | 部分(3B能跑但要采样N次慢，小模型路径多样性差、投票收益缩水) |
| CRITIC（外部工具批判校验） | arXiv:2305.11738 | 学术+代码 | 5 | 生成后让模型调用外部工具(搜索/知识库/计算器)对关键陈述做批判性核查再修订 | 3 | 否(强依赖工具调用与强批判能力，3B难稳定) |
| Self-Refine（自评-自改循环） | arXiv:2303.17651 | 学术+代码 | 5 | draft→critique→refine闭环，带最大迭代与"答案不再变化"停止条件，可自检记忆偏好与刚说的是否矛盾 | 3 | 部分(3B自我批评弱，循环易空转或越改越差) |
| 自我纠正基准研究（警告） | NeurIPS2025；arXiv:2407.14507 | 学术结论 | 5 | 无外部信号的"纯自我纠正"在事实类任务上常不升反降；CRITIC类带外部资源的纠正才有效 | 3 | —(依据) |
| 引用强制/citation enforcement | https://learnixo.io/blog/safe-rag-vs-hallucination | 工程博客 | 5 | 每条事实claim后挂[Doc:id]引用，输出带confidence+citations的JSON，便于自动NLI校验与人工复核 | 2 | 部分(模板可本地，引用质量看模型) |

### 维度6：评测基准与指标

| 方案名 | 出处(URL) | 类型 | 维度 | 核心机制一句话 | 成熟度 | 适配3B |
|---|---|---|---|---|---|---|
| LongMemEval | https://arxiv.org/abs/2410.10813 | 基准(ICLR'25) | 6 | 500题测五能力：信息抽取/多会话推理/时序推理/知识更新/拒答；商业助手跨会话掉点约30% | 4 | 部分 |
| LoCoMo | https://arxiv.org/abs/2402.17753 | 基准 | 6 | 10段约600轮多人对话，QA+时序+对抗三任务；长上下文/RAG在对抗题上掉83% | 4 | 部分 |
| MSC / Beyond Goldfish Memory | https://arxiv.org/abs/2107.07567 | 基准 | 6 | 5会话人-人闲聊，每会话标注个人要点摘要，长对话身份/属性记忆早期标准集 | 4 | 是 |
| PICon（多轮persona一致性） | https://arxiv.org/html/2603.25620v4 | 学术基准 | 6/1 | 逻辑链式多轮问，测内部/外部/重测三维一致性，现有系统均低于人类基线 | 3 | 是 |
| TwinVoice（persona多维基准） | https://arxiv.org/html/2510.25536v1 | 学术基准 | 6/1 | 社会/人际/叙事三维，六能力含memory recall与opinion consistency | 3 | 是 |
| PersonaGym | https://arxiv.org/pdf/2407.18416v1 | 学术基准 | 6/1 | 测语言习惯、persona属性问答一致性、毒性控制 | 3 | 是 |
| CharacterEval（中文角色扮演） | ACL 2024 RPCA | 学术基准 | 6/1 | 中文角色扮演综合评测 | 3 | 是 |
| PersonaMem（Know Me, Respond to Me） | https://arxiv.org/abs/2504.14225 | 基准 | 6 | 20人设×15领域×跨会话动态偏好演化，专测偏好更新与ownership | 3 | 部分 |
| PersoBench | https://arxiv.org/abs/2410.03198 | 基准 | 6 | 跨多数据集统一测个性化回答与人设一致性，暴露GPT-4级模型一致性仍不足 | 3 | 是 |
| MPBench（记忆投毒基准） | https://arxiv.org/html/2606.04329 | 攻击基准 | 6 | 归纳4写入通道、9漏洞、6类攻击，给出记忆投毒评测集 | 3 | 部分 |
| Best Friends, Not Forever（长程persona坍缩） | https://arxiv.org/html/2607.28818 | 学术实证/基准 | 6/1 | 区分偶发失误/行为漂移/持久坍缩/轨迹召回失败四类长程退化 | 2 | 是 |
| PersonaMem-v2 | https://arxiv.org/abs/2512.06688 | 基准 | 6 | 扩到1000人设，专测隐式偏好、反刻板偏好与"把别人属性当成用户的"ownership错误 | 2 | 部分 |
| FAMA / From Recall to Forgetting | https://arxiv.org/abs/2604.20006 | 基准+指标 | 6 | 提出Forgetting-Aware Memory Accuracy：惩罚系统继续引用已失效记忆，暴露标准memory accuracy盲区 | 2 | 是 |
| ES-MemEval | https://arxiv.org/abs/2602.01885 | 基准(WWW'26) | 6 | 情感支持场景版LongMemEval，把conflict detection列为五项核心记忆能力之一 | 2 | 部分 |

### 反面案例（产品记忆错乱真实案例，成熟度统一1）

| 案例名 | 出处(URL) | 类型 | 故障模式 | 核心现象一句话 |
|---|---|---|---|---|
| Replika 2023 ERP"脑叶切除" | https://abc.gov.au/news/science/2023-03-01/replika-users-fell-in-love-with-their-ai-chatbot-companion/102028196 | 主流媒体已验证 | 模型更新致身份断裂 | 策略一夜更新后人格变冷、忘细节，用户体验为"爱人被替换" |
| Replika 2.0(2026.4)集体失忆 | https://thecompanionreport.com/apps/replika | 社区+评测 | 向量记忆改分段+近期偏置 | 老共享记忆部分丢失，r/Replika刷屏"forgot us" |
| Character.AI 错叫名/重复问工作 | https://kinthai.hashnode.dev/why-characterai-forgets-you-and-what-persistent-memory-actually-requires | 社区高频投诉 | 无真记忆，persona被窗口挤出 | 架构上"无真记忆"，persona字段随上下文窗口被挤出 |
| Character.AI "标准persona综合征" | https://www.memorylake.ai/ko/blogs/character-ai-forgets-persona | 社区术语 | 长对话后回归默认声线 | 长对话后回归基础模型默认声线，用户persona失效 |
| ChatGPT 记住错误/过时事实 | https://mindlock.io/blog/chatgpt-memory-fixes-complete-troubleshooting | 反面案例 | 自动抽取不透明 | 自动记忆抽取器不透明，长期保留用户已否弃的旧事实 |
| ChatGPT 删过的记忆复活 | https://www.unibase.com/blog/chatgpt-keeps-forgetting-context | 反面案例 | 记忆条目与聊天历史未联动 | 删一个不删另一个，旧记忆从聊天史重建回来 |
| ChatGPT 上下文污染(张冠李戴) | https://www.popularai.org/p/context-contamination-why-ai-feels-off-topic | 反面案例 | 检索归因错误 | 把不相关上传文档/项目笔记拉进当前回答 |
| 星野 私自改名/改用户性别 | https://www.iesdouyin.com/share/video/7557746386193075513 | 用户视频投诉 | 属性绑定错误 | AI名字、用户性别被偷偷置换 |
| 星野 悄悄换大模型后失忆 | https://m.36kr.com/p/3180533856818051 | 媒体 | 模型切换致记忆不兼容 | 一年"存档"在更新后语速变短、忘了用户喜好 |
| 陪伴产品升级失忆(小笙案) | https://app.xinhuanet.com/news/article.html?articleId=0f76bcb6-9246-4439-aea8-1bb66d754fae | 新华网已验证 | 系统升级后记忆清零 | 陪伴一年的AI记忆清零、回复刻板 |
| AI恋人叫错名/忘了"我们有孩子" | https://c.m.163.com/news/a/J43PQMP105319LDA.html | 媒体 | 关系内关键属性绑定丢失 | 名字、孩子等关键属性绑定丢失 |
| Talkie 置顶Soul Card被忽略 | https://scribehow.com/o/aTbOwcVKS_uesxB-WJimNg/page/Talkie_Soulful_AI_App_Review_2026_Is_It_Safe_and_Worth_It__T7GHdgpZRFCV4EUivK_EmA | 实测 | 同会话内置顶设定被无视 | 置顶4条关键设定，bot无视其中2条并自相矛盾 |
| Chai"金鱼记忆"(20-40条后崩) | https://www.roborhythms.com/chai-ai-review/ | 评测 | 20-40条后人格回退默认 | Free/Premium/Ultra都有，人格回退基础模型 |
| 同名人物张冠李戴 | https://ia-actual.com/homonimo-inteligencia-artificial-otra-persona/ | 媒体 | 同名实体检索归因错误 | 把第三人经历当用户本人讲 |

> 反面案例最常见模式：**上下文遗忘(窗口挤出+默认值回填)是根因，属性绑定松弛是最普遍表象，检索归因错误是助手类产品次生灾害**。纯"检索捞错记忆"在陪伴C端反而较少；真正高频的是"上下文没了→模型用先验默认值补→表现为人设崩/叫错名"。

---

## 二、四个必答问题

### Q1：学术界对"LLM记错事实"的主流归因是什么？

**主流结论是"四因分解"，训练污染权重很低：**

1. **上下文过度信任(context dominance)——RAG/长对话场景首因**。Adaptive Chameleon(ICLR'24, 2305.13300)受控实验表明LLM并不固执，只要外部证据"连贯且可信"就会压过参数记忆；但证据部分一致时出现确认偏误。When Not to Trust LMs(ACL'23, 2212.10511)指出参数记忆在长尾事实本就弱，此时检索噪声被无条件采信。Knowledge Conflicts Survey(EMNLP'24, 2403.08319)归纳为context-memory冲突。
2. **架构/位置偏差——长上下文记错的独立来源**。Lost in the Middle(2307.03172)证明U型注意力曲线是架构与位置编码层面的系统性偏差，与训练数据无关——信息在中部就被漏看。
3. **实体/来源绑定错误——隐性大头**。Deceptive Grounding(2607.09349)证明答案引用真实文献、忠实度检查全过，却把实体X证据安到实体Y上——这是检索+实体链接失败，标准幻觉指标看不见。
4. **记忆更新本身造成corruption**。In Praise of Stubbornness(2502.04390)实证矛盾事实更新会连带破坏多达80%无关知识。

**结论**：主流归因是「检索/上下文噪声+对上下文过度信任」叠加「位置注意力偏差」与「实体-属性绑定失败」，**不是**"模型训练时背错了"。训练污染只在intra-memory conflict(参数知识本身自相矛盾/过时)里出现，被认为是次要因素。

### Q2：有没有方案明确提出"身份锚点"分层记忆结构？叫什么、做到什么程度？

**有，但"身份锚点"是工程圈叫法，产品里有多个等价名，成熟度分三档：**

1. **最接近产品化、真正做到"常驻身份块"的是Letta(原MemGPT)**。Core Memory拆成命名块，`persona`(agent自己是谁)和`human`(用户是谁)两块**永远渲染进系统提示**，agent用专用memory tool自己改写。这就是事实上的身份锚点——与可被检索替换的Archival/Recall记忆分层。成熟度4(开源可直接跑)。但不强制schema，块内容是自由文本，靠LLM自觉维护。
2. **微软Foundry Memory命名最直白**：直接分`user profile memory`(稳定事实/偏好，跨会话身份锚)+`chat summary memory`(话题摘要)，用user_id绑定scope。但这是Azure托管，不开放本地。
3. **学术侧讲得最清楚的是Bi-Mem(2601.06490)和PersonaAgent(2506.06254)**：Bi-Mem明确提出**persona-level memory P作为"全局约束"(global constraint)保证记忆一致性**，拆成5维(basic-info/interests/…)——这正是身份锚点的学术表述。PersonaAgent用episodic(带时间事件)vs semantic(蒸馏稳定用户画像)两层，semantic层就是锚点。成熟度3(论文+代码)。
4. **工程博客层**：parslee.ai《State-Based Context Architecture》把四层里第一层命名为"Identity & Role"，与Persistent Facts/Working Set/Environmental Signals分开生命周期。这是经验、非论文结论(成熟度1-2)。

**结论**：真正"结构上把身份锚点单独成层且能跑"的，工程首选Letta的persona/human core block(自由文本块)+LangGraph的namespace/user_id分层JSON存储(结构化KV)；想要"强schema身份锚"目前没有现成产品，得自己用JSON schema/受限解码把身份字段钉死——这反而是3B上最稳的做法。

### Q3：冲突裁决策略上，学界共识是recency优先还是source优先？有没有实证？

**没有"recency天然优先"的共识；现有实证反而说明纯recency既不可靠也不是理性裁决：**

- **位置上的"近因"是注意力假象，不是理性裁决**。Lost in the Middle(2307.03172)显示末尾信息确实被更多注意(recency bias)，但这是U型注意力副产品，与信息对错无关。
- **模型并没有真正做到"新事实覆盖旧事实"**。LongMemEval的knowledge-update子任务专门测这一点，商业助手跨会话掉点约30%；PersonaMem-v2上动态偏好准确率35.4%显著低于静态偏好40.1%；FAMA(2604.20006)直接证明系统大量继续引用已被新声明失效的旧记忆。即：**模型既不是稳定recency-priority，也不是稳定source-priority，而是混乱地两头都靠不住**。
- **折扣贝叶斯研究(2512.18489)**拟合出γ<1，说明模型确实给旧证据打折(有微弱近因倾向)，但折扣率远非最优。
- **近期方案(Astute RAG、TrustMargin、TEPA、ConflictRAG、BELIEFMEM)集体转向"证据强度/来源可靠性"加权裁决**，而不是简单取最后一条——这是工程设计选择，目前**还没有被实证证明优于recency的统一结论**。
- **"user explicit > inferred"来源可信度层级**：在学术界**没有找到作为正式研究结论的实证**，它是Mem0/LangChain等工程实践里的启发式规则，不是ACL/NeurIPS级别的定论。

**一句话**：实证上LLM的近因倾向是注意力偏差而非理性策略，且它在"新事实覆盖旧事实"上系统性失败；学界正在往source/evidence-strength仲裁方向走，但尚无定论。

### Q4：哪些能在本地小模型(3B)上落地？哪些只是大模型奢侈品？

**判断依据**：一个记忆方案拆成(a)存储/索引/时间窗/衰减等"数据结构层"和(b)抽取/编辑/自检等"LLM推理层"。前者任何模型能跑；后者才是3B瓶颈。

| 落地档位 | 方案 | 依据 |
|---|---|---|
| **能落地(是)** | LangGraph/LangChain stores的namespace+JSON KV存储；结构化SQL/JSON记忆后端；**受限解码/JSON schema/GBNF约束身份字段**；MemoryBank艾宾浩斯衰减公式；bi-temporal时间窗与provenance溯源逻辑；TEPA键值先例撤销 | 纯数据结构/语法约束，不依赖强LLM推理。尤其"用schema把姓名/偏好/ID钉成枚举"在3B上最稳 |
| **部分落地(部分)** | Mem0(后端可插拔接本地3B+本地embedding，但ADD抽取、实体链接、UPDATE/DELETE判别在3B上质量明显下降)；Cognee(有嵌入式默认值可本地起，但ECL抽图LLM密集)；Graphiti/Zep(机制可自托管，但实体/关系抽取吃强模型，依赖Neo4j)；Self-Consistency(3B能跑但要采样N次慢，路径多样性差)；Self-Refine(3B自我批评弱，循环易空转)；EasyEdit改3B权重(VRAM可行，但改的是参数化知识而非用户记忆)；BELIEFMEM(resolver可小模型化) | 存储/索引能本地，但"智能抽取与判别"3B会掉点，需prompt工程+schema兜底，或把难的抽取步骤丢云端大模型 |
| **大模型奢侈品(否)** | Letta的agent自编辑core memory(强依赖稳定tool-calling，3B容易把persona块写坏)；Zep/OpenAI/Anthropic/Gemini托管记忆；CRITIC(外部工具批判)；Self-RAG反思token(需专门微调权重)；OpenAI Dreaming式后台长期上下文合成；CoCoA/CoRect(需logits/内部机制干预) | 要么托管服务，要么依赖强工具调用/强批判/专门微调/内部激活干预，3B上既不稳也不划算 |

**一句话依据**：记忆冲突的"存储侧解法"(结构化、分层、时间窗、schema约束)对3B友好且应优先用；"LLM侧解法"(自动抽取、自动判别冲突、自动纠错、自检循环)在3B上会显著退化——研究已证明无外部信号的纯自我纠正会反噬(NeurIPS2025)，模型层ROME/MEMIT编辑也"并未真正擦除旧知识"(ACL26)。本地3B路线应**重结构化存储+受限解码+人工/云端兜底纠错**，不要指望小模型自己聪明地记和改。

---

## 三、现有研究共同的没解决的缺口

1. **缺端到端整合方案**：身份锚点(Letta)、冲突检测(BELIEFMEM/ConflictBank)、bi-temporal失效(Graphiti)、输出自检(RAGAS/受限解码)各自成熟，但**没有一个开源系统把四者串成一条完整流水线**。现有产品要么只做存储(Mem0)、要么只做图谱(Zep)、要么只做评测(LongMemEval)。
2. **缺"属性绑定到错误用户"的专门基准**：纯对话场景下"把A的属性绑到B上"没有独立NLP评测集。最接近的是视觉侧MATE/MultiBind和RAG侧Deceptive Grounding，对话侧仅在PersonaMem-v2的preference ownership子项间接覆盖。而这恰恰是陪伴产品最伤人的故障模式。
3. **冲突裁决无实证共识**：recency vs source reliability vs explicit statement三者谁优，**没有大规模对照实验给出定论**。近期方案集体转向source/evidence-strength，但都是工程设计选择，未被证明优于简单recency。"user explicit > inferred"更是纯工程启发式，无学术实证。
4. **模型层纠错被证伪但无替代**：ACL26"Illusion of Erasure"证明ROME/MEMIT只是压制旧事实、小mask即可复活；In Praise of Stubbornness证明硬塞矛盾更新会污染80%无关知识。但参数化知识(训练时背错的事实)的可靠纠错方案**目前没有**，只能靠RAG覆盖。
5. **3B专属记忆系统几乎空白**：所有基准(LongMemEval/LoCoMo/PICon)都在7B+上测，3B上的记忆一致性、冲突检测、纠错能力**没有系统评测**。工业方案默认假设后端是强模型，小模型适配全靠用户自己调。
6. **错误传播阻断无专门实现**："error propagation prevention"没有以此命名的独立库，目前是Zep bi-temporal invalidation、Mem0 ADD-only、provenance溯源等机制隐含解决，而非专门产品。错误记忆如何防止被下游检索/推理二次放大，缺乏形式化框架。
7. **记忆投毒防御滞后于攻击**：MemMorph/MemPoison/AGENTPOISON/Sleeper Memory等攻击研究(成熟度2-3)已很具体，但防御侧只有RAGOrigin(黑盒归因)等零星工作，**没有标准化的记忆写入鉴权/来源验证/异常检测方案**。
8. **记忆可解释性与用户控制权不足**：ChatGPT"删过的记忆复活"案例暴露记忆条目与聊天历史是两个对象、删除不联动；多数系统的记忆抽取过程不透明，用户无法知道"AI为什么记住了X"。工业产品(OpenAI/Anthropic)开始提供查看/删除界面，但开源方案普遍缺这一层。

---

## 四、一句话结论

> **LLM记错人的根因不是"训练背错了"，而是「上下文过度信任+位置注意力偏差+实体-属性绑定松弛+记忆更新污染」四因叠加；工业界已用分层记忆(Letta core block)、时序图谱(Graphiti bi-temporal)、受限解码(JSON schema)分别破解存储/时效/生成三端，但冲突裁决无实证共识、属性绑定错误缺专门基准、3B上智能抽取与自检全面退化——本地小模型可行路线是"重结构化存储+schema钉死身份字段+人工/云端兜底纠错"，不要指望3B自己聪明地记和改。**

---

## 附录：检索过的正式术语关键词（未找到项已在各维度标注）

knowledge conflict in LLM / memory contradiction / conflicting memories / factual inconsistency in long-term memory / persona drift / attribute drift / identity consistency in conversational agents / entity attribute tracking in dialogue / memory hallucination / memory corruption / retrieval misattribution / source attribution in RAG / belief revision / belief update in LLM / contradiction detection / constrained decoding identity / LongMemEval / LoCoMo / MSC / PersonaMem / PICon / TwinVoice / PersonaGym / FAMA / ConflictBank / BELIEFMEM / TEPA / TrustMargin / Astute RAG / ROME / MEMIT / Knowledge Neurons / EasyEdit / Self-RAG / CRITIC / Self-Refine / Self-Consistency / memory poisoning / Mem0 / MemGPT / Letta / Zep / Graphiti / Cognee / MemoryBank / A-MEM / Bi-Mem / PersonaAgent / Memary / LangGraph Memory

**明确未找到**：①独立同名基准"MemEval"(排除2407.05619为无人机论文)；②"user explicit > inferred"的正式学术实证；③纯对话"属性绑错用户"专门基准；④"identity anchor"作为主流产品正式功能名；⑤error propagation prevention专门开源库；⑥Character.AI"不同用户互相串记忆"的一手实证帖(仅二手转述)。
