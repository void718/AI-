# 主题C：话题漂移 / 自然拐弯 —— 方案侦察清单

> 子任务：AI 主动性方案侦察 · 主题C
> 整理日期：2026-09-27
> 子方向：① 对话中的话题转移（topic shift / drift / digression）；② 联想式对话生成（associative dialogue）；③ 非连贯对话建模（non-sequitur / meandering）
>
> 成熟度定义：5=已产品化稳定复现；4=有开源实现可直接跑；3=论文级、有代码但不完整；2=只有思路或 demo；1=纯概念。
> 迁移到本地轻量模型（3B 级）一栏：✅ 可 / ⚠️ 部分可 / ❌ 难。

---

## 一、方案清单（按成熟度降序）

### 成熟度 5（已产品化 / 稳定复现）

| 方案名 | 出处（真实 URL） | 类型 | 解决哪个子方向 | 核心机制（一句话） | 成熟度 | 可迁移到 3B 本地模型 |
|---|---|---|---|---|---|---|
| SillyTavern World Info / Lorebook（关键词触发式设定注入） | https://docs.sillytavern.app/usage/core-concepts/worldinfo/ （官方文档；中文镜像 https://docs.eigeen.cc/usage/core-concepts/worldinfo/ ） | 开源产品（官方文档） | C-② 联想式对话（按关键词联想注入背景/设定，驱动话题自然切换） | 维护一个"动态词典"，当消息中出现某条目关键词时，自动把对应 lore 片段插入 prompt，使模型在新话题上有料可接 | 5 | ✅ 关键词匹配本身极轻量；但"用不用得好"取决于底座模型，3B 可跑注入逻辑 |
| Rasa Stories / CALM Flows + Conversation Patterns（显式话题流转状态机） | https://rasa.com/docs/rasa/next/writing-stories/ （官方，"Using Stories for Context Switching"）；https://rasa.com/docs/rasa/contextual-conversations/ （官方，Conversation Patterns：chitchat/search/handoff/导航） | 开源产品（官方文档） | C-① 话题转移（工程层：用户打断/插话后切话题再切回） | 用 stories 显式编写"从流程A切到插话话题、办完再切回流程A"的路径；CALM 把对话抽象成 Flow，配 chitchat/search/recover 等可复用 pattern | 5（工程成熟）；但属任务型对话，非开放闲聊 | ⚠️ Rasa 整套栈较重、依赖 NLU/训练；状态机思路可借鉴，但不适合纯本地 3B 轻量闲聊 |

### 成熟度 4（有开源实现、可直接跑）

| 方案名 | 出处（真实 URL） | 类型 | 解决哪个子方向 | 核心机制（一句话） | 成熟度 | 可迁移到 3B 本地模型 |
|---|---|---|---|---|---|---|
| MapDia / ChMapData（记忆感知的主动话题转移） | 论文 https://arxiv.org/abs/2503.05150 ；代码与数据集 https://github.com/FrontierLabs/MapDia | 论文 + 开源 | C-① 主动话题转移生成（在恰当时机把话题拉回相关历史话题） | RAG 三段式：话题摘要（Topic Summarization）→ 相关历史话题召回（Topic Retrieval，排序模型）→ 主动漂移时机检测与生成（Proactive Topic-shifting Detection & Generation，带 CoT "Thoughts" 判断该不该切） | 4（论文称框架与数据已开源，且用 7B LLM 训练即在 A/B 测试中超过 GPT-4） | ⚠️ 官方用 7B；3B 可跑召回/摘要小模块，但"切话题时机判断 + 自然生成"对 3B 偏难 |
| Rhea（角色感知的情景记忆注意力） | 论文 https://arxiv.org/abs/2512.06869 ；代码 https://github.com/ddInference/Rhea | 论文 + 开源 | C-① 上下文切换时的相关上下文筛选（用户 pivot 后不带入上一话题的无关上下文） | 把历史拆成"指令记忆 IM（全局约束）+ 情景记忆 EM（互动片段）"，用非对称噪声控制 + 启发式检索做优先级注意力，只把高信噪比片段塞回 prompt | 4（有开源 repo） | ⚠️ 工程层（记忆检索/注意力调度）可移植；但"判断什么该留"仍依赖较强底座 |

### 成熟度 3（论文级 / 有代码不完整）

| 方案名 | 出处（真实 URL） | 类型 | 解决哪个子方向 | 核心机制（一句话） | 成熟度 | 可迁移到 3B 本地模型 |
|---|---|---|---|---|---|---|
| CNTD 中文话题漂移检测（师生框架 + 层次对比学习） | https://arxiv.org/abs/2305.01195 （Lin et al.） | 论文 | C-① 话题漂移**检测**（预判用户下一句是否要换话题） | 标注 1308 段中文自然对话语料 CNTD；师生知识蒸馏：老师偷看回复、学生只看上文，用层次对比学习在"无回复"条件下预测是否漂移 | 3（BERT-base-Chinese 分类器，F1 约 54%，论文级） | ✅ BERT-base 量级极轻，可直接做"漂移检测器"外挂；但它只检测不生成 |
| TACT（TOD↔闲聊 转换感知对话） | https://aclanthology.org/2025.emnlp-main.672.pdf （EMNLP 2025） | 论文 + 数据集 | C-① 任务与闲聊两种模式间的话题切换/恢复 | 构造 TCT（任务→闲聊→任务）与 CTC（闲聊→任务→闲聊）流，提出 Switch（切换）与 Recovery（恢复）两个指标，训练模型主动发起并从模式切换中恢复 | 3（数据集 + 训练范式，非开箱产品） | ⚠️ 数据集可用；生成质量仍需中大型模型 |
| CANTTALKABOUTTHIS（让模型**守住**话题，反面校准） | https://arxiv.org/abs/2404.03820 | 论文 + 数据集 | C-③ 反面：抗干扰、不被带跑（与"自然拐弯"相反，用于对照/平衡） | 构造混入干扰轮次的合成对话，微调模型使其在任务型对话中抗住"故意把机器人带偏"的轮次、保持话题一致 | 3（有数据集与微调实验） | ✅ 数据/方法轻；但它解决的是"别乱飘"，做闲聊时需反向使用 |
| GauchoChat（主动可控个性化社交对话） | https://cdn.amazon.science/80/c9/c241c7c94d09bfca04b4a73a4dc9/gauchochat-towards-proactive-controllable-and-personalized-social-conversation.pdf | 论文（Amazon Science） | C-① 主动话题切换模块（从被动应答转到主动抛话题） | Promptist 根据用户意图/人设/情绪动态选提示策略，另有一个 proactive topic switching 模块智能判断何时切换话题并把外部素材织入对话 | 3（论文，未见完整开源代码） | ⚠️ 思路可借鉴；依赖外部素材检索 |
| Unified Conversational Models：系统发起的话题转换句 | https://dl.acm.org/doi/fullHtml/10.1145/3571884.3597125 （ACM WWW） | 论文 | C-① 生成"过渡句"主动从闲聊切到任务 / 从任务切到闲聊 | 训练两个离散 token 或连续 prompt，让统一模型主动产出一句 transition sentence 来触发系统发起的模式切换 | 2–3（prompt-tuning 级，无产品） | ⚠️ 离散 token 思路轻量，但需微调 |
| ProCoT（主动对话的思维链提示） | https://arxiv.org/abs/2305.13626 | 论文 + prompt | C-① 主动话题/澄清提问（prompt 工程级） | 用 proactive chain-of-thought 提示激发 LLM 的规划能力；论文同时指出：不加约束时 LLM 会"过激地"把话题拽向指定目标 | 3（纯 prompt 方案，可直接试） | ✅ 纯 prompt，3B 能跑但效果弱（论文明示小模型主动提问仍差） |
| SalesBot 2.0（意图引导的平滑闲聊过渡） | https://arxiv.org/abs/2308.14266 | 论文 + 数据集 | C-① 平滑、多轮地把话题过渡到目标意图，避免生硬跳转 | 先找"当前话题与目标意图的交集话题"，再用多轮逐步过渡，要求 transition 尽量自然不突兀 | 3（数据构造范式 + LLM 提示） | ✅ 提示范式可直接复用 |
| PaRT（个性化实时检索增强的主动社交聊天） | https://arxiv.org/abs/2504.20624 （SIGIR 2025） | 论文 | C-① 主动生成个性化新话题 | 把用户画像+上下文喂 LLM，先精化意图再生成个性化话题，作为 query 去小红书等语料检索相关段落，织入回复 | 3（框架论文） | ❌ 依赖外部检索库与较强 LLM，3B 吃力 |
| UPC（用 Critic 引导的用户导向主动对话） | https://arxiv.org/abs/2505.12334 | 论文 | C-① 主动话题的"度"控制（不过激、不冷淡） | 用 LLM-as-a-judge 做 critic 评估主动度，再让 bot/user 两个 agent 互聊生成高主动度语料做 SFT | 2–3 | ❌ 依赖较强 LLM 当裁判与生成器 |

### 成熟度 2（思路 / demo / 工程博客）

| 方案名 | 出处（真实 URL） | 类型 | 解决哪个子方向 | 核心机制（一句话） | 成熟度 | 可迁移到 3B 本地模型 |
|---|---|---|---|---|---|---|
| STAR-BTM（多轮对话的话题相关性建模） | https://arxiv.org/abs/2009.12735 | 论文 | C-① 话题漂移时"该接哪段上下文" | 用 Biterm Topic Model 在话题级（而非词/句级）判断哪些历史上下文与当前轮相关，再生成回应 | 2（较早、已偏传统方法） | ✅ 话题模型可外挂，但工程较旧 |
| Convergent & Divergent Decoding（topic drifter 漂移词） | https://arxiv.org/abs/2005.03174 | 论文 | C-② 联想式话题扩展（避免一直重复同一话题） | 设一个 topic drifter，从上下文与事实中产出"漂移词"，从当前话题候选往外扩，提升对话多样性与流畅度 | 2（解码策略，论文 demo） | ⚠️ 解码层思路可借鉴；实现偏旧 |
| DASH-DTS（公共频道对话话题分段） | https://arxiv.org/abs/2512.15042 | 论文 | C-① 话题分段 / 新话题起点检测 | 握手识别模块找"开启新话题的短互动线索"，再用对话相似度引导的 in-context 检索做话题切分 | 2–3（结构感知框架，代码未全开源） | ⚠️ 需检索/ICL，3B 做握手判断偏难 |
| Membox（把话题连续性织进长程记忆） | https://arxiv.org/abs/2601.03785 | 论文 | C-① 跨时段的话题连续性（相邻交换之间的稳定主题框） | 反对"切碎再用 embedding 检索补连贯"，改用层次记忆结构保留叙事/因果流，避免检索偏向词面相似 | 2（新论文，repo 待成熟） | ❌ 偏记忆架构研究，3B 难落地 |
| Think Before You Speak（内心独白式主动避题） | https://arxiv.org/abs/2311.07445 | 论文 | C-① 遇到不想/不会聊的话题时主动转移到熟悉内容 | 用 inner monologue 让模型意识到"这个话题不熟/该回避"，再主动做 topic transition 切到熟悉内容 | 2 | ⚠️ 思路可 prompt 化；"判断该不该转"对 3B 难 |
| AutoReply（自省式检测对话里的 nonsense） | https://arxiv.org/abs/2211.12615 | 论文 | C-③ 非连贯/无意义回复的检测（反面质量门） | 让模型自省式地判别当前回复是否属于重复/无意义等 nonsense 类型 | 2 | ✅ 判别思路轻，可做输出过滤器 |

### 社区 / 工程博客（prompt 级与反面材料）

| 方案名 | 出处（真实 URL） | 类型 | 解决哪个子方向 | 核心机制（一句话） | 成熟度 | 可迁移到 3B 本地模型 |
|---|---|---|---|---|---|---|
| "Interrupt and Redirect" 两行式换话题提示 | https://www.aiangels.io/blog/interrupt-and-redirect-prompt-two-line-pattern-ai-companion-subject-change | 工程博客（社区经验，非官方） | C-① 用户侧主动拐弯的 prompt 模板 | 第一行明确"上一话题关闭"的中断信号，第二行给新话题的具体引导，两步拆开避免模型黏在上一话题 | 3（社区反复验证的 prompt pattern） | ✅ 纯 prompt，3B 可试但遵循度弱 |
| "Hard Pivot / Hard No" 换话题脚本系列 | https://www.aiangels.io/blog/hard-pivot-script-change-subject-ai-companion-no-loop ；https://www.aiangels.io/blog/hard-no-prompt-three-sentence-templates-train-ai-drop-topic-guilt | 工程博客（社区经验） | C-① 从重情绪话题干净切到轻松闲聊、不触发"你怎么了"循环 | 用"承认→桥接过渡词(speaking of which)→给明确新话题"三段式，不给模型留情绪尾巴可追 | 3 | ✅ 纯 prompt |
| 中文"像朋友一样聊天、把天聊活"提示词 | https://www.cnblogs.com/ghj1976/p/18657144/jing-dianprompt-fen-xiang-ru-he-rangai-xiang-peng | 博客园（中文社区） | C-② 话题延续 + 主动抛出相关新话题 | 要求每轮结尾延伸相关新话题、主动提具体话题（美食/电影/旅游），避免问"有什么要聊的"这种泛问 | 2–3 | ✅ 纯 prompt，3B 可直接试 |
| "The Passivity Problem"（AI 为什么不主动、一根筋） | https://whitepapers.gravity7.com/notes/the-passivity-problem-why-the-most-capable-ai-models-in-the-world-still-cant-lea/ | 分析博客（引用 CollabLLM 等） | C-③ 反面：为什么 AI 不会主动拐弯 | 论点：RLHF 优化的是"单轮有用性"，系统性侵蚀多轮对话与主动性；越被动越"显得权威" | 2（观点性分析，非可运行方案） | —（诊断，非方案） |
| Character.AI 为何"擅自换场景"（第三方分析） | https://www.roborhythms.com/character-ai-bot-changes-scenario/ | 博客（**第三方推测，非官方**） | C-③ 反面：话题漂移其实是上下文窗口耗尽后的连贯性失败 | 原场景滚出上下文窗后，模型从最近一条消息重建场景、用训练数据填空，于是"换了剧情"——这不是人设而是 coherence failure | 2（社区推测） | —（诊断） |
| Google 开发者论坛：模型死盯最后一条消息 | https://discuss.ai.google.dev/t/context-memory-problem/51505 | 社区帖子（**第三方反馈**） | C-③ 反面：recency bias 导致黏在上一话题、循环、自相矛盾 | 用户观察到所有主流模型都过度聚焦最后一条 user message，忽略全程上下文，长对话里"拐不动" | 2 | —（诊断） |

---

## 二、按"实现成本"重新归类（重点结论）

### ① 纯靠 prompt 就能实现的方案
- **ProCoT**（https://arxiv.org/abs/2305.13626）—— 主动对话思维链提示。
- **Interrupt and Redirect / Hard Pivot / Hard No**（aiangels.io 系列）—— 中断+重定向两行/三段模板。
- **博客园"像朋友聊天"提示词** —— 每轮结尾主动抛具体新话题、避免泛问。
- **SalesBot 2.0 的过渡提示范式** —— 先找两话题交集、再多轮平滑过渡。
- 通用做法：在 system prompt 里写"允许在合适时机自然开启新话题、用 '说到这个/对了' 之类过渡、不要每次都硬扣回上一句"。

### ② 需要外挂工程（话题检测 / 状态机 / 知识库联想）的方案
- **CNTD 话题漂移检测器**（BERT-base 分类器，外挂判断"用户这轮是不是要换话题"）。
- **MapDia 三段式 RAG**（话题摘要 + 历史话题召回排序 + 漂移时机检测）。
- **SillyTavern World Info**（关键词触发式 lore 注入，做联想式背景供给）。
- **Rasa Stories / CALM Flows**（显式状态机，处理插话-切走-切回）。
- **CrewAI Conversational Flows**（每轮先做 intent 分类再 route_turn 路由）——https://docs.crewai.com/en/guides/flows/conversational-flows
- **Rhea 记忆调度**（IM/EM 双记忆 + 优先级注意力，做上下文取舍）。

### ③ 在 3B 级小模型上可能无效 / 效果打折的方案及原因
- **MapDia 的"主动漂移时机判断 + 自然生成"**：时机判断本质是隐式推理，3B 判别力弱，容易"该切不切/乱切"；官方用 7B 才超过 GPT-4。
- **PaRT / UPC / GauchoChat**：依赖较强 LLM 做意图精化、个性化话题生成、LLM-as-judge 评判，3B 既写不出好话题也当不了好裁判。
- **Membox / DASH-DTS 的"握手识别 + 语义叙事连贯"**：需要细粒度语用与长程叙事理解，3B 缺这个语义敏感性。
- **ProCoT 式主动澄清/抛话题**：论文明示小模型在主动提问上"原本就很差"，CoT 能提但仍有限。
- 共同原因：话题"自然拐弯"的难点不在语法而在**语用判断**——什么时候切、切到哪不突兀、怎么留桥。这正是 RLHF 大模型靠海量偏好数据才勉强学会、而小模型最缺的能力。3B 上更靠谱的是把"判断"外包给规则/检索/小分类器，只让小模型负责"生成过渡句"。

---

## 三、未能找到 / 明确标注缺口的地方（诚实声明）
- **Replika**：未找到任何关于"话题自然转换机制"的官方技术文档，社区也无可靠机制说明 → 记为"未找到官方说明"。
- **OpenAI**：未找到专门讲"对话话题管理/主动拐弯"的官方文档；只找到通用的 chat history / memory（把历史消息全量回传、跨会话记忆）。**没有官方话题漂移机制说明**。
- **Character.AI**：无官方话题机制文档；第三方博客（airoleplay.ai、roborhythms）推测其为"短期 5–7 轮窗口 + 长期人设向量"，**均为第三方推测，已在表中标注**。
- **OpenDialog**：未检索到与"话题漂移/联想"相关的实质机制。
- **AutoGen**：无原生话题漂移机制，其 GroupChatManager 只做"下一个谁发言"的 speaker selection，不做自然话题联想 → 记为不适用。
- **associative dialogue（联想式闲聊）作为独立产品化方向**：学术上分散在 proactive dialogue / word association（如 https://arxiv.org/abs/2502.08312 词联想基准、https://arxiv.org/abs/2510.12110 PACE 平行联想链），但**没有成熟的开源产品直接做"AI 自由联想式闲聊"**，多为论文或评估基准。

---

## 四、本任务实际检索过的关键词（中英文）
中文：
- AI聊天 不会拐弯 一根筋 话题转换 知乎
- 如何让AI像朋友一样聊天 避免把天聊死 prompt

英文（general_search / site:arxiv.org / site:aclanthology.org 方向）：
- topic shift detection dialogue system SIGDIAL
- topic drift conversational dialogue modeling arxiv
- associative dialogue generation free-association chatting LLM
- non-sequitur response generation dialogue conversational meandering
- Character.AI topic transition how it works conversation flow
- SillyTavern lorebook world info topic transition context
- Rasa stories rules topic switching dialogue management handoff
- RLHF makes chatbot too on-topic rigid cannot change topic instruction following
- Anthropic Claude conversation coherence memory best practices topic
- github topic segmentation dialogue LLM conversational memory repo
- proactive dialogue topic transition generation open-domain chit-chat LLM
- AutoGen CrewAI topic management conversation state machine
